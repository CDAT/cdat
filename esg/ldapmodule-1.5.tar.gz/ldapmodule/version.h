#ifndef __h_version_
#define __h_version_

/* $Id: version.h,v 1.2 1997/09/17 08:36:46 leonard Exp $ */

#include "Python.h"
extern void LDAPinit_version( PyObject* d );

#endif /* __h_version_ */

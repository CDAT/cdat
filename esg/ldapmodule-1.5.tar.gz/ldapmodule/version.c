
/* 
 * version info
 * $Id: version.c,v 1.2 1997/12/01 22:46:12 leonard Exp $
 */

#include "version.h"

static char version_str[] =
#	include "version_str.h"
;

void
LDAPinit_version( PyObject* d ) 
{
	PyDict_SetItemString( d, "__version__", 
				PyString_FromString(version_str) );
}

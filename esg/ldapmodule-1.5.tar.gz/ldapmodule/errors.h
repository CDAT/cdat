/* $Id: errors.h,v 1.1.1.1 1997/08/07 01:14:12 leonard Exp $ */

#ifndef __h_errors_
#define __h_errors_

#include "Python.h"
#include "lber.h"
#include "ldap.h"

extern PyObject* LDAPerror_object;
extern PyObject* LDAPerror( LDAP*, char*msg );
extern void LDAPinit_errors( PyObject* );

#endif /* __h_errors */

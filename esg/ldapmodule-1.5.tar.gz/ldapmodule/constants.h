#ifndef __h_constants_
#define __h_constants_

/* $Id: constants.h,v 1.2 1997/09/17 08:36:41 leonard Exp $ */

#include "Python.h"
extern void LDAPinit_constants( PyObject* d );
extern PyObject* LDAPconstant( int );

#endif /* __h_constants_ */

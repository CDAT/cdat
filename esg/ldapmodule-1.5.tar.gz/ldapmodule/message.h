#ifndef __h_message 
#define __h_message 

/* $Id: message.h,v 1.2 1997/09/17 08:36:45 leonard Exp $ */

#include "lber.h"
#include "ldap.h"
#include "Python.h"

extern PyObject* LDAPmessage_to_python( LDAP*ld, LDAPMessage*m );

#endif /* __h_message_ */


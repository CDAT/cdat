/*
 * common utility macros
 *
 * $Id: common.h,v 1.3 1999/02/12 06:02:30 leonard Exp $ 
 */

#ifndef __h_common 
#define __h_common 

#ifndef WIN32
#include <sys/time.h>
#else
#include <winsock.h>
#endif
#include <string.h>
#define streq( a, b ) \
	( (*(a)==*(b)) && 0==strcmp(a,b) )

#include "Python.h"
void LDAPadd_methods( PyObject*d, PyMethodDef*methods );
#define PyNone_Check(o) ( o == Py_None )

#endif /* __h_common_ */



import ldap
import sys

l = ldap.open("localhost", 31001)
l.simple_bind_s("cn=root,o=FNARG,c=AU","s3cr3t")

#
# create a sub organisation
#

try:
    l.add_s( "ou=Church of Fnarg,o=FNARG,c=AU",
	 [
	    ("objectclass",["organizationalUnit"]),
	    ("businesscatgeory",["cult"]),
	    ("description",["The church of Fnarg is a mildly-non-violent religion."]),
	 ]
       )
except:
    print "couldn't add entry:",sys.exc_type

res = l.search_s(
	"o=FNARG, c=AU", 
	ldap.SCOPE_SUBTREE, 
	"objectclass=*",
      )

print res

l.unbind()


#ifndef __h_functions_
#define __h_functions_

/* $Id: functions.h,v 1.2 1997/09/17 08:36:43 leonard Exp $ */

#include "Python.h"
extern void LDAPinit_functions( PyObject* );

#endif /* __h_functions_ */

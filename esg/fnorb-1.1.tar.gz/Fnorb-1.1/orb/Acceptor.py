#!/usr/bin/env python
#############################################################################
# Copyright (C) DSTC Pty Ltd (ACN 052 372 577) 1997, 1998, 1999
# All Rights Reserved.
#
# The software contained on this media is the property of the DSTC Pty
# Ltd.  Use of this software is strictly in accordance with the
# license agreement in the accompanying LICENSE.HTML file.  If your
# distribution of this software does not contain a LICENSE.HTML file
# then you have no rights to use this software in any manner and
# should contact DSTC at the address below to determine an appropriate
# licensing arrangement.
# 
#      DSTC Pty Ltd
#      Level 7, GP South
#      Staff House Road
#      University of Queensland
#      St Lucia, 4072
#      Australia
#      Tel: +61 7 3365 4310
#      Fax: +61 7 3365 4311
#      Email: enquiries@dstc.edu.au
# 
# This software is being provided "AS IS" without warranty of any
# kind.  In no event shall DSTC Pty Ltd be liable for damage of any
# kind arising out of or in connection with the use or performance of
# this software.
#
# Project:      Fnorb
# File:         $Source: /projects/fnorb/Fnorb-1.1/orb/RCS/Acceptor.py,v $
# Version:      @(#)$RCSfile: Acceptor.py,v $ $Revision: 1.2 $
#
#############################################################################
""" Acceptor (part of the 'Reactor' pattern). """


class Acceptor:
    """ Acceptor (part of the 'Reactor' pattern). """

    def __init__(self, address=None):
	""" Constructor.

	'address'  is the address to use when creating my endpoint.

	"""
	pass

    def address(self):
	""" Return the address of the acceptor's endpoint. """

	pass

#############################################################################

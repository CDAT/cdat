Embedding matplotlib in graphical user interfaces
=================================================

You can embed matplotlib directly into a user interface application by
following the embedding_in_SOMEGUI.py examples here.  Currently
matplotlib supports wxpython, pygtk, tkinter, pyqt, fltk and cocoa.

When embedding matplotlib in a GUI, you must use the matplotlib API
directly rather than the pylab/pyplot proceedural interface, so take a
look at the examples/api directory for some example code working with
the API.



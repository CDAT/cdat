#!/usr/bin/env python

## import everything from the python wrapped fortran module
import _pyIoapi as _pI
import numpy as N

## Parameters for conversion to IOAPI format metadata
## from IOAPI library PARMS3.EXT file
_IOnamelength = 16
_IOdesclength = 60
_IOmxvars = 120
_IOmxdesclines = 80
_IOmxlays = 100
_m3int = 4
_m3real = 5
_m3dble = 6
_IOwritenew = 3
_IOwriteupdate = 2


def padText(text, length = _IOnamelength):
    """
    Pads a text string w/ trailing spaces.

    Inputs:
          text  - text string

          length - length of new string, default is the IOAPI namelength

    Output:
          newStr - string of size length

    Note/Assumptions:

       1.  Internal function.  Should generally not be used by
           normal users.
    """

    lenStr = "%d" %length 
    fmtLine = "%-" + lenStr + "s"
    tmpText = fmtLine %text
    return tmpText

def padList(textLst, elemLength = _IOnamelength, \
                totalLength = _IOmxvars * _IOnamelength, list2stringFlag = False):
    """
    Pads a list of strings w/ trailing spaces.  Can produce a list
    of extended strings or can concatenate the list into one
    string of length totalLength.

    Note/Assumptions:

       1.  Internal function.  Should generally not be used by
           normal users.

    """

    lenStr = "%d" %elemLength
    totStr = "%d" %totalLength
    fmtLine1 = "%-" + lenStr + "s"
    fmtLine2 = "%-" + totStr + "s"

    if list2stringFlag:
        tmpStr = ""
        ## Expand each element to appropriate length
        for elem in textLst:
            tmpStr += fmtLine1 %elem

        ## take new string of all elements (string length = elemLength)
        ## and expand it pack the end until get total length
        tmpStr = fmtLine2 %tmpStr

        ## Return the full string
        return tmpStr

    else:
        ## expand each element to appropriate length
        tmpLst = [fmtLine1 %elem for elem in textLst]

        return tmpLst

def padNumeric(a, length = 0, type = N.float):
    """
    Pads the end of a numeric array w/ zeros.

    Inputs:
          a  - Numeric array

          length - length of new array

          type - Numeric type
    Output:
          newArray  - array of size length.

    Note/Assumptions:
       1.  Internal function.  Should generally not be used by
           normal users.

    """
    newArray = N.zeros(length, type)
    newArray[0:len(a)] = a
    return newArray

## def populateCdesc3(cdesc3=None, ioM=None):
##     """
##     Populates the cdesc3 commonblock w/ data from
##     iometa.  This is required to write to an IOAPI format file.

##     Note/Assumptions:

##        1.  Internal function.  Should generally not be used by
##            normal users.
##
##        2.  Call this from ioapiTools.

##     """
##     if cdesc3 is None:
##         raise KeyError, "cdesc3 must be passed to function"
##     if ioM is None:
##         raise KeyError, "ioM must be passed to function"

##     ## Need to expand string variables to appropriate length and
##     ## collapse lists into single long strings to populate cdesc3

##     cdesc3.gdnam3d = padText(ioM.gridName)
##     cdesc3.upnam3d = padText(ioM.upname)

##     cdesc3.fdesc3d = padText(ioM.fileDesc, _IOdesclength*_IOmxdesclines)

##     cdesc3.vname3d = padList(ioM.vnameLst, list2stringFlag = True)
##     cdesc3.units3d = padList(ioM.vunitsLst, list2stringFlag = True)
##     cdesc3.vdesc3d = padList(ioM.vdescLst, elemLength = _IOmxdesclines, \
##                                       totalLength = _IOmxdesclines * _IOmxvars, \
##                                       list2stringFlag = True)

## def populateBdesc3(bdesc3=None, ioM=None, cdmsM=None):
##     """
##     Populates the bdesc3 commonblock w/ data from
##     iometa and cdmsmeta.  This is required to write to an IOAPI
##     format file.

##     Note/Assumptions:
##        1.  Internal function.  Should generally not be used by
##            normal users.
##
##        2.  Call this from ioapiTools.

##     """
##     if bdesc3 is None:
##         raise KeyError, "bdesc3 must be passed to function"

##     if ioM is None:
##         raise LookupError, "Metadata ioM must be set"

##     if cdmsM is None:
##         raise LookupError, "Metadata cdmsM must be set"

##     ## Populate all the bdesc3 variables
##     ## for some reason, the single value variables are actually arrays
##     ## so assign to first element

##     ## Easy ones are simply in ioM
##     bdesc3.p_alp3d[0] = ioM.p_alp
##     bdesc3.p_bet3d[0] = ioM.p_bet
##     bdesc3.p_gam3d[0] = ioM.p_gam
##     bdesc3.xcent3d[0] = ioM.xcent
##     bdesc3.ycent3d[0] = ioM.ycent
##     bdesc3.ftype3d[0] = ioM.ftype
##     bdesc3.nthik3d[0] = ioM.nthick
##     bdesc3.gdtyp3d[0] = ioM.gridType
##     bdesc3.vgtyp3d[0] = ioM.vertType
##     bdesc3.nvars3d[0] = ioM.nvars

##     ## Construct these from cdms metadat
##     ## X and Y values of the boundaries of the 0th cell
##     bdesc3.xorig3d[0] = cdmsM.xlonAxis.getBounds()[0][0]
##     bdesc3.yorig3d[0] = cdmsM.ylatAxis.getBounds()[0][0]

##     ## cell size, difference b/w 2 cells position
##     bdesc3.xcell3d[0] = cdmsM.xlonAxis.getValue()[1] - \
##                         cdmsM.xlonAxis.getValue()[0]
##     bdesc3.ycell3d[0] = cdmsM.ylatAxis.getValue()[1] - \
##                         cdmsM.ylatAxis.getValue()[0]

##     ## time
##     sdate = dates2DateTime(cdmsM.timeAxis.asComponentTime()[0])
##     date2 = dates2DateTime(cdmsM.timeAxis.asComponentTime()[1])
##     date = sdate.year * 1000 + sdate.day_of_year
##     time = sdate.hour*10000 + sdate.minute*100 + sdate.second
##     diff = date2 - sdate
##     tstep = diff.hour * 10000 + diff.minute*100 + diff.second
##     bdesc3.sdate3d[0] = date
##     bdesc3.stime3d[0] = time
##     bdesc3.tstep3d[0] = tstep
##     bdesc3.mxrec3d[0] = len(cdmsM.timeAxis) # num timesteps

##     ## Spatial Domain
##     bdesc3.ncols3d[0] = len(cdmsM.xlonAxis)
##     bdesc3.nrows3d[0] = len(cdmsM.ylatAxis)

##     ## Vertical layers -- need to add vert coords to cdmsMeta!!
##     bdesc3.nlays3d[0] = len(cdmsM.layAxis)
##     bdesc3.vgtop3d[0] = ioM.vertTop
##     sigmaLst = cdmsM.layAxis.getValue().tolist()
##     sigmaLst.append(0.0)   ## add on last element of vertcoords
##     bdesc3.vglvs3d = padNumeric(sigmaLst, _IOmxlays + 1)

##     ## Variable type
##     bdesc3.vtype3d = padNumeric(ioM.vtypeLst, _IOmxvars, N.Int)




def bdesc2dict():
    bdescDct = {}

def cdesc2dict():
    cdescDct = {}
    cdescDct["execn3d"] = _pI.cdesc3.execn3d.tostring().rstrip()
    cdescDct["fdesc3d"] = _pI.cdesc3.fdesc3d.tostring().rstrip()
    cdescDct["gdnam3d"] = _pI.cdesc3.gdnam3d.tostring().rstrip()
    cdescDct["units3d"] = _pI.cdesc3.units3d.tostring().split()
    cdescDct["updsc3d"] = _pI.cdesc3.updsc3d.tostring().rstrip()
    cdescDct["upnam3d"] = _pI.cdesc3.upnam3d.tostring().rstrip()
    cdescDct["vdesc3d"] = _pI.cdesc3.vdesc3d.tostring().split()
    cdescDct["vname3d"] = _pI.cdesc3.vname3d.tostring().split()
    
    return cdescDct


    

#!/usr/bin/env python

## Version, author and other info for this package
version="0.2"
author="Alexis Zubrow"
author_email="azubrow@uchicago.edu"
description="Low level python interface to IOAPI library"

#!/usr/bin/env python

## import everything from the python wrapped fortran module
from _pyIoapi import *

from pyIoapi import *

## Get version info from package_version file
from package_version import version as __version__
from package_version import author as __author__

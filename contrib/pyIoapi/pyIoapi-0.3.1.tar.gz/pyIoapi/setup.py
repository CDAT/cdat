import os, glob
import sys

from getopt import gnu_getopt


target_prefix = sys.prefix
for i in range(len(sys.argv)):
    a = sys.argv[i]
    if a=='--prefix':
        target_prefix=sys.argv[i+1]
    sp = a.split("--prefix=")
    if len(sp)==2:
        target_prefix=sp[1]
try:
    import cdat_info
    externals = cdat_info.externals
except:
    externals = os.path.join(sys.prefix,"Externals")
externals = os.environ.get("EXTERNALS",externals)


## Additional directory to search for libraries.
## Base search is from setup.cfg. If the prefix or home
## option is passed, add this to libDirs, the additional paths
## to search.  This directory will be searched before the setup.cfg
## directories.  Only works if only one option is used.
## e.g.:
##  $ python setup.py install --prefix=~/tmp
## This will add ~/tmp/lib to search path
##  $ python setup.py install --prefix=~/tmp --force
## This will not add anything to the search path
libDirs=[os.path.join(externals,'lib'),
         os.path.join(externals,'NetCDF','lib'),
         ] + cdat_info.cdunif_library_directories

try:
    optLst, args = gnu_getopt(sys.argv[1:], "h", ["prefix=", "home=","netcdf="])
    for opt,val in optLst:
        if opt == "--prefix":
            libDirs.append(os.path.join(os.path.expanduser(val), "lib"))
        if opt == "--home":
            libDirs.append(os.path.join(os.path.expanduser(val), "lib"))
        if opt == "--netcdf":
            libDirs.append(os.path.join(os.path.expanduser(val), "lib"))
except:
    pass

## test for prefix option, if so add to 
# Gather up all the files we need.
files = glob.glob("Src/*.f")
## pyfiles = glob.glob("Lib/*.py")

## Get package version info
version_file = os.path.join(os.curdir,"Lib","package_version.py")
execfile(version_file)

## scypy_distutils Script
from numpy.distutils.core import setup, Extension

# Some useful directories.  
## from distutils.sysconfig import get_python_inc, get_python_lib

## python_incdir = os.path.join( get_python_inc(plat_specific=1) )
## python_libdir = os.path.join( get_python_lib(plat_specific=1) )

extra_link_args=[]
if sys.platform=='darwin':
    extra_link_args = ['-bundle','-bundle_loader '+sys.prefix+'/bin/python']
## setup the python module
print 'libdirs:',libDirs
setup(name="pyIoapi",
      version=version,
      description=description,
      author=author,
      author_email=author_email,
      maintainer=author,
      maintainer_email=author_email,

      ## Build fortran wrappers, uses f2py
      ## directories to search for libraries defined in setup.cfg
      ext_modules = [Extension('pyIoapi._pyIoapi',
                               files,
                               libraries=["ioapi",] + cdat_info.cdunif_libraries,
                               library_dirs=libDirs,
			       include_dirs=['Src']+cdat_info.cdunif_include_directories,
                               extra_link_args=extra_link_args,
                               ),
                     ],
      license="GNU GPL",
      
     ## Install these to their own directory
     package_dir={'pyIoapi':'Lib'},
     packages = ["pyIoapi"],
      
     )





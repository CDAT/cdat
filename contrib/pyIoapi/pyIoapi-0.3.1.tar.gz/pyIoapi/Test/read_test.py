#!/usr/bin/env python

##  Driver to run some of the f2py wrapped functions

import pyIoapi as pI
import os
import numpy as N
from optparse import OptionParser

###########################
## Get command line options
###########################

usage = "usage: %prog [options] inIOAPI" 
parser = OptionParser(usage=usage)

parser.add_option("-v", dest="varName", default= "o3",
                 metavar=" VARIABLE_NAME",
                 help="Variable name to extract.  This will automatically capitalize "
                  " the variable.  Default is 'o3'.")

(options, args) = parser.parse_args()

if (len(args) != 1):
    parser.error("Incorrect number of arguments -- need input IOAPI file")

    
## Get all the options
inFile = os.path.expanduser(args[0])
varName = options.varName.upper()

## Setup so environmental variables
## input and output for ioapi
os.environ["IN_IOAPI"] = inFile
    
## Make variable name 16 char long
vname = "%-16s" %varName

ifile_env = "IN_IOAPI"


lay = 1

## init and open file for read
logunit = pI.init_ioapi()
print "logunit %d" %logunit

## Print some meta data
print "Metadata after init:"
pI.print_desc()

print ""

print ""

print "##########################################################"
print " Testing reading from %s" %inFile
print "##########################################################"
print ""


status = pI.open_file(ifile_env, 1)
if status == 0:
    print "-->>Error in open_file command, could not open %s" %inFile
else:
    print "-->>Success: open_file command, reading file %s" %inFile
    
print ""

## read metadata
status = pI.read_desc(ifile_env)
if status == 0:
    print "-->>Error in read_desc command, could not read description of %s" %inFile
else:
    print "-->>Success: read_desc command, reading description from file %s" %inFile
pI.print_desc()

print ""

## Use metadata to assign some parameters:

nsteps = pI.bdesc3.mxrec3d
nlays = pI.bdesc3.nlays3d
nrows = pI.bdesc3.nrows3d
ncols = pI.bdesc3.ncols3d
date = pI.bdesc3.sdate3d
time = pI.bdesc3.stime3d
tstep = pI.bdesc3.tstep3d
stime = pI.bdesc3.stime3d

print "Dimensions of variable (time, layer, rows, cols):"
print "%d %d %d %d" %(nsteps, nlays, nrows, ncols)


lay = 1

## Read a variable
print "Reading variable through read_var:"
var = pI.read_var(ifile_env,vname,nsteps,nlays,nrows,ncols,date,stime,tstep,lay)

print ""

status = pI.close_file(ifile_env)
if status == 0:
    print "-->>Error in close_file command, could not close %s" %inFile
else:
    print "-->>Success: close_file command, closing %s" %inFile

print ""



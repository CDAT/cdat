#!/usr/bin/env python

##  Driver to run some of the f2py wrapped functions

import pyIoapi as pI
import os
import numpy as N
from optparse import OptionParser

###########################
## Get command line options
###########################

usage = "usage: %prog [options] inIOAPI outIOAPI"
parser = OptionParser(usage=usage)

parser.add_option("-v", dest="varName", default= "o3",
                 metavar=" VARIABLE_NAME",
                 help="Variable name to write.  This will automatically capitalize "
                  "the variable.  Default is 'o3'.  Variable read from inIOAPI "
                  "is always 'o3'.  This intentionally will fail in the write phase "
                  "if varName does not equal 'o3'.")

(options, args) = parser.parse_args()

if (len(args) != 2):
    parser.error("Incorrect number of arguments -- need input and output IOAPI files")

    
## Get all the options
inFile = os.path.expanduser(args[0])
oFile = os.path.expanduser(args[1])
varName = options.varName.upper()

## Setup so environmental variables
## input and output for ioapi
ifile_env = "IN_IOAPI"
ofile_env = "OUT_IOAPI"
os.environ[ifile_env] = inFile
os.environ[ofile_env] = oFile

## if ofile exists, remove
if os.path.isfile(oFile):
    print "Warning removing %s" %oFile
    os.remove(oFile)
    
## Make variable name 16 char long
vnameIn = "%-16s" %"O3"
vname = "%-16s" %varName



lay = 1

## init and open file for read
logunit = pI.init_ioapi()


print ""

print "##########################################################"
print " Testing reading from %s" %inFile
print "##########################################################"
print ""


status = pI.open_file(ifile_env, 1)
if status == 0:
    print "-->>Error in open_file command, could not open %s" %inFile
else:
    print "-->>Success: open_file command, reading file %s" %inFile
    
print ""

## read metadata
status = pI.read_desc(ifile_env)
if status == 0:
    print "-->>Error in read_desc command, could not read description of %s" %inFile
else:
    print "-->>Success: read_desc command, reading description from file %s" %inFile
print ""

## Use metadata to assign some parameters:

nsteps = pI.bdesc3.mxrec3d
nlays = pI.bdesc3.nlays3d
nrows = pI.bdesc3.nrows3d
ncols = pI.bdesc3.ncols3d
date = pI.bdesc3.sdate3d
time = pI.bdesc3.stime3d
tstep = pI.bdesc3.tstep3d
stime = pI.bdesc3.stime3d

lay = 1

## Read a variable
print "Reading o3 through read_var:"
var = pI.read_var(ifile_env,vnameIn,nsteps,nlays,nrows,ncols,date,stime,tstep,lay)

print ""

status = pI.close_file(ifile_env)
if status == 0:
    print "-->>Error in close_file command, could not close %s" %inFile
else:
    print "-->>Success: close_file command, closing %s" %inFile

print ""


print ""
print "##########################################################"
print " Testing writing to %s" %oFile
print "##########################################################"
print ""

## Change some metadata output
print "Changing some metadata in cdesc3 and bdesc3 for ouput:"
gdnam3dStr = "M_test"
gdnam3dStr = "%-16s" %gdnam3dStr
pI.cdesc3.gdnam3d = gdnam3dStr
pI.bdesc3.nvars3d = 1   #1 variable output
pI.cdesc3.vname3d = "%-1920s" %vnameIn

pI.print_desc()

print ""

## Open output file for writing
status = pI.open_file(ofile_env, 3)
if status == 0:
    print "-->>Error in open_file command, could not open %s" %oFile
else:
    print "-->>Success: open_file command, writing file %s" %oFile

print ""

## Write output file
pI.write_var(var, ofile_env,vname,nsteps,nlays,nrows,ncols,date,stime,tstep)

print ""

status = pI.close_file(ofile_env)
if status == 0:
    print "-->>Error in close_file command, could not close %s" %oFile
else:
    print "-->>Success: close_file command, closing %s" %oFile



#!/usr/bin/env python
import os,sys

## this test is for the cdat test_script
## Assumes that you are in the pIoapi/Test directory

## tests that module will import
import pyIoapi



## the example data location, relative to test script
idir = "exampleData"
idir = os.path.expanduser(idir)
ifile = os.path.join(idir, "o3_aconc.ioapi")

## outfile in present directory
ofile = "test_pI.ioapi"

## print some diagnostics
print "###################################"
print "Testing pyIoapi:"
print "   input file: %s" %ifile
print "   output file: %s" %ofile
print "###################################"

## Now run the write_test script
progStr = os.path.join(sys.prefix,'bin','python')+" ./write_test.py " + ifile + " " + ofile
os.system(progStr)

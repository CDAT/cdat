# Package Scientific.QtWidgets

"""
@undocumented: qt_fake
"""

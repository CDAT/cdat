#!/usr/bin/python -tt
#=======================================================================
#                        General Documentation

"""Single-procedure module.

   See procedure docstring for description.
"""

#-----------------------------------------------------------------------
#                       Additional Documentation
#
# RCS Revision Code:
#   $Id: active2gif.py,v 1.1 2004/02/20 21:49:48 jlin Exp $
#
# Modification History:
# - 09 Dec 2003:  Orig. by Johnny Lin, Computation Institute,
#   University of Chicago.  Passed passably reasonable visual 
#   tests.
#
# Notes:
# - Written for Python 2.2.
# - Non-"built-in" packages required:  IaGraph
#
# Copyright (c) 2003 by Johnny Lin.  For licensing, distribution 
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/py_pkgs/IaGraph/.
#=======================================================================




#---------------- Module General Import and Declarations ---------------

#- Set package version number:

import IaGraph_version
__version__ = IaGraph_version.version
del IaGraph_version




#------------------------ Procedure Declaration ------------------------

def active2gif( file ):
    """Plot active VCS canvas to GIF file.

    Input:
    * file:  Filename.  String scalar.
    * sysvar:  IaGraph system variable object.  Set to the global
      object established at package import.  This keyword should
      never have to be set manually.

    Output:
    * GIF file of plot (landscape).  Existing file overwritten.

    Example:
    >>> import Numeric
    >>> from IaGraph.plot import plot
    >>> from IaGraph.active2gif import active2gif
    >>> x = Numeric.arange(100.)/Numeric.pi
    >>> y = Numeric.sin(x)
    >>> plot(x, y, psym=3)
    >>> active2gif('file.gif')
    """




#------------------------ Procedure Executables ------------------------

    import IaGraph
    sysvar = IaGraph.Sysvar()   #- IaGraph system variable object
    v = sysvar.__class__.active_canvas
    v.gif(file,'r')
    del v




# ===== end file =====

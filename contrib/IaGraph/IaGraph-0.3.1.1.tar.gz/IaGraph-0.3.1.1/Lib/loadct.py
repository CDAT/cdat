#!/usr/bin/python -tt
#=======================================================================
#                        General Documentation

"""Single-procedure module.

   See procedure docstring for description.
"""

#-----------------------------------------------------------------------
#                       Additional Documentation
#
# RCS Revision Code:
#   $Id: loadct.py,v 1.2 2004/04/30 01:26:28 jlin Exp $
#
# Modification History:
# - 17 Dec 2003:  Original by Johnny Lin, Computation Institute,
#   University of Chicago.  Passed barely minimally passably 
#   reasonable tests.
# - 24 Dec 2003:  Color map name made quite unique.  Passed barely 
#   minimally passably reasonable tests.
# - 29 Apr 2004:  Add verbose flag.  Passed barely minimally passably 
#   reasonable tests.
#
# Notes:
# - Written for Python 2.2.
# - For list of dependencies, see the import statements that are
#   found throughout the code.
#
# Copyright (c) 2003-2004 by Johnny Lin.  For licensing, distribution 
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/py_pkgs/IaGraph/Doc/.
#=======================================================================




#---------------- Module General Import and Declarations ---------------

#- Set package version number etc.:

import IaGraph_version
__version__ = IaGraph_version.version
__author__  = IaGraph_version.author
__date__    = IaGraph_version.date
__credits__ = IaGraph_version.credits
del IaGraph_version




#------------------------ Procedure Declaration ------------------------

def loadct( *in_args, **in_kwds ):
    """Load a predefined color table.

    This procedure loads a color table into a VCS canvas that is
    passed in as an argument.  This is different from IDL where the
    color table is loaded into the IDL system memory.

    Positional Argument(s):
    * *in_args[0]:  VCS canvas object for which to set the color map 
      for.  Altered by procedure.
    * *in_args[1]:  Index of the color map to set as the active color
      map for the VCS canvas.  Scalar integer.  The following values 
      are accepted:
        0:   Black-white linear.
        1:   Blue-white linear:  Dark blue to white.
        11:  Blue-red 1:  Dark to light blue, then light to dark red; 
             blue is color indices 16-127, red is 128-239.
        13:  Rainbow (violet to red, 390-680 nm).
        43:  Red-white linear:  Dark red to white.
        53:  Rainbow (red to violet, 680-390 nm).
        99:  CDAT default color map.

    Keyword Argument (from **in_kwds):
    * verbose:  If 1, information messages are printed to stdout.  If
      0, all informational messages are suppressed.  Default is 1.

    The description of the above colormaps applies to color indices
    16 to 239, inclusive.  If *in_args is no argument, this procedure 
    prints out the list of available color maps and their index values.  
    Pictures of some of these color maps are at:
        http://www.johnny-lin.com/cdat_tips/tips_color/new_cm.html.
        http://www.johnny-lin.com/cdat_tips/tips_color/predef_cm.html

    Output:
    * Argument *in_args[0] is changed and returned, with the color map
      specified by *in_args[1] as the active color map.  The map is 
      named the string specified by variable loadct_cmap_name.

    Syntax of method call is based on IDL conventions.  However, values 
    are set to my personal preferences.

    Examples:
    (1) Importing:
        from IaGraph.loadct import loadct
    (2) Prints available color tables:
        loadct()                 
    (3) Loads black-white linear as the active color map in VCS canvas 
        v:
        loadct(v, 0)
    (4) Loads black-white linear as the active color map in VCS canvas 
        v, and informational messages are not printed:
        loadct(v, 0, verbose=0)  
    """




#----------------- Check and Manipulate Input Argument -----------------
#
# Based on the value of the input argument(s), we create variable
# cmap_index to use in selecting the color maps defined herein and 
# set the VCS canvas variable.  Set the verbose flag depending on
# whether there are keyword entries; default to 1:

    if len(in_args) == 0:
        cmap_index = None
    elif len(in_args) == 2:
        v          = in_args[0]
        cmap_index = in_args[1]
    else:
        raise ValueError, "loadct:  Bad number input arguments"

    if (type(cmap_index) != type(1)) and \
       (type(cmap_index) != type(1L)) and \
       (cmap_index != None):
        raise TypeError, "loadct:  Bad input argument type"

    if len(in_kwds) != 0:
        verbose = in_kwds['verbose']
    else:
        verbose = 1




#------------------------- Define My Color Map -------------------------
#
# The name of the procedure's cmap is made unique by a 10-digit number 
# translation of the number of seconds since the last epoch.  This 
# provides a way of giving a unique name to the color map that is 
# guaranteed to be unique if the procedure is called again no sooner 
# than 1 sec and no later than ~100 days from the current call.  Note 
# if there is no input argument there's no need to define a color map.

    if cmap_index != None:
        import time
        loadct_cmap_name = 'cmap' \
                        + ('%.2f' % time.time())[-11:].replace('.','')
        loadct_cmap = v.createcolormap(loadct_cmap_name, 'default')




#---------------------- List Available Color Maps ----------------------

    if cmap_index == None:
        if verbose:
            print "loadct:  Available color maps:"
            print " 0:   Black-white linear"
            print " 1:   Blue-white:  Dark blue to white."
            print " 11:  Blue-red 1:  Dark to light blue, then light to dark" 
            print "      red; blue is color indices 16-127, red is 128-239."
            print " 13:  Rainbow (violet to red, 390-680 nm)"
            print " 43:  Red-white:  Dark red to white."
            print " 53:  Rainbow (red to violet, 680-390 nm)"
            print " 99:  CDAT default color map."




#------------------------ Black-White Color Map ------------------------

    elif cmap_index == 0:
        if verbose:  print "loadct:  Loading black-white color map"
        for i in range(16,240):
            rvalue = int( float(i-16)/(239.-16.) * 100. )
            gvalue = rvalue
            bvalue = rvalue
            loadct_cmap.index[i] = [rvalue, gvalue, bvalue]




#------------------------ Blue-White Color Map -------------------------

    elif cmap_index == 1:
        if verbose:  print "loadct:  Loading blue-white color map"
        for i in range(16,240):
            rvalue = int( float(i-16)/(239.-16.) * 100. )
            gvalue = rvalue
            bvalue = 100
            loadct_cmap.index[i] = [rvalue, gvalue, bvalue]




#------------------------- Blue-Red 1 Color Map ------------------------

    elif cmap_index == 11:
        if verbose:  print "loadct:  Loading blue-red 1 color map"
        for icell in range(16,128):
            rvalue = int( float(icell-16)/(127.-16.) * 75. )
            gvalue = rvalue
            bvalue = 100
            loadct_cmap.index[icell] = [rvalue, gvalue, bvalue]
        for icell in range(128,240):
            rvalue = 100
            gvalue = 75 - int( float(icell-128)/(239.-128.) * 75. )
            bvalue = gvalue
            loadct_cmap.index[icell] = [rvalue, gvalue, bvalue]




#------------------------ Rainbow Color Map (13) -----------------------
#
# Make a list of evenly spaced wavelengths from 390-680 nm.  Compute 
# RGB values and fill the loadct_cmap.index dictionary for color
# indices 16 to 239.

    elif cmap_index == 13:
        if verbose:  print "loadct:  Loading rainbow (violet to red) color map"
        import vcs
        from wavelen2rgb import wavelen2rgb
        wavelengths = vcs.mkevenlevels(390,680,240-16-1)
        for i in range(16,240):
            loadct_cmap.index[i] = wavelen2rgb(wavelengths[i-16])




#------------------------ Rainbow Color Map (53) -----------------------
#
# Make a list of evenly spaced wavelengths from 390-680 nm, then 
# reverse it.  Compute RGB values and fill the loadct_cmap.index 
# dictionary for color indices 16 to 239.

    elif cmap_index == 53:
        if verbose:  print "loadct:  Loading rainbow (red to violet) color map"
        import vcs
        from wavelen2rgb import wavelen2rgb
        wavelengths = vcs.mkevenlevels(390,680,240-16-1)
        wavelengths.reverse()
        for i in range(16,240):
            loadct_cmap.index[i] = wavelen2rgb(wavelengths[i-16])




#------------------------- Red-White Color Map -------------------------

    elif cmap_index == 43:
        if verbose:  print "loadct:  Loading red-white color map"
        for i in range(16,240):
            rvalue = 100
            gvalue = int( float(i-16)/(239.-16.) * 100. )
            bvalue = gvalue
            loadct_cmap.index[i] = [rvalue, gvalue, bvalue]




#-------------------------- Default Color Map --------------------------

    elif cmap_index == 99:
        if verbose:  print "loadct:  Loading default color map"




#------------------ Catch Bad Color Map Input Indices ------------------

    else:
        raise ValueError, "loadct:  Bad input color map index"




#----- Activate Custom Color Map and Update active_Canvas Variable -----
#
# This section is activated only if cmap_index is not equal to None.

    if cmap_index != None:
        v.setcolormap(loadct_cmap_name)




#-------------------------- Main:  Test Module -------------------------

#- Define additional examples for doctest to use:

__test__ = { 'Additional Example 1':
    """
    >>> from loadct import loadct
    >>> loadct()
    loadct:  Available color maps:
     0:   Black-white linear
     1:   Blue-white:  Dark blue to white.
     11:  Blue-red 1:  Dark to light blue, then light to dark
          red; blue is color indices 16-127, red is 128-239.
     13:  Rainbow (violet to red, 390-680 nm)
     43:  Red-white:  Dark red to white.
     53:  Rainbow (red to violet, 680-390 nm)
     99:  CDAT default color map.
    >>> loadct(verbose=0)
    >>> import vcs
    >>> v = vcs.init()
    >>> loadct(v, 0)
    loadct:  Loading black-white color map
    >>> loadct(v, 0, verbose=0)
    >>> loadct(v, 11)
    loadct:  Loading blue-red 1 color map
    >>> loadct(v, 11, verbose=0)
    """ }


#- Execute doctest if module is run from command line:

if __name__ == "__main__":
    """Test the module.

    Tests the examples in all the module documentation strings, plus 
    __test__.

    The parent directory to the current directory is added to sys.path 
    for this module testing case to enable doctest to work on more 
    cases.
    """
    import doctest, sys, os
    sys.path.append(os.pardir)
    doctest.testmod(sys.modules[__name__])




# ===== end file =====

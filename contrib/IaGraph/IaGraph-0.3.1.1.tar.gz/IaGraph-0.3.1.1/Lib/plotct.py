#!/usr/bin/python -tt
#=======================================================================
#                        General Documentation

"""Single-procedure module.

   See procedure docstring for description.
"""

#-----------------------------------------------------------------------
#                       Additional Documentation
#
# RCS Revision Code:
#   $Id: plotct.py,v 1.2 2004/04/30 01:48:56 jlin Exp $
#
# Modification History:
# - 18 Dec 2003:  Original by Johnny Lin, Computation Institute,
#   University of Chicago.  Passed barely minimally passably 
#   reasonable tests.
# - 24 Dec 2003:  Make VCS object names "unique".  Passed barely 
#   minimally passably reasonable tests.
#
# Notes:
# - Written for Python 2.2.
# - For dependencies see the import statements throughout the file.
#
# Copyright (c) 2003 by Johnny Lin.  For licensing, distribution 
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/py_pkgs/IaGraph/.
#=======================================================================




#---------------- Module General Import and Declarations ---------------

#- Set package version number:

import IaGraph_version
__version__ = IaGraph_version.version
del IaGraph_version




#------------------------------- Function ------------------------------

def plotct( ctindex ):
    """Plot color table.

    Plots a color table given by a loadct index onto the active canvas.  
    Any previously existing plot in the active canvas is overwritten
    and replaced.  Color indices 0 to 255 are shown of the color table.
    The numbers on the axis of the color table refer to the color 
    index; color index 0 is the color shown on the color table from 
    x-axis value 0 to 1, color index 1 is the color shown from x-axis 
    value 1 to 2, etc.

    Method Argument:
    * ctindex:  Index of color table to plot, keyed into the values
      used by procedure loadct.  To see a list of all available 
      values, use the command IaGraph.loadct.loadct().

    Output:
    * Plot of color table on screen.
    * The active_canvas system variable in IaGraph.Sysvar is set to
      the canvas (overwritten if a previous canvas exists) that is 
      drawn by this procedure.  This allows other procedures in 
      IaGraph to operate on the canvas outside of the IaGraph.plotct
      procedure.

    Example to plot rainbow color table (violet to red, 390-680 nm),
    then dump plot to Postscript file plot.ps:
      import IaGraph
      from IaGraph.plotct import plotct
      plotct(13)
      active2ps('plot.ps')
    """


    #- Import modules and set system variable object:

    import Numeric as N
    import cdms, vcs
    import IaGraph
    from IaGraph.loadct import loadct
    import time

    sysvar = IaGraph.Sysvar()


    #- Data:  Color indices:

    x = N.arange(257)
    y = N.array([0,1])
    data = N.array([range(257), range(257)])


    #- Open VCS canvas window (first closing and reseting any pre-
    #  existing active canvas):

    if sysvar.__class__.active_canvas != []:
        sysvar.__class__.active_canvas.clear()
        v = sysvar.__class__.active_canvas
    else:
        v = vcs.init()


    #- Make unique string based on system time.  This provides a way 
    #  of giving a unique name to VCS objects that is guaranteed to 
    #  be unique if the procedure is called again no sooner than 1 
    #  sec and no later than ~100 days from the current call:

    uniq_str = ('%.2f' % time.time())[-11:].replace('.','')


    #- Create x vs. y graphics method object and template:

    my_fill_gm = v.createisofill('fillgm'+uniq_str, 'default')
    my_fill_tpl = v.createtemplate('filltp'+uniq_str, 'default')


    #- Create my own colormap and set the cell colors in that map:

    loadct(v, ctindex, verbose=0)


    #- Set coordinates (normalized units) for lower-left and upper-
    #  right bounding box (bbll*, bbur*); set tick labels font height 
    #  (ticklabel_fontht); set length of tick marks (in normalized 
    #  units):

    bbllx = 0.2
    bblly = 0.3
    bburx = 0.8
    bbury = 0.37
    ticklabel_fontht = 15
    ticklength = 0.01


    #- Set font to use for the ticklabels (ticklabel_font):

    ticklabel_font = 1


    #- Set conversion factor to multiply font height coordinates by
    #  to obtain the value in normalized coordinates:

    fontht2norm = sysvar.__class__.p_fontht2norm[0]


    #- Create text-table and text-orientation objects for x- and 
    #  y-axis tick labels and using them set font and font height.
    #  Also set y-axis tick labels to be vertically aligned at the
    #  mid-way point:

    ttab_xticklabel = v.createtexttable('ttxtic'+uniq_str, 'default')
    tori_xticklabel = v.createtextorientation('toxtic'+uniq_str, 'defcenter')
    tori_xname      = v.createtextorientation('toxnam'+uniq_str, 'default')

    ttab_xticklabel.font = ticklabel_font
    ttab_xticklabel.color = 241
    tori_xticklabel.height = ticklabel_fontht
    tori_xname.height = ticklabel_fontht
    tori_xname.halign = 'center'


    #- Turn off some default titling fields:

    my_fill_tpl.xname.priority = my_fill_tpl.yname.priority = 0
    my_fill_tpl.max.priority = my_fill_tpl.min.priority = 0
    my_fill_tpl.mean.priority = 0


    #- Set position of data field, plot box, and x-axis bottom ticks 
    #  and labels; set text-table and text-orientation of x-axis bottom 
    #  labels; turn off upper-right set of tick labels:

    my_fill_tpl.data.x1 = my_fill_tpl.box1.x1 = bbllx
    my_fill_tpl.data.y1 = my_fill_tpl.box1.y1 = bblly
    my_fill_tpl.data.x2 = my_fill_tpl.box1.x2 = bburx
    my_fill_tpl.data.y2 = my_fill_tpl.box1.y2 = bbury

    my_fill_tpl.xname.x = (bburx-bbllx)/2.0 + bbllx
    my_fill_tpl.xname.y = bblly - ticklength \
                        - ( 4 * ticklabel_fontht * fontht2norm )
    my_fill_tpl.xname.textorientation = tori_xname

    my_fill_tpl.xtic1.y1 = bblly - ticklength
    my_fill_tpl.xtic1.y2 = bblly
    my_fill_tpl.xlabel1.y = bblly - (2.8 * ticklength)
    my_fill_tpl.xlabel1.texttable = ttab_xticklabel
    my_fill_tpl.xlabel1.textorientation = tori_xticklabel

    my_fill_tpl.xlabel1.priority = 1
    my_fill_tpl.ylabel1.priority = 0
    my_fill_tpl.xtic1.priority = 1
    my_fill_tpl.ytic1.priority = 0
    my_fill_tpl.xtic2.priority = 0
    my_fill_tpl.ytic2.priority = 0
    my_fill_tpl.legend.priority = 0


    #- Create "nice" x-axis labels and set them into the graphics
    #  method:

    my_fill_gm.xticlabels1 = vcs.mklabels( [0,16,50,100,150,200,240,255] )


    #- Calculate and set filled-contour levels:

    my_min = min(N.ravel(data))
    my_max = max(N.ravel(data))
    my_fill_gm.levels = range(257)
    my_fill_gm.fillareacolors = range(256)


    #- Create x and y axis:

    xAxis = cdms.createAxis(x[:])
    yAxis = cdms.createAxis(y[:])


    #- Render plot, plot overall title, x-axis title, and y-axis title:

    v.plot( data, my_fill_gm, my_fill_tpl, xaxis=xAxis, yaxis=yAxis \
          , xname='Color Index', name=' ' )


    #- Set active_canvas in system variables object:

    sysvar.__class__.active_canvas = v
    del v




# ===== end file =====

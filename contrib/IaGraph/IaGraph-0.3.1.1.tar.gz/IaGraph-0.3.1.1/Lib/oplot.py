#!/usr/bin/python -tt
#=======================================================================
#                        General Documentation

"""Single-procedure module.

   See procedure docstring for description.
"""

#-----------------------------------------------------------------------
#                       Additional Documentation
#
# RCS Revision Code:
#   $Id: oplot.py,v 1.1 2004/02/20 21:49:49 jlin Exp $
#
# Modification History:
# - 20 Jan 2004:  Orig. by Johnny Lin, Computation Institute,
#   University of Chicago.  Passed minimally passably reasonable 
#   tests.
#
# Notes:
# - Written for Python 2.2.
# - For list of dependencies see import statement placed throughout
#   the file.
#
# Copyright (c) 2004 by Johnny Lin.  For licensing, distribution 
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/py_pkgs/IaGraph/.
#=======================================================================




#---------------- Module General Import and Declarations ---------------

#- Set package version number:

import IaGraph_version
__version__ = IaGraph_version.version
del IaGraph_version




#------------------------ Procedure Declaration ------------------------

def oplot( x_in, y_in  \
         , linestyle=None \
         , psym=None  \
         , symht=7 \
         ):
    """Interactively add an overlay x-y plot.

    Overplots an x-y line plot onto a pre-existing plot on the active 
    VCS canvas.  Syntax of method call, and symbol and linestyle codes, 
    are based on IDL conventions.  However, defaults for input
    parameters are set to my personal preferences, not IDL defaults.
    Default overplot has square plot symbols connected by a solid line
    (unless the system variables have settings different than their 
    default).


    Input Arguments:
    * x_in:  Vector of independent (x-axis) variable values.  Numeric,
      MA, or MV array.

    * y_in:  Vector of dependent (y-axis) variable values.  Numeric, 
      MA, or MV array.

    NB:  If an input argument is MV, only the MA portion of the
    variable is used; this procedure does not read the additional
    attributes of the MV class.


    Keyword Inputs:
    * linestyle:  Line style code for connecting lines.  Default set 
      to IaGraph.Sysvar.__class__.p_linestyle.  Integer.  Key to 
      values:
        0:  Solid line
        1:  Dotted
        2:  Dashed
        3:  Dash dot
        5:  Long dashes
      Note:  linestyle cannot equal 4; in IDL that corresponds to
      dash-dot-dot, which is not a default defined linetype in VCS.

    * psym:  Symbol code.  Default set to IaGraph.Sysvar.__class__.
      p_psym.  Integer.  Negative values plot both symbol and line.  
      Key to values:
        0:  No symbol
        1:  Plus sign
        2:  Asterisk
        3:  Period, circle, or dot
        4:  Diamond
        5:  Triangle
        6:  Square
        7:  X
      If psym is less than 0, the symbol and connecting lines are 
      plotted.  If psym is greater than 0, the symbol without connec-
      ting lines are plotted.  If psym is 0, lines without symbols 
      are plotted.

    * symht:  Plot symbol height.  Integer scalar.  Arbitrary units,
      with range of 1 to 300.  Default is 7 (which gives a square with
      an on screen size of approximately 2 mm).


    Output:
    * Overplots x-y plot of data on screen on the active canvas.
    * Unlike the plot command, oplot uses only VCS as its supported
      graphics package.


    Example to plot a plus sign for symbol, connecting solid lines, 
    and overplot the center part of the curve shifted by 90 deg (and 
    with 1/2 the amplitude), with square symbol and no connecting 
    lines:
      import Numeric
      from plot import plot
      from oplot import oplot
      x1 = Numeric.arange(50.)/Numeric.pi
      x2 = Numeric.arange(15.,35.)/Numeric.pi
      y1 = Numeric.sin(x1)
      y2 = 0.5*Numeric.sin(x2-(Numeric.pi/2.))
      plot(x1, y1, psym=-1)
      oplot(x2, y2, psym=6)
    """




#--------------------------- Global Imports ----------------------------

    import MA
    import Numeric as N
    import time




#---------- Create x and y from Input and Establish Settings -----------

    #- Vectors x and y are equivalent to the input vectors:

    x = MA.masked_array(x_in)
    y = MA.masked_array(y_in)


    #- Set system variable object and set line style and plot symbol:
    
    import IaGraph
    sysvar = IaGraph.Sysvar()

    if linestyle == None:  linestyle = sysvar.__class__.p_linestyle
    if psym == None:       psym = sysvar.__class__.p_psym




#------------------------- Global Error Check --------------------------

    if len(x) != len(y):
        raise ValueError, "oplot:  Bad input vector lengths"




#--------------------------- Plot Using CDAT ---------------------------

    #- Set plot symbols and linestyles (key:value corresponds
    #  to IDL code:VCS code):

    symbols = sysvar.__class__.symbols
    linetypes = sysvar.__class__.linetypes


    #- Open VCS canvas to active canvas:

    if sysvar.__class__.active_canvas == []:
        raise ValueError, "oplot:  No pre-existing canvas"
    v = sysvar.__class__.active_canvas


    #- Make unique string based on system time.  This provides 
    #  a way of giving a unique name to VCS objects that is 
    #  guaranteed to be unique if the procedure is called again 
    #  no sooner than 1 sec and no later than ~100 days from 
    #  the current call:

    uniq_str = ('%.2f' % time.time())[-11:].replace('.','')


    #- Create x vs. y plot graphics method object (depending on
    #  whether the base method was xvsy, isofill, or isoline) and 
    #  template.  Create a scatter method if the overplot has no 
    #  connecting lines, otherwise create an xvsy method.  Transfer 
    #  applicable settings from base method to overplot x vs. y 
    #  method:

    if sysvar.__class__.active_canvas_base_gm[0:4] == 'xygm':
        temp_gm = v.getxvsy( sysvar.__class__.active_canvas_base_gm )
    elif sysvar.__class__.active_canvas_base_gm[0:4] == 'fill':
        temp_gm = v.getisofill( sysvar.__class__.active_canvas_base_gm )
    elif sysvar.__class__.active_canvas_base_gm[0:4] == 'line':
        temp_gm = v.getisoline( sysvar.__class__.active_canvas_base_gm )
    else:
        raise ValueError, "oplot:  Bad base graphics method"

    if psym > 0:
        xy_gm = v.createscatter( 'xygm'+uniq_str, 'default' )
    else:
        xy_gm = v.createxvsy( 'xygm'+uniq_str, 'default' )

    xy_gm.xticlabels1 = temp_gm.xticlabels1
    xy_gm.yticlabels1 = temp_gm.yticlabels1
    xy_gm.datawc_x1   = temp_gm.datawc_x1
    xy_gm.datawc_x2   = temp_gm.datawc_x2
    xy_gm.datawc_y1   = temp_gm.datawc_y1
    xy_gm.datawc_y2   = temp_gm.datawc_y2
    del temp_gm

    my_tpl = v.createtemplate( 'mytpl'+uniq_str \
                             , sysvar.__class__.active_canvas_base_tpl )


    #- Set plot symbol, symbol size, and linestyle:

    try:
        xy_gm.marker = symbols[abs(psym)]
    except KeyError:
        print "oplot:  VCS lacks chosen psym - using square"
        xy_gm.marker = symbols[6]
    xy_gm.markersize = symht


    if psym <= 0:
        try:
            xy_gm.line = linetypes[linestyle]
        except KeyError:
            print "oplot:  VCS lacks chosen linestyle - using solid"
            xy_gm.line = linetypes[0]


    #- Turn off all template labeling for the overplot that might be 
    #  turned on from plot or contour:

    my_tpl.legend.priority      = 0
    my_tpl.file.priority        = my_tpl.function.priority       = 0
    my_tpl.logicalmask.priority = my_tpl.transformation.priority = 0
    my_tpl.source.priority      = my_tpl.units.priority          = 0
    my_tpl.crdate.priority      = my_tpl.crtime.priority         = 0
    my_tpl.title.priority       = my_tpl.dataname.priority       = 0
    my_tpl.box1.priority        = my_tpl.box2.priority           = 0
    my_tpl.box3.priority        = my_tpl.box4.priority           = 0
    my_tpl.line1.priority       = my_tpl.line2.priority          = 0
    my_tpl.line3.priority       = my_tpl.line4.priority          = 0
    my_tpl.xlabel1.priority     = my_tpl.ylabel1.priority        = 0
    my_tpl.xlabel2.priority     = my_tpl.ylabel2.priority        = 0
    my_tpl.xmintic1.priority    = my_tpl.ymintic1.priority       = 0
    my_tpl.xmintic2.priority    = my_tpl.ymintic2.priority       = 0
    my_tpl.xtic1.priority       = my_tpl.ytic1.priority          = 0
    my_tpl.xtic2.priority       = my_tpl.ytic2.priority          = 0
    my_tpl.xname.priority       = my_tpl.yname.priority          = 0
    my_tpl.zname.priority       = my_tpl.tname.priority          = 0
    my_tpl.xunits.priority      = my_tpl.yunits.priority         = 0
    my_tpl.zunits.priority      = my_tpl.tunits.priority         = 0
    my_tpl.xvalue.priority      = my_tpl.yvalue.priority         = 0
    my_tpl.zvalue.priority      = my_tpl.tvalue.priority         = 0
    my_tpl.comment1.priority    = my_tpl.comment2.priority       = 0
    my_tpl.comment3.priority    = my_tpl.comment4.priority       = 0


    #- Render plot:

    v.plot( x, y, xy_gm, my_tpl )


    #- Update active_canvas in system variables object:

    sysvar.__class__.active_canvas = v
    del v




# ===== end file =====

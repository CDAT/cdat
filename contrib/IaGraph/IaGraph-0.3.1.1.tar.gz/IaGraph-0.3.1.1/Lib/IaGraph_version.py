#!/usr/bin/python -tt
#=======================================================================
#                        General Documentation

"""Version number for package IaGraph.
"""

#-----------------------------------------------------------------------
#                       Additional Documentation
#
# RCS Revision Code:
#   $Id: IaGraph_version.py,v 1.5 2004/06/02 21:38:41 jlin Exp $
#
# Modification History:
# - 16 Feb 2004:  Original by Johnny Lin, Computation Institute,
#   University of Chicago.  Passed passably reasonable tests.
#
# Notes:
# - Written for Python 2.2.
# - No import statements in module.
#
# Copyright (c) 2004 by Johnny Lin.  For licensing, distribution 
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/py_pkgs/IaGraph/Doc.
#=======================================================================

version = '0.3.1.1'
author  = 'Johnny Lin <http://www.johnny-lin.com/>'
date    = '2 Jun 2004'
credits = ''




# ===== end file =====

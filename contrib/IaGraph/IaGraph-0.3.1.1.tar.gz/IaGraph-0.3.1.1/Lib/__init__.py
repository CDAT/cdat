#!/usr/bin/python -tt
#=======================================================================
#                        General Documentation

"""Interactive graphing procedures.

   Provide a package of basic plotting procedures to use for explora-
   tory data analysis (as opposed to publication quality graphics).
   The syntax is based upon IDL syntax and the procedures in this
   package are designed to be called in a single line.

   Key Package Procedures:
   * active2gif:  Output the active VCS canvas to GIF file.
   * active2ps:  Output the active VCS canvas to Postscript file.
   * contour:  2-D line and smooth filled contour plots to active
     VCS canvas, replacing any existing active canvas.
   * loadct:  Load additional predefined color tables.
   * ocontour:  Overplot contour plot.
   * oplot:  Overplot x-y line plot.
   * plot:  Make x-y line plot.  This procedure is able to construct
     the plot even if CDAT is not installed, though the output will
     not be available to write to hard-copy.  If CDAT is present, the
     plot is output to the active VCS canvas, replacing any existing
     active canvas.
   * plotct:  Plot a color table to the active VCS canvas, replacing 
     any existing active canvas.
   * window:  Sets the active canvas to a specified window number.
     The default active canvas is labeled window 0.

   Additional Package Helper Functions:
   * wavelen2rgb:  Returns the RGB values (for an arbitrary 0 to
     maximum intensity range) for visible light given the wavelength
     in nm.

   The package is written such that a single command "from IaGraph
   import *" will import all "key package procedures" in the package 
   by name.  Thus, the plot procedure will be available as "plot", 
   without specifying either module or package name.  The "helper
   functions" are not automatically imported; specify the full import 
   name (e.g. from IaGraph.wavelen2rgb import wavelen2rgb) in order 
   to use them.

   All modules in this package each only contain one function, and 
   the function name is the same as the module name.  Thus, the module 
   "plot" contains one procedure, also named "plot".
   
   Some useful online help commands for the package:
   * help(IaGraph):  Help for the package.  A list of all modules in 
     this package is found in the "Package Contents" section of the 
     help output.
   * help(IaGraph.M):  Details of each module "M", where "M" is the 
     module's name.  Examples on using each function is provided in
     the docstrings of the respective modules.
"""

#-----------------------------------------------------------------------
#                       Additional Documentation
#
# Package Name:
#   IaGraph
#
# RCS Revision Code:
#   $Id: __init__.py,v 1.1 2004/02/20 21:49:48 jlin Exp $
#
# Modification History:
# - 16 Dec 2003:  Orig. by Johnny Lin, Computation Institute,
#   University of Chicago.  Passed passably reasonable tests.
#
# Notes:
# - Written for Python 2.2.3.
# - For list of dependencies, see the import statements that are
#   found throughout the code.
#
# Copyright (c) 2003 by Johnny Lin.  For licensing, distribution 
# conditions, contact information, and additional documentation see
# URL http://www.johnny-lin.com/py_pkgs/IaGraph/.
#=======================================================================




#---------------- Module General Import and Declarations ---------------

#- Set package version number:

import IaGraph_version
__version__ = IaGraph_version.version
del IaGraph_version


#- List of modules in package and import all the key procedures in
#  the submodules so they are all available to the user with a single 
#  "from IaGraph import *" command.

__all__ = [ "active2gif", "active2ps", "contour", "loadct" \
          , "ocontour", "oplot", "plot", "plotct" \
          , "wavelen2rgb", "window" ]

import os, sys
sys.path.append(os.pardir)
from active2gif import active2gif
from active2ps import active2ps
from contour import contour
from loadct import loadct
from ocontour import ocontour
from oplot import oplot
from plot import plot
from plotct import plotct
from window import window




#--------------------------- System Variable ---------------------------

class Sysvar:
    """IaGraph system variable.

    The attributes of this class are "system" variables.  This allows
    us to keep canvas/plot settings for an entire Python session as
    well as initialize IaGraph plotting procedures.

    I try to make the names and content types of the class attributes
    to be similar to their identically named IDL counterparts.  Thus,
    p_psym is identical in value and function to !P.PSYM.  However,
    besides p_psym, p_linestyle, the functionality isn't precisely 
    duplicated (and in some cases, like p_font, entirely different)
    because of differences between IDL and VCS.  See the attribute
    description below for details.

    Class attributes:
    * active_canvas:  Set to the active VCS canvas.  Initialized to
      an empty list.
    * active_canvas_base_gm:  Name of the graphics method used to
      create the active canvas base plot (i.e. by plot, contour,
      etc.)
    * active_canvas_base_tpl:  Name of the template used to create 
      the active canvas base plot (i.e. by plot, contour, etc.)
    * active_canvas_num:  The window number of the active canvas.
      Initial value is 0.
    * inactive_canvases:  Dictionary of inactive canvases.  The key
      corresponds to the window number of the inactive canvas while
      the value is the canvas object.  Initialized to an empty dic-
      tionary.
    * inactive_canvases_base_gm:  Name of the graphics method used
      to create the base plot (i.e. by plot, contour, etc.) for each
      inactive canvas.
    * inactive_canvases_base_tpl:  Name of the template used to create 
      the base plot (i.e. by plot, contour, etc.) for each inactive
      canvas.
    * linetypes:  Dictionary of linestyles (key:value corresponds to 
      IDL code:VCS code).
    * symbols:  Dictionary of symbols (key:value corresponds to IDL 
      code:VCS code).
    * p_font:  VCS font code for title.
    * p_fontht:  Character size for titles.  In VCS font height units.
    * p_fontht2norm:  Conversion factor to multiply font height
      coordinates by to obtain the value in normalized coordinates.  
      This is obtained by trial-and-error.  1-element tuple (to help
      prevent it from ever changing).
    * p_linestyle:  Line style (value follows the IDL linestyle code,
      though not all IaGraph routines support all IDL linestyle codes;
      see each routine for details as to which values are supported).
      Same as the linestyle keyword.
    * p_maxnlev:  For contour plots, this is the maximum number of
      level intervals that will be allowed, when contour levels are 
      automatically calculated instead of set through the c_levels 
      keyword.  Scalar integer.
    * p_position:  4-element list of [bbllx, bblly, bburx, bbury] of
      the bounding box (x,y) coordinates in normalized values.  The
      data origin is the lower-left corner, and the upper-right corner
      of the data box is the upper-right corner of position.  Same as
      the position keyword.
    * p_psym:  Symbol marker (value follows the IDL psym code, though
      not all IaGraph routines support all IDL psym codes; see each
      routine for details as to which values are supported).  Same as 
      the psym keyword.
    * p_ticklen:  Ticklengths, in normalized coordinate units.
    * [xy]_font:  Font code for [xy]-axis tick marks and title.
    * [xy]_fontht:  Character size for [xy]-axis tick marks and title.
      In VCS font height units.
    * [xy]_range:  The range of the [xy]-axis used to calculate "neat"
      tickmarks, from which the actual axis range is set.  Two-element
      list, where the first element is the minimum in the axis range
      and the second element is the maximum in the axis range.  Same
      as the [xy]range keyword.
    * [xy]_tickmaxnum:  Maximum number of [xy]-axis ticks.
    * [xy]_ticklen:  [xy]-axis ticklengths, in normalized coordinate 
      units.
    * [xy]_tickvalues:  If this is defined, this directly sets the 
      [xy]-axis tick values.  This is the form of a dictionary where
      the dictionary key is the tick marks' numerical value and the 
      dictionary value is a string labeling each tick mark.

    Note that system variables are not changed by keyword values in
    calling routines.  Thus, if you call contour with the position
    keyword, the p_position keyword is not changed.  However, in a
    plotting function, if a keyword is defined, it will always have
    precedence in that plotting function over its corresponding 
    system variable.

    All attributes of the class are class attributes, not system
    attributes.  This allows us to change, pass, and access these
    attributes across multiple instances of the class.
    """

    active_canvas = []
    active_canvas_base_gm = ''
    active_canvas_base_tpl = ''
    active_canvas_num = 0
    inactive_canvases = {}
    inactive_canvases_base_gm = {}
    inactive_canvases_base_tpl = {}
    linetypes = { 0:0, 1:2, 2:1, 3:3, 5:4 }
    symbols = { 0:None, 1:2, 2:3, 3:1, 4:6, 5:7, 6:11, 7:5 }

    p_font = 1
    p_fontht = 40
    p_fontht2norm = (0.0007,)
    p_linestyle = 0
    p_maxnlev = 16
    p_position = None
    p_psym = -6
    p_ticklen = 0.01

    x_font = 1
    x_fontht = 30
    x_range = None
    x_ticklen = p_ticklen
    x_tickmaxnum = 9
    x_tickvalues = None

    y_font = 1
    y_fontht = 30
    y_range = None
    y_ticklen = p_ticklen
    y_tickmaxnum = 9
    y_tickvalues = None


    def __init__(self):
        """Initialize instance attributes.

        There are no instance attributes to initialize.
        """




#-------------------------- Main:  Test Module -------------------------

#- Define additional examples for doctest to use:

__test__ = { 'Additional Example 1':
    """
    >>> import IaGraph
    >>> a = IaGraph.Sysvar()
    >>> a.__class__.x_font
    1
    """
    }


#- Execute doctest if module is run from command line:

if __name__ == "__main__":
    """Test the module.

    Tests the examples in all the module documentation strings, plus 
    __test__.  Parent directory added to path to make doctest more
    robust.
    """
    import doctest, sys, os
    sys.path.append(os.pardir)
    doctest.testmod(sys.modules[__name__])
    



# ===== end file =====

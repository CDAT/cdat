#=======================================================================
# Miscellaneous Tasks Examples
#
# Copyright (c) 2004 by Johnny Lin.  For licensing, distribution
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/py_pkgs/IaGraph/Doc/.
#=======================================================================


#- Import modules:

try:  execfile('/home/jlin/.pythonrc.py')
except:  print "eg_misc.py:  Ignore Johnny Lin's path settings."

import os
import Numeric as N
from IaGraph import *


#- Data:

x = N.arange(15) / N.pi
y = N.sin(x)


#- Examples (window command added so each plot occurs in its own
#  window):

sysvar = IaGraph.Sysvar()
sysvar.__class__.x_fontht = 10
sysvar.__class__.y_fontht = 10
sysvar.__class__.p_fontht = 80
sysvar.__class__.p_font = 2

window(0)
plot( x, y, psym=5, symht=14 \
    , xtitle='x', ytitle='sin(x)', title='My Plot' )
active2gif('IaG_eg_misc_img1.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_misc_img1.gif IaG_eg_misc_img1.jpg')

window(1)
plotct(13)
active2gif('IaG_eg_misc_img2.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_misc_img2.gif IaG_eg_misc_img2.jpg')




#====== end of file ======

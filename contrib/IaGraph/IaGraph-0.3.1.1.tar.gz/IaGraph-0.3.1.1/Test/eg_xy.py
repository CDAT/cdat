#=======================================================================
# X-Y Plot Examples
#
# Copyright (c) 2003-2004 by Johnny Lin.  For licensing, distribution
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/py_pkgs/IaGraph/Doc/.
#=======================================================================


#- Import modules:

try:  execfile('/home/jlin/.pythonrc.py')
except:  print "eg_xy.py:  Ignore Johnny Lin's path settings."

import os
import Numeric as N
from IaGraph import *


#- Data:

x = N.arange(15) / N.pi
y = N.sin(x)


#- Examples (window command added so each plot occurs in its own
#  window):

window(0)
plot(x, y)
active2gif('IaG_eg_xy_img1.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_xy_img1.gif IaG_eg_xy_img1.jpg')

window(1)
plot(x, y, psym=2, symht=14)
active2gif('IaG_eg_xy_img2.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_xy_img2.gif IaG_eg_xy_img2.jpg')

window(2)
plot( x, y, linestyle=5, xrange=[3, 4] \
    , title='Partial Plot', xtitle='x', ytitle='sin(x)' \
    , annot='This is my plot.\nBy Johnny Lin\n\n' \
           +'University of Chicago\nClimate Systems Center\n' \
           +'December 2003' )
active2gif('IaG_eg_xy_img3.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_xy_img3.gif IaG_eg_xy_img3.jpg')




#====== end of file ======

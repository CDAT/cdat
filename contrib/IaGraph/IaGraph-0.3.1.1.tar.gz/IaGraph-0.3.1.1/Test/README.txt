README FILE
By Johnny Lin


This directory contains example Python scripts to create the example
plots on the IaGraph web pages, found in ../Doc/imgs.  Thus these 
scripts function as unit tests.

Note that these scripts have two pieces of customization that you
need to be aware of if you're running them on your local system:

(1) The first line in each module execfile()s my .pythonrc.py in
    order to append my personal Python modules to the path.

(2) Because I want my example plots to be in JPEG format (to fulfill
    the conditions of the Gnu Free Documentation License), I use the
    ImageMagick Studio Unix command convert(1) to crop, add a black
    border, and use do the conversion.  If you don't have this program
    you'll have to comment out all the os.system calls in these scripts.

#=======================================================================
# Overplotting Examples
#
# Copyright (c) 2004 by Johnny Lin.  For licensing, distribution
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/py_pkgs/IaGraph/Doc/.
#=======================================================================


#- Import modules:

try:  execfile('/home/jlin/.pythonrc.py')
except:  print "eg_overplot.py:  Ignore Johnny Lin's path settings."

import os
import MA
import Numeric as N
from IaGraph import *


#- Data:

xd = N.arange(29) * 10.0
yd = N.arange(21) * 10.0 - 100.0
data = N.outerproduct( N.sin(yd*N.pi/360.), N.cos((xd-140.)*N.pi/360.))

xd1 = N.array([40, 50, 60, 70, 80, 90, 100])
yd1 = N.array([-20, 0, 20, 40, 60, 80])
data1 = N.outerproduct( N.sin(N.arange(6)/5.0*N.pi) \
                      , N.sin(N.arange(7)/6.0*N.pi) )
N.putmask(data1, N.where(N.absolute(data1) < 1e-10, 1, 0), 0.)

x1 = N.arange(30) * 5.0
y1 = 50.0 * N.sin(x1/(4.0*N.pi))
y1[13:16] = 1e+20
y1 = MA.masked_values(y1, 1e+20)

x2 = N.array([10,  40, 60, 89, 123, 160, 192])
y2 = N.array([-82, 21, -3, 34,  54,  31, -23])


#- Examples:

window(0)
plot(x1, y1, psym=0)
oplot(x2, y2, psym=5)
active2gif('IaG_eg_overplot_img1.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_overplot_img1.gif IaG_eg_overplot_img1.jpg')

window(1)
contour(data, xd, yd)
oplot(x2, y2, linestyle=3)
active2gif('IaG_eg_overplot_img2.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_overplot_img2.gif IaG_eg_overplot_img2.jpg')

window(0)
oplot(x2, -y2, psym=1)
active2gif('IaG_eg_overplot_img3.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_overplot_img3.gif IaG_eg_overplot_img3.jpg')

window(2)
contour(data, xd, yd)
ocontour(data1, xd1, yd1)
active2gif('IaG_eg_overplot_img4.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_overplot_img4.gif IaG_eg_overplot_img4.jpg')

window(3)
contour( data1, xd1, yd1, plottype='fill' \
       , xrange=[0,280], yrange=[-100,100] )
ocontour(data, xd, yd)
active2gif('IaG_eg_overplot_img5.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_overplot_img5.gif IaG_eg_overplot_img5.jpg')

window(4)
contour( data, xd, yd, plottype='line' \
       , xrange=[0,280], yrange=[-100,100] )
ocontour(data1, xd1, yd1, plottype='fill')
active2gif('IaG_eg_overplot_img6.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_overplot_img6.gif IaG_eg_overplot_img6.jpg')




#====== end of file ======

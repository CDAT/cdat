#=======================================================================
# Contour Plot Examples
#
# Copyright (c) 2003-2004 by Johnny Lin.  For licensing, distribution
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/py_pkgs/IaGraph/Doc/.
#=======================================================================


#- Import modules:

try:  execfile('/home/jlin/.pythonrc.py')
except:  print "eg_con.py:  Ignore Johnny Lin's path settings."

import os
import Numeric as N
from IaGraph import *


#- Data:

x = N.arange(29) * 10.0
y = N.arange(21) * 10.0 - 100.0
data = N.outerproduct( N.sin(y*N.pi/360.), N.cos((x-140.)*N.pi/360.))


#- Examples (window commands added so each plot appears in its own
#  window):

window(0)
contour(data, x, y)
active2gif('IaG_eg_con_img1.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_con_img1.gif IaG_eg_con_img1.jpg') 

window(1)
contour(data, x, y, plottype="line")
active2gif('IaG_eg_con_img2.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_con_img2.gif IaG_eg_con_img2.jpg') 

window(2)
contour(data, x, y, plottype="fill")
active2gif('IaG_eg_con_img3.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_con_img3.gif IaG_eg_con_img3.jpg') 

window(3)
contour( data, x, y \
   , title='My Plot', xtitle='X-Axis', ytitle='Y-Axis' \
   , c_levels=[-0.8, -0.4, -0.35, -0.3, 0.0, 0.2, 0.3, 0.5, 0.55, 0.9] )
active2gif('IaG_eg_con_img4.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_con_img4.gif IaG_eg_con_img4.jpg') 

window(4)
contour( data, x, y \
   , annot='This is my plot.\nBy Johnny Lin\n' \
          +'December 2003\n\n' \
          +'University of Chicago\nClimate Systems Center' \
   , title='My Plot', xtitle='X-Axis', ytitle='Y-Axis' \
   , ctindex=11, colorbar=0 )
active2gif('IaG_eg_con_img5.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_con_img5.gif IaG_eg_con_img5.jpg') 

window(5)
contour( data, x, y, xrange=[80,180], yrange=[-20,80] )
active2gif('IaG_eg_con_img6.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_con_img6.gif IaG_eg_con_img6.jpg') 




#====== end of file ======

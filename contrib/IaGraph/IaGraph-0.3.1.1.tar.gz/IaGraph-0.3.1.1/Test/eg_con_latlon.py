#=======================================================================
# Latitude-Longitude Contour Plot Examples
#
# Copyright (c) 2003-2004 by Johnny Lin.  For licensing, distribution
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/py_pkgs/IaGraph/Doc/.
#=======================================================================


#- Import modules:

try:  execfile('/home/jlin/.pythonrc.py')
except:  print "eg_con_latlon.py:  Ignore Johnny Lin's path settings."

import os
import Numeric as N
import IaGraph, MA
from IaGraph import *


#- Data (with missing values set to 1e+20):

lat = N.arange(13) * 15.0 - 90.0
lon = N.arange(25) * 15.0 - 180.0
data = N.outerproduct( N.sin(lat*N.pi/360.) \
                     , N.cos(lon*N.pi/360.) )
data[3:4,6:8] = 1e+20
data = MA.masked_values(data, 1e+20)


#- Set system variables for axes tick labels:

sysvar = IaGraph.Sysvar()
sysvar.__class__.x_tickvalues = \
    {-180:'180W', -90:'90W', 0:'0', 90:'90E', 180:'180E'}
sysvar.__class__.y_tickvalues = \
    {-90:'90S', -45:'45S', 0:'EQ', 45:'45N', 90:'90N'}


#- Examples (window command added so each plot occurs in its own
#  window):

window(0)
contour(data, lon, lat, continents=1)
active2gif('IaG_eg_con_latlon_img1.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_con_latlon_img1.gif IaG_eg_con_latlon_img1.jpg')

window(1)
contour( data, lon, lat \
       , ctindex=11 \
       , colorbar=0 \
       , title='Example Contour Plot' \
       , xtitle='Longitude [deg]',ytitle='Latitude [deg]' \
       , continents=1 )
active2gif('IaG_eg_con_latlon_img2.gif')
os.system('convert -verbose -trim -border 8x8 -bordercolor white ' \
         +'-mattecolor black -frame 2x2 ' \
         +'IaG_eg_con_latlon_img2.gif IaG_eg_con_latlon_img2.jpg')




#====== end of file ======

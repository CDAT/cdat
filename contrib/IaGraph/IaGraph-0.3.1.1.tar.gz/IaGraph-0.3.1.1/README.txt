README FILE
By Johnny Lin


-> SUMMARY:

A full description of this package is in ./Doc/index.html.  For the most 
up-to-date public documentation of this package, see:

   http://www.johnny-lin.com/py_pkgs/IaGraph/Doc/

The version of this package is given in module ./Lib/IaGraph_version.py.


-> CONTENTS OF THIS DIRECTORY:

README.txt   This file.

setup.py     Installation script.  See ./Doc/index.html for installation
             instructions.

./Doc        Documentation, including all HTML and CSS files.  To access 
             the front page of all documentation, open ./Doc/index.html 
             in a browser; links should properly access these local copies.  
             Some of these HTML files reference the Python source files 
             in the ./Lib directory as well as code in ./Test.  The *.html 
             files in this directory of the same name as the modules in 
             ./Lib are pydoc generated documentation of the package's 
             modules.  See ./Doc/index.html for details.

./Lib        Python source code.

./Src        Directory of C and Fortran source code.  Currently empty.

./Test       Directory of test scripts.


-> LICENSE:

A copy of the license this package is released under is found in the file 
./Doc/GNU_LGPL.txt.

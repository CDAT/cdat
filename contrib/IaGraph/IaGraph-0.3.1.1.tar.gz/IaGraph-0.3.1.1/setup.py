#- Imports:

from distutils.core import setup, Extension
import os


#- Read in the package version and author fields from the Python
#  source code IaGraph_version.py file:

execfile(os.curdir+os.sep+'Lib'+os.sep+'IaGraph_version.py')


#- Run setup:

setup (name = "IaGraph",
       version=version,
       author=author,
       description = "Package of interactive graphing tools",
       url = "http://www.johnny-lin.com/py_pkgs/IaGraph/Doc/",
       packages = ['IaGraph'],
       package_dir = {'IaGraph': 'Lib'},
##        ext_modules = [
##              Extension('genutil.array_indexing',
##                        ['Src/array_indexing.c',]
##                        )
##              ]
       )

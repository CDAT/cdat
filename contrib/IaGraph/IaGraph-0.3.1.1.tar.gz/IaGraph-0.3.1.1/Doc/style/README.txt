README FILE
By Johnny Lin


This directory contains the CSS files for the documentation in ../Doc.

imgs.css            Specifies where the images in the documentation
                    files are called from.  This file is either a copy
                    of imgs_local.css or imgs_hemulen.css.  As the user
                    you can set it to either one.  If you want the most
                    up-to-date image, make this a copy of the file
                    imgs_hemulen.css.  If you want the images to come
                    from your local computer (say you don't have an
                    Internet connection) make this a copy of the file
                    imgs_local.css.  Default is set to imgs_local.css.

imgs_local.css      Defines the DIV blocks that call the images.  Refer-
                    ences the local copies of the images at ../imgs.

imgs_hemulen.css    Defines the DIV blocks that call the images for the
                    documentation.  References the copies of the images
                    on the Internet at hemulen.uchicago.edu/~jlin/imgs.

libcode1.css        Base CSS settings.

import os, glob

# Gather up all the files we need.
## files = glob.glob("Src/*.f")
pyfiles = glob.glob("Lib/*.py")

## scypy_distutils Script
from distutils.core import setup, Extension

# Some useful directories.  
## from scipy_distutils.sysconfig import get_python_inc, get_python_lib

## python_incdir = os.path.join( get_python_inc(plat_specific=1) )
## python_libdir = os.path.join( get_python_lib(plat_specific=1) )

## Get package version info
version_file = os.path.join(os.curdir,"Lib","package_version.py")
execfile(version_file)

## Setup the python module
setup(name="ioapiTools",
      version=version,
      description=description,
      author=author,
      author_email=author_email,
      maintainer=author,
      maintainer_email=author_email,
      license="GNU GPL",
      
     ## Install these to their own directory
     ##extra_path = 'pyIoapi',
     package_dir={'ioapiTools':'Lib'},
     packages = ["ioapiTools"],
      
     )




#!/usr/bin/env python

## Version, author and other info for this package
version="0.3.2"
author="Alexis Zubrow"
author_email="azubrow@uchicago.edu"
description="High level python interface to IOAPI library"

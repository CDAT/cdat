#!/usr/bin/env python

####################################################################
##     Copyright (C) 2005 Alexis Zubrow
##
##     This program is free software; you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation; either version 2 of the License, or
##     (at your option) any later version.
##
##     This program is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
##
##     You should have received a copy of the GNU General Public License
##     along with this program; if not, write to the Free Software
##     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
####################################################################


"""
ioapiTools

    A series of tools that operate on ioapi files 

    Author:  Alexis Zubrow
"""


## Put pI before cdms.  When cdms has DODS
## support, importing cdms before pyIoapi
## creates a bunch of lncvarid warnings
import pyIoapi as pI
import cdms, cdtime, MV, cdutil
import Numeric as N
import gdal, osr
import os, sys, string, copy
from mx import DateTime as D
from string import atoi
from glob import glob


#############
## Some flags
#############

ll2projFlag = 1  ## Lon, Lat --> proj (meters)
ll2crFlag = 2    ## Lon, Lat --> col, row
proj2llFlag = 3  ## projection --> Lon, Lat (degrees)
proj2crFlag = 4  ## projection --> col, row
cr2llFlag = 5    ## col, row --> Lon, Lat (degrees)
cr2projFlag = 6  ## col, row --> projection (meters)

llFlag = 1      ## Lon, Lat flag
projFlag = 2    ## Native projection Flag
crFlag = 3      ## column row Flag

crossFlag = 1   ##   center of cell [Default]
SWFlag = 2      ##   Southwest corner of cell
SEFlag = 3      ##   Southeast corner of cell
NEFlag = 4      ##   Northeast corner of cell
NWFlag = 5      ##   Northwest corner of cell

grid2projFlag = 1   ## grid --> osr projection object
grid2mapFlag = 2    ## grid --> grid_map variable
map2gridFlag = 3    ## grid_map --> grid object

##Some flags for indicating how passing metadata
iofileFlag = 1
cffileFlag = 2
cdmsvarFlag = 3
byhandFlag = 4



## Parameters for conversion to IOAPI format metadata
## from IOAPI library PARMS3.EXT file
_IOnamelength = 16
_IOdesclength = 60
_IOmxvars = 120
_IOmxdesclines = 80
_IOmxlays = 100
_m3int = 4
_m3real = 5
_m3dble = 6
_IOwritenew = 3
_IOwriteupdate = 2

#----------------------------------------------------------------#
def isIOAPI(fileHandle):
    
    """
        Tests whether or not a file is in IO/API format.   All it does is check
        if the file has a global attribute IOAPI_VERSION.

        Input:
            fileHandle - a CdmsFile object, the return of cdms.open(fileName)

        Return:
             True  -   Is recognized as IO/API format.
             False -   Is not recognized as IO/API format

        Note:
           Internal Function.
    """
    ## See if cdms file object has a global attribute IOAPI_VERSION
    ## If it doesn't return False, otherwise assume it is a properly
    ## formatted IO/API file and return True

    try: fileHandle.IOAPI_VERSION
    except: return False

    return True

#----------------------------------------------------------------#
def isIOCDMS(fileHandle):
    
    """
        Tests whether or not a file is a CF netCDF w/ ioapi metadata.
        All it does is check if the file has:
              ioapi_meta variable
              grid_map variable

        Input:
            fileHandle - a CdmsFile object, the return of cdms.open(fileName)

        Return:
             True  -   Is recognized as CF netCDF w/ IOAPI metadata.
             False -   Is not recognized as CF netCDF w/ IOAPI metadata

        Note:
           Internal Function.
"""
    
    ## See if cdms file object has a variable called ioapi_meta
    ## If it doesn't return False


    try: ioapiCdms = fileHandle("ioapi_meta")
    except: return False

    ## See if the cdms file has an appropriate grid_mapping variable
    try: grid_map = fileHandle(ioapiCdms.grid_mapping)
    except: return False

    ## CF netCDF w/ ioapi metadata
    return True


    
#----------------------------------------------------------------#
class iofile(object):
    
    """ An iofile object is the object which retains file handles and
        provides methods for extracting and writing variables.

        Notes/Assumptions:
          1. Presently only tested for Lambert Conformal Conic projection.

          2. If instantiated via IO/API file, assumes that the spatial axes
             are regular, equally spaced.
             
        Revisions:

            8/25/2003 --  Alexis Zubrow -- Initial Version (iometa)
            3/25/2004 --  Alexis Zubrow -- Added iometa.vertcoords (iometa)
            4/13/2004 --  Alexis Zubrow -- Added iometa.xlon and ylat (iometa)
            6/25/2004 --  Alexis Zubrow -- Shifted to cctmTools, added
                                           cdms variable option.  Corrected
                                           x and y origin to clarify grid center
                                           and grid edge locations.
            1/10/2005 --  Alexis Zubrow -- Shifted to ioapiTools, made this
                                           file object.
    """
    
    def __init__(self, fileName = None, rwFlag = "r", typeFlag = cffileFlag,\
                 newM = None, logFile = None, llaxesFlag = False):
        
    
        """ Init
        

        Input:
               fileName  - Either a fileName for an IO/API file or a CF
                           complient netcdf file.

               rwFlag    - 'r' - read
                           'w' - write / overwrite

               typeFlag  - cffileFlag (default), write a cf netcdf file
                           iofileFlag, write an ioapi format file
                           (Only needed for writes, reading automatically
                           determines file type)

               newM      - tuple (ioM, cdmsM) describes the ioapi metadata
                           domain, and geographic projection of the data
                           for this file. This tuple is the return of
                           combineMeta.  Only needed for multiple writes
                           to ioapi format files (see Notes).

               logFile -   log file name. Used to store ioapi library
                           log info.  Default is None, display log
                           info in stdout.  If a file is indicated, it
                           will overwrite any previous file of that name.

               llaxesFlag- True - write out alternative lat and lon coordinates
                           False [default] - do not write out alternative
                                  coordinates
                        
        Notes/Assumptions:

           1.  If the file format is neither ioapi or cf compliant,
               but it is a netcdf file, it will raise an error.
               
           2.  If you are writing ioapi format and pass a logFile,
               the function sets up an environmental variable,
               LOGFILE.

           3.  If you are writing ioapi format file, the iofile
               object will setup an environmental variable for the
               output name.  The variable will be of the form,
               'OUTDDDDDDDDDD'.  This is needed for the ioapi
               library.

           4.  If you are writing to a file that already exists.
               the open command will print a warning and remove
               the file before writing.

           5.  Multiple writes and ioapi format. All the metadata
               for an ioapi file needs to be written in the
               beginning.  If you want to have multiple, seperate
               writes to the file, you need to open the file with
               the metadata for all the variables you plan to
               write to this file.  In order to do multiple
               writes, pass the newM parameter.  Here is an
               example of writing 3 variables:

                 >>> newM = ioapiTools.combineMeta([o3, nh3, co])
                 >>> f = ioapiTools.open('test.ioapi','w', newM, \
                                         ioapiTools.iofileFlag)
                 >>> f.write(nh3)
                 ...
                 >>> f.write([o3,co])
                 >>> f.close()

           6.  The llaxesFlag indicates whether or not to write out
               alternative coordinates, lat and lon.  This is only
               meaningful if you are writing to a CF netCDF file.
               These alternative coordinates are cdms variables in
               there own right.  They are both functions of yLat and
               xLon, e.g. lat(yLat,xLon).  To be truelly CF compliant,
               this flag should be on.  But, this slows down the write
               and may cause some programs to have problems displaying
               the data.  The values of lat are the latitude at each
               yLat,xLon grid point.  This basically translates the
               regular grid in the native projection to an irregular
               grid in degrees N,E.  It also creates a bounds_lon and
               bounds_lat variable, which correspond to the irregular
               corners of each grid cell.


        """

        ## set all the attributest to None
        self.setNone()

        if fileName is None:
            raise IOError, "Need to pass a file"

        fileName = os.path.expanduser(fileName)
        
        ## Reading a file
        if rwFlag == "r":

            ## Test if file exists, if it does open it
            if not os.path.isfile(fileName):
                raise IOError, "File %s does not exist" %fileName
            
            self.fileName = fileName
            self.f = cdms.open(self.fileName, "r")
            self.openFlag = True
            

            ## CF netCDF w/ iometa variable
            if isIOCDMS(self.f):

                self.typeFlag = cffileFlag

                ## Create an iometa object, contains
                ## IO/API specific info and projection info
                self.ioM = iometa(self)

                ## Create cdms metadata object
                ## duplicate storage, but used by dates2File
                self.cdmsM = cdmsmeta(self, cffileFlag)
                
            ## IO/API format
            else:

                ## If not CF file, assume ioapi file

                ## check if file has IOAPI_VERSION global attribute
                ## if not, print a warning but continue as if ioapi file
                try: self.f.IOAPI_VERSION
                except: print "Warning: %s not CF file \n" %(self.fileName) + \
                        "Testing ioapi format: \n" + \
                        "\t missing IOAPI_VERSION global attribute\n" + \
                        "Warning: assuming ioapi file, but additional missing global attributes \n" +\
                        "\tmay cause failure.  If it fails, try using cdms module.\n" 

                
                        
                self.typeFlag = iofileFlag
                
                self.parse()

                ## Create an iometa object, contains
                ## IO/API specific info and projection info
                self.ioM = iometa(self)
                
                ## Create cdms metadata object
                self.cdmsM = cdmsmeta(self)

                
            
            
            
        ## Writing file
        elif rwFlag == "w":

            self.typeFlag = typeFlag
            
            ## Test if file exists, if it does remove it
            if  os.path.isfile(fileName):
                print "Warning %s exists, will remove and overwrite it"\
                      %fileName
                os.remove(fileName)
            
            self.fileName = fileName

            ## CF netcdf
            if typeFlag == cffileFlag:

                ## Open a cdms file for writing
                self.f = cdms.open(self.fileName, "w")

                ## Set first write flag to true
                self.firstwriteFlag = True

                ## record lat lon axes flag
                self.llaxesFlag = llaxesFlag
                
            ## IOAPI format
            elif typeFlag == iofileFlag:
                ## Use the pyIoapi lowlevel package
                ## Basic idea is open a file for writing and
                ## write the metadata needed for ALL variables

                ## Test if log file exists, if so remove and give warning
                if logFile is not None:
                    logFile = os.path.expanduser(logFile)
                    if os.path.isfile(logFile):
                        print "Warning removing %s" %logFile
                        os.remove(logFile)

                    ## Create an environmental variable LOGFILE
                    ## used by pyIoapi to write log info from libioapi
                    os.environ["LOGFILE"] = logFile

                ## Run init 
                pI.init_ioapi()

                ## Create a new environmental variable for output file
                ## Make it unique by appending the present date/time:
                ## OUT_MMDDHHMMSS
                ## Needed by pyIoapi, max 16 characters
                nowD = D.now()
                self.outfile_env = "OUT_%d%d%d%d%d" \
                                   %(nowD.month,nowD.day, \
                                     nowD.hour, nowD.minute, nowD.second)
                
                os.environ[self.outfile_env] = fileName

                ## Only open a new file if ioM and cdmsM was passed
                if (newM is not None):

                    ## store ioM and cdmsM
                    self.ioM = newM[0]
                    self.cdmsM = newM[1]
                    

                    ## Populate the IOAPI metadata common block cdesc3 and bdesc3
                    self.populateCdesc3(pI.cdesc3)
                    self.populateBdesc3(pI.bdesc3)

                    ## Open the file for writing
                    status = pI.open_file(self.outfile_env, _IOwritenew)
                    if status == 0:
                        raise IOError, "IOAPI error opening file"
                    
                    ## Set flags, can do multiwrite, file exists don't have to create
                    self.multiwriteFlag = True
                    self.firstwriteFlag = False

                else:
                    ## Set flags, file does not exist, first write should create
                    self.multiwriteFlag = False
                    self.firstwriteFlag = True

                    
            

            else:
                raise KeyError, "File type flag must be for ioapi or cf compliant files"


            ## File is open for writing
            self.openFlag = True
            self.writeFlag = True

        ## Error
        else:
            raise KeyError, "rwFlag must be equal either 'r' or 'w'"
            
            
    ##--------------##
        
    def setNone(self):
        """
        sets all the attributest to None.  This should only be called in the
        __init__.  DO NOT call this directly, it will erase all the metadata.

        Note/Assumptions:
        
           1.  Internal function.  Should not be used by normal users.
        
        """

        ## Make sure all of your attributes are included in this, if add
        ## new attributes, make sure to add them here as well
        self.fileName = None
        self.f = None
        self.sdate = None
        self.stime = None
        self.times = None
        self.start = None
        self.end = None
        self.layers = None
        self.vertcoords = None
        self.vertType = None   #
        self.vertTop = None    #
        self.cols = None
        self.rows = None
        self.xcellSize = None
        self.ycellSize = None
        self.projectionName = None
        self.standparallel1 = None
        self.standparallel2 = None
        self.xcent = None
        self.ycent = None
        self.gridName = None
        self.gridType = None        #
        self.xunits = None
        self.yunits = None
        self.xedge = None
        self.yedge = None
        self.xorigCross = None
        self.yorigCross = None
        self.xlonLst = None
        self.ylatLst = None
        self.grid_map = None
        self.cdmsM = None  #
#        self.timeAxis = None
#        self.layAxis = None
#        self.xlonAxis = None
#        self.ylatAxis = None
        self.nthick = None    #
        self.ftype = None     #
        self.nvars = None     #
        self.vnameLst = None  #     
        self.vunitsLst = None #
        self.vdescLst = None  #
        self.vtypeLst = None  #
        self.fileDesc = None  #
        self.upname = None    #
        
        self.writeFlag = False #
        
    ##--------------##
        
    def parse(self):
        """
        Parses the IO/API metadata

        Note/Assumptions:
        
           1.  Internal function.  Should not be used by normal users.


        """

        ## General file and variable info:
        self.ftype = self.f.FTYPE.toscalar()
        self.nvars = self.f.NVARS.toscalar()
        self.fileDesc = self.f.FILEDESC.rstrip()
        self.upname = self.f.UPNAM.rstrip()
        self.vnameLst = self.f.listvariables()
        self.vnameLst.remove("TFLAG")   # remove tflag variable b/c not in ioapi metadata
        self.vunitsLst = [self.f.variables[varName].units.rstrip() \
                          for varName in self.vnameLst]
        self.vdescLst = [self.f.variables[varName].var_desc.rstrip() \
                          for varName in self.vnameLst]
        ## Assumes all variables type real,
        ## can change by hand later
        self.vtypeLst = N.ones(self.nvars) * _m3real
        
        ## projection info
        self.p_alp = self.f.P_ALP.toscalar()
        self.p_bet = self.f.P_BET.toscalar()
        self.p_gam = self.f.P_GAM.toscalar()
        self.xcent = self.f.XCENT.toscalar()
        self.ycent = self.f.YCENT.toscalar()
        self.gridName = self.f.GDNAM.rstrip()
        self.gridType = self.f.GDTYP.toscalar()

        ## domain info
        self.sdate = self.f.SDATE.toscalar()
        self.stime = self.f.STIME.toscalar()
        self.start = self.dateConv(self.sdate, self.stime)
        self.times = self.f.axes["TSTEP"].getData()
        self.tstep = self.f.TSTEP.toscalar()
        nhrs = self.tstep/10000.  ## nhrs in tstep
        self.end = self.start + (self.times[-1] * nhrs * D.oneHour)
        self.layers = self.f.axes["LAY"].getData()
        self.vertcoords = self.f.VGLVLS.tolist()  # coordinates of vertical layers
        self.vertType = self.f.VGTYP.toscalar()
        self.vertTop = self.f.VGTOP.toscalar()
        self.cols = self.f.axes["COL"].getData()
        self.rows = self.f.axes["ROW"].getData()
        self.xcellSize = self.f.XCELL.toscalar() 
        self.ycellSize = self.f.YCELL.toscalar() 
        self.nthick = self.f.NTHIK.toscalar()
        

        ## Get SW edge of domain
        ## lower left corner of domain in meters from
        ## projection center (xcent, ycent)
        ## This is SW corner of the 0,0 grid cell
        ## in projection units
        self.xedge = N.array((0,0), "f")
        self.yedge = N.array((0,0), "f")
        self.xedge[0] = self.f.XORIG.toscalar()
        self.yedge[0] = self.f.YORIG.toscalar()

        ## cross point origin, the location of the center
        ## of the 0,0 grid cell, in projection units
        self.xorigCross = self.xedge[0] + (0.5 * self.xcellSize)
        self.yorigCross = self.yedge[0] + (0.5 * self.ycellSize)

        ## xlon and ylat lists, axes coordinates in projection
        ## This is cross point, the center of the pixel
        self.xlonLst = self.xorigCross + (self.cols * self.xcellSize)
        self.ylatLst = self.yorigCross + (self.rows * self.ycellSize)

        ## Get NE edge of domain
        ## in projection units
        self.xedge[1] = self.xlonLst[-1] + (0.5 * self.xcellSize)
        self.yedge[1] = self.ylatLst[-1] + (0.5 * self.ycellSize)
        
        
    ##--------------##
        
    def dateConv(self, sdate, stime):
        """
            Takes SDATE and STIME and creates a DateTime object

            SDATE is the start date from the IO/API file.  It
            has the form YYYYDDD.  E.g. 1992045 is the 45th day
            of 1992.

            STIME is the start time.  It has the form HHMMSS, but
            only hour is taken into consideration by this function.
            E.g. 60000 is 6 am.

        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.

        """
        year = int(sdate/1000)
        hours = int(stime/10000)
        dayofyear = sdate - (year * 1000)
        origYear = D.DateTime(year)
        date = origYear + (dayofyear - 1) + hours*D.oneHour
        return date


    ##--------------##
        
    def extract(self, vname = None, capFlag = True):
        """
        Extracts a variable from ioFile and returns an iovar object.

        Input:
            vname - variable name, string

            capFlag - True, [default] automatically capitalize vname
                      False, do not capitalize vname

        Output:
            var  - iovar object

        Note:
        
            1.  The extract method is equivalent to making a call to
                the object.  For example, if the iofile object is 'f',
                then f.extract('o3') is equivalent to f('o3').

        """

        if vname is None:
            raise NameError, "Need to pass variable name"

        varName = vname
        if capFlag:
            ## Capitalize the variable name
            ## Most IO/API files have variables in caps
            varName = vname.upper()

        ## Get data from file and create a temporary cdms variable
        varTmp = self.f(varName)

        ## Create an iovar variable
        if self.typeFlag == iofileFlag:
            ## from ioapi file
            ioVar = createVariable(varTmp, self.ioM, self.cdmsM.getAxes())
        else:
            ## from CF netCDF file
            ioVar = createVariable(varTmp, self.ioM)

        return ioVar

        
    ##--------------##
        
    def __call__(self, vname, capFlag = True):
        """
        Extracts a variable.

        Input:
          vname - variable name

          capFlag - True [default] - automatically capitalize vname
                    False - do not capitalize

        Output:
          ioVar - iovar object
          
        """
        return self.extract(vname, capFlag)

    ##--------------##
        
    def __str__(self):

        if self.writeFlag:
            mode = "w"
        else:
            mode = "r"

        if self.openFlag:
            status = "open"
        else:
            status = "closed"

        if (self.typeFlag == iofileFlag):
            type = "ioapi"
        else:
            type = "CF netCDF"
            
        summaryStr = "<ioapiTools- file: %s, mode: '%s', format: %s, status: %s >" \
              %(self.fileName, mode, type, status) 

        return summaryStr

    ##--------------##
        
    def __repr__(self):
        return self.__str__()
    
    ##--------------##
        
    def populateBdesc3(self, bdesc3=None):
        """
        Populates the bdesc3 commonblock w/ data from
        iometa and cdmsmeta.  This is required to write to an IOAPI
        format file.
        
        Note/Assumptions:
           1.  Internal function.  Should generally not be used by
               normal users.

        """
        if bdesc3 is None:
            raise KeyError, "bdesc3 must be passed to function"

        if self.ioM is None:
            raise LookupError, "Metadata ioM must be set"

        if self.cdmsM is None:
            raise LookupError, "Metadata cdmsM must be set"
        
        ## Populate all the bdesc3 variables
        ## for some reason, the single value variables are actually arrays
        ## so assign to first element

        ## Easy ones are simply in ioM
        bdesc3.p_alp3d[0] = self.ioM.p_alp
        bdesc3.p_bet3d[0] = self.ioM.p_bet
        bdesc3.p_gam3d[0] = self.ioM.p_gam
        bdesc3.xcent3d[0] = self.ioM.xcent
        bdesc3.ycent3d[0] = self.ioM.ycent
        bdesc3.ftype3d[0] = self.ioM.ftype
        bdesc3.nthik3d[0] = self.ioM.nthick
        bdesc3.gdtyp3d[0] = self.ioM.gridType
        bdesc3.vgtyp3d[0] = self.ioM.vertType
        bdesc3.nvars3d[0] = self.ioM.nvars

        ## Construct these from cdms metadat
        ## X and Y values of the boundaries of the 0th cell
        bdesc3.xorig3d[0] = self.cdmsM.xlonAxis.getBounds()[0][0]
        bdesc3.yorig3d[0] = self.cdmsM.ylatAxis.getBounds()[0][0]

        ## cell size, difference b/w 2 cells position
        bdesc3.xcell3d[0] = self.cdmsM.xlonAxis.getValue()[1] - \
                            self.cdmsM.xlonAxis.getValue()[0]
        bdesc3.ycell3d[0] = self.cdmsM.ylatAxis.getValue()[1] - \
                            self.cdmsM.ylatAxis.getValue()[0]

        ## time
        sdate = dates2DateTime(self.cdmsM.timeAxis.asComponentTime()[0])
        date = sdate.year * 1000 + sdate.day_of_year
        time = sdate.hour*10000 + sdate.minute*100 + sdate.second
        if len(self.cdmsM.timeAxis) > 1:
            date2 = dates2DateTime(self.cdmsM.timeAxis.asComponentTime()[1])
            diff = date2 - sdate
            tstep = int(diff.hours) * 10000 + diff.minute*100 + diff.second
        else:
            ## only 1 date, so determine tstep based on units
            unit = self.cdmsM.timeAxis.units.split()[0]
            if unit == "days":
                tstep = 240000
            else:
                ## default to 1 hour
                tstep = 10000
        bdesc3.sdate3d[0] = date
        bdesc3.stime3d[0] = time
        bdesc3.tstep3d[0] = tstep
        bdesc3.mxrec3d[0] = len(self.cdmsM.timeAxis) # num timesteps

        ## Spatial Domain
        bdesc3.ncols3d[0] = len(self.cdmsM.xlonAxis)
        bdesc3.nrows3d[0] = len(self.cdmsM.ylatAxis)

        ## Vertical layers -- need to add vert coords to cdmsMeta!!
        bdesc3.nlays3d[0] = len(self.cdmsM.layAxis)
        bdesc3.vgtop3d[0] = self.ioM.vertTop
        sigmaLst = self.cdmsM.layAxis.getValue().tolist()
        ## add on last element of vertcoords bounds
        sigmaLst.append(self.cdmsM.layAxis.getBounds()[-1][1])   
        bdesc3.vglvs3d = self.padNumeric(sigmaLst, _IOmxlays + 1)

        ## Variable type
        bdesc3.vtype3d = self.padNumeric(self.ioM.vtypeLst, _IOmxvars, N.Int)
        

        ## store bdesc3
        self.bdesc3 = bdesc3
        
    ##--------------##
        
    def padNumeric(self, a, length = 0, type = N.Float):
        """
        Pads the end of a numeric array w/ zeros.

        Inputs:
              a  - Numeric array

              length - length of new array

              type - Numeric type
        Output:
              newArray  - array of size length.
              
        Note/Assumptions:
           1.  Internal function.  Should generally not be used by
               normal users.
        
        """
        newArray = N.zeros(length, type)
        newArray[0:len(a)] = a
        return newArray

                
    ##--------------##
        
    def populateCdesc3(self, cdesc3=None):
        """
        Populates the cdesc3 commonblock w/ data from
        iometa.  This is required to write to an IOAPI format file.
        
        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.

        """
        if cdesc3 is None:
            raise KeyError, "cdesc3 must be passed to function"

        ## Need to expand string variables to appropriate length and
        ## collapse lists into single long strings to populate cdesc3
        
        cdesc3.gdnam3d = self.padText(self.ioM.gridName)
        cdesc3.upnam3d = self.padText(self.ioM.upname)
        
        cdesc3.fdesc3d = self.padText(self.ioM.fileDesc, _IOdesclength*_IOmxdesclines)

        cdesc3.vname3d = self.padList(self.ioM.vnameLst, list2stringFlag = True)
        cdesc3.units3d = self.padList(self.ioM.vunitsLst, list2stringFlag = True)
        cdesc3.vdesc3d = self.padList(self.ioM.vdescLst, elemLength = _IOmxdesclines, \
                                          totalLength = _IOmxdesclines * _IOmxvars, \
                                          list2stringFlag = True)

        ## store cdesc3
        self.cdesc3 = cdesc3
        
    ##--------------##
        
    def padText(self, text, length = _IOnamelength):
        """
        Pads a text string w/ trailing spaces.

        Inputs:
              text  - text string

              length - length of new string, default is the IOAPI namelength

        Output:
              newStr - string of size length

        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.
        """

        lenStr = "%d" %length 
        fmtLine = "%-" + lenStr + "s"
        tmpText = fmtLine %text
        return tmpText

    ##--------------##
        
    def padList(self, textLst, elemLength = _IOnamelength, \
                    totalLength = _IOmxvars * _IOnamelength, list2stringFlag = False):
        """
        Pads a list of strings w/ trailing spaces.  Can produce a list
        of extended strings or can concatenate the list into one
        string of length totalLength.

        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.
        
        """
        
        lenStr = "%d" %elemLength
        totStr = "%d" %totalLength
        fmtLine1 = "%-" + lenStr + "s"
        fmtLine2 = "%-" + totStr + "s"

        if list2stringFlag:
            tmpStr = ""
            ## Expand each element to appropriate length
            for elem in textLst:
                tmpStr += fmtLine1 %elem

            ## take new string of all elements (string length = elemLength)
            ## and expand it pack the end until get total length
            tmpStr = fmtLine2 %tmpStr

            ## Return the full string
            return tmpStr
        
        else:
            ## expand each element to appropriate length
            tmpLst = [fmtLine1 %elem for elem in textLst]

            return tmpLst
        
            
    ##--------------##
        
    def write(self, vars):
        """
        Write a variable or a variable list to the file.

        Input:
           vars - iovar or list of iovar objects

        Notes/Assumptions:
           1.  If you are writing ioapi format file, the iofile
               object will setup an environmental variable for the
               output name.  The variable will be of the form,
               'OUTDDDDDDDDDD'.  This is needed for the ioapi
               library.

           2.  If you are writing to an ioapi file, you have the
               choice of multiple writes or a single write.  If you
               did not open the file w/ a newM (see open notes), then
               you can only perform one write.  To write multiple
               variables at once:
               
                 >>> f.ioapiTools.open('test.ioapi', 'w', \
                                       ioapiTools.iofileFlag)
                 >>> f.write([o3, nh3, co])
                 >>> f.close()
               
           3.  Multiple writes and ioapi format. All the metadata for
               an ioapi file needs to be written in the beginning.  If
               you want to have multiple, seperate writes to the file,
               you need to open the file with the metadata for all the
               variables you plan to write to this file.  In order to
               do multiple writes, pass the newM parameter to open.
               Here is an example of writing 3 variables:

                 >>> newM = ioapiTools.combineMeta([o3, nh3, co])
                 >>> f = ioapiTools.open('test.ioapi','w', newM, \
                                         ioapiTools.iofileFlag)
                 >>> f.write(nh3)
                 ...
                 >>> f.write([o3,co])
                 >>> f.close()

           4.  If you doing a single write to an ioapi file, the
               variable's metadata will be synced with the current
               state of the variable. In other words, the variable's
               ioM object will run updateFromVar.
        

        """

        ## Check if write flag, if not raise error
        if not self.writeFlag:
            raise IOError, "File %s opened for read only" %self.fileName
        
        ##IOAPI format
        if(self.typeFlag == iofileFlag):

            ## Difference b/w multiwrite and single write

            ## If multiwrite, can write multiple separate times
            ## doesn't write metadata to the file.
            ## Assumes that metadata is correctly written
            ## and this variable is in metadata
            if self.multiwriteFlag:


                ## Repopulate cdesc3 and bdesc3
                ## If opened a second file before writing first,
                ## the common blocks get overwritten.  Therefore,
                ## need to make sure that you have commonblock for
                ## this file's metadata before writing
                self.populateCdesc3(self.cdesc3)
                self.populateBdesc3(self.bdesc3)

                ## Simply write the variable
                if isinstance(vars, list):
                    for var in vars:
                        varStr = self.padText(var.id, _IOnamelength)
                        
                        ## Flatten variable to rank 1 Numeric array
                        varFlat = N.ravel(var)

                        ## Alot of the metadata is in the cdesc3 and bdesc3 attributes
##            write_var(a,file,var_name,nsteps,nlays,nrows,ncols,date,start_time,tstep)
                        status = pI.write_var(varFlat, self.outfile_env, \
                                              varStr, self.bdesc3.mxrec3d, \
                                              self.bdesc3.nlays3d, self.bdesc3.nrows3d, \
                                              self.bdesc3.ncols3d, self.bdesc3.sdate3d, \
                                              self.bdesc3.stime3d, self.bdesc3.tstep3d)

                        if status == 0:
                            raise IOError, "IOAPI error writing to file"
                        
                else:
                    ## Only one variable

                    ## Flatten variable to rank 1 Numeric array
                    varFlat = N.ravel(vars)

                    varStr = self.padText(vars.id, _IOnamelength)

                    status = pI.write_var(varFlat, self.outfile_env, \
                                          varStr, self.bdesc3.mxrec3d, \
                                          self.bdesc3.nlays3d, self.bdesc3.nrows3d, \
                                          self.bdesc3.ncols3d, self.bdesc3.sdate3d, \
                                          self.bdesc3.stime3d, self.bdesc3.tstep3d)
                    if status == 0:
                        raise IOError, "IOAPI error writing to file"

                ## Set first time write flag to false
                self.firstwriteFlag = False

            else:

                ## if first write flag, then need to first open
                ## file for write, pass it the metadata, write the data

                ## If not first write, raise an error
                if not self.firstwriteFlag:
                    raise IOError, "Cannot write multipe times to IOAPI format file. " \
                          "Use alternative open format for multiple writes"

                
                if isinstance(vars, list):
                    ## list of variables

                    ## Get a combined iometa for all the variables
                    newMeta = combineMeta(vars)

                    ## Store the new meta objects in iofile instance
                    self.ioM = newMeta[0]
                    self.cdmsM = newMeta[1]

                    ## Populate the ioapi common blocks
                    self.populateCdesc3(pI.cdesc3)
                    self.populateBdesc3(pI.bdesc3)

                    ## Open the file for writing
                    status = pI.open_file(self.outfile_env, _IOwritenew)
                    if status == 0:
                        raise IOError, "IOAPI error opening file"
                    

                    for var in vars:
                        varStr = self.padText(var.id, _IOnamelength)

                        ## Flatten variable to rank 1 Numeric array
                        varFlat = N.ravel(var)

                        ## Alot of the metadata is in the cdesc3 and bdesc3 attributes
##            write_var(a,file,var_name,nsteps,nlays,nrows,ncols,date,start_time,tstep)
                        status = pI.write_var(varFlat, self.outfile_env, \
                                              varStr, self.bdesc3.mxrec3d, \
                                              self.bdesc3.nlays3d, self.bdesc3.nrows3d, \
                                              self.bdesc3.ncols3d, self.bdesc3.sdate3d, \
                                              self.bdesc3.stime3d, self.bdesc3.tstep3d)
                        if status == 0:
                            raise IOError, "IOAPI error writing to file"


                else:
                    ## Only one variable

                    ## make sure metadata current w/ variable
                    vars.ioM.updateFromVar(vars)

                    ## Store the var meta objects in iofile instance
                    self.ioM = vars.ioM
                    self.cdmsM = cdmsmeta(vars, typeFlag = cdmsvarFlag)

                    ## Populate the ioapi common blocks
                    self.populateCdesc3(pI.cdesc3)
                    self.populateBdesc3(pI.bdesc3)

                    ## Open the file for writing
                    status = pI.open_file(self.outfile_env, _IOwritenew)

                    if status == 0:
                        raise IOError, "IOAPI error opening file"

                    ## Flatten variable to rank 1 Numeric array
                    varFlat = N.ravel(vars)

                    varStr = self.padText(vars.id, _IOnamelength)

                    status = pI.write_var(varFlat, self.outfile_env, \
                                          varStr, self.bdesc3.mxrec3d, \
                                          self.bdesc3.nlays3d, self.bdesc3.nrows3d, \
                                          self.bdesc3.ncols3d, self.bdesc3.sdate3d, \
                                          self.bdesc3.stime3d, self.bdesc3.tstep3d)
                    if status == 0:
                        raise IOError, "IOAPI error writing to file"


                ## Set first time write flag to false
                self.firstwriteFlag = False
                


        elif(self.typeFlag == cffileFlag):
            ## CDMS write to CF netCDF file
            
            ## list of variables
            if isinstance(vars, list):

                ## Check if first write,
                ## if so, write the grid_map and ioapi_meta from the
                ## first variable in the list
                if self.firstwriteFlag:
                    self.f.write(vars[0].ioM.IO2gridmap())
                    self.f.write(vars[0].ioM.IO2cdms())

                    ## if lat lon axes flag, generate alternative axes and axes bounds
                    ## and write variables to file
                    if self.llaxesFlag:
                        cdmsM1 = cdmsmeta(vars[0], typeFlag = cdmsvarFlag)
                        llaxes = cdmsM1.latlonAxes(vars[0].ioM)
                        latVar = llaxes[0]
                        lonVar = llaxes[1]
                        latBounds = llaxes[2]
                        lonBounds = llaxes[3]
                        self.f.write(latVar)
                        self.f.write(lonVar)
                        self.f.write(latBounds)
                        self.f.write(lonBounds)
                    
                ## Write each variable to file, need to convert to cdms
                for var in vars:

                    if self.llaxesFlag:
                        ## Append additional attribute to the vars
                        ## relates xlon ylat coordinates to lon lat
                        var.coordinates = "lat lon" 

                    self.f.write(var.IO2cdms())

            ## A single variable
            else:
                ## Check if first write,
                ## if so, write the grid_map and ioapi_meta from the variable
                if self.firstwriteFlag:
                    self.f.write(vars.ioM.IO2gridmap())
                    self.f.write(vars.ioM.IO2cdms())

                    ## if lat lon axes flag, generate alternative axes and axes bounds
                    ## and write variables to file
                    if self.llaxesFlag:
                        cdmsM1 = cdmsmeta(vars, typeFlag = cdmsvarFlag)
                        llaxes = cdmsM1.latlonAxes(vars.ioM)
                        latVar = llaxes[0]
                        lonVar = llaxes[1]
                        latBounds = llaxes[2]
                        lonBounds = llaxes[3]
                        self.f.write(latVar)
                        self.f.write(lonVar)
                        self.f.write(latBounds)
                        self.f.write(lonBounds)



                ## Write variable to file, need to convert to cdms variable
                if self.llaxesFlag:
                    ## Append additional attribute to the vars
                    ## relates xlon ylat coordinates to lon lat
                    vars.coordinates = "lat lon" 
                self.f.write(vars.IO2cdms())

            ## Change first write flag to False
            self.firstwriteFlag = False
            
        else:
            raise KeyError, "iofile typeflag is not correct"

    ##--------------##
        
    def close(self):
        """
        Close a file.  Especially important if you are writing to the file.

        """

        if self.writeFlag:
            ## Wrote to file, depending on type, close differently
            if(self.typeFlag == iofileFlag):

                ## Close the ioapi file
                pI.close_file(self.outfile_env)

            elif(self.typeFlag == cffileFlag):

                ## close the cf netcdf file
                self.f.close()

            else:
                raise KeyError, "iofile typeFlag is not correct"

        else:
            ## Read from file, so just do a cdms close
            self.f.close()

        self.openFlag = False
        

    ##--------------##
        
    def listvariables(self, allFlag = False):
        """
        list variables in the file.

        Input:
            allFlag  - True, list all variables in the file
                       False,[default] try to remove metadata variables

        Output:
            varLst   - list of variable names

        Note/Assumptions:

           1.  If allFlag is False, this method will try and remove
               any of the metadata variables.  For ioapi files, it
               will remove TFLAG from the list.  For CF netCDF files,
               it will remove ioapi_meta, bounds_yLat, bounds,xLon,
               and lat, lon, bounds_lat, and bounds_lon if they exist.
               It will not remove the grid_mapping variable, because
               its name is not fixed, it depends on the projection
               type.
        
        """
        ## Get all variables from the cdms file handle
        varLst = self.f.listvariables()
        
        if allFlag:
            return varLst

        else:
            ## remove some variables depending on the file type
            if self.typeFlag == iofileFlag:
                ## ioapi file
                try: varLst.remove("TFLAG")
                except: pass
                return varLst

            else:
                ## CF netCDF
                try: varLst.remove("ioapi_meta")
                except: pass
                try: varLst.remove("bounds_xLon")
                except: pass
                try: varLst.remove("bounds_yLat")
                except: pass
                try: varLst.remove("bounds_lat")
                except: pass
                try: varLst.remove("bounds_lon")
                except: pass
                try: varLst.remove("lat")
                except: pass
                try: varLst.remove("lon")
                except: pass

                return varLst

            
    ##--------------##
        
    def getXlons(self):
        """
        Returns a copy of the xlon list.  These are the longitude values
        of the cross points (center) of each grid cell.  They are in the
        projection coordinate units (probably meters). The 0th element is
        the Western most grid cell.  The last element is the Eastern most
        grid cell.
        
        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.
        """
        if self.xlonLst is None:
            raise KeyError, "Xlon list is not set"

        return self.xlonLst.copy()

    ##--------------##
        
    def getYlats(self):
        """
        Returns a copy of the ylat list.  These are the latitude values
        of the cross points (center) of each grid cell.  They are in the
        projection coordinate units (probably meters). The 0th element is
        the Southern most grid cell.  The last element is the Northern most
        grid cell.
        
        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.
        """
        if self.ylatLst is None:
            raise KeyError, "Ylat list is not set"

        return self.ylatLst.copy()
    ##--------------##
        
    def getTimes(self):
        """
        Returns a copy of the times list.  These are time steps
	(probably hours) since the start time.
        
        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.
        """
        if self.times is None:
            raise KeyError, "Times list is not set"

        return self.times.copy()
    
    ##--------------##
        
    def getCdmsMeta(self):
        """
        Returns a copy of the cdmsMeta object.  These are the cdms axes.
                
        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.
        """
        if self.cdmsM is None:
            raise KeyError, "cdmsMeta object is not set"

        return self.cdmsM.copy()
    ##--------------##
        
    def getGridMap(self):
        """
        Returns a copy of the grid_map, projection info stored in a
        seperate cdms variable.

        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.
        """
        if self.grid_map is None:
            raise KeyError, "grid_map is not set"

        return self.grid_map.clone()
        
    ##--------------##
        
    def hasAxes(self):
        """
        
        Tests whether grid object has the cdmsMeta object and grid_map.
        
        If this is True, one can directly access the axes through the
        methods: getCdmsMeta and getGridMap.

        returns:
           True - has the additional axes
           False - does not have them
           
        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.
        """
        if self.cdmsM is None:
            return False
        if self.grid_map is None:
            return False

        return True


           
#----------------------------------------------------------------#
def open(fileName, rwFlag = "r", typeFlag = cffileFlag, newM = None, \
                  logFile = None, llaxesFlag = False):
        
    
    """ Opens a file and returns an iofile object.

        Input:
           fileName  - Either a fileName for an IO/API file or a CF
                       complient netcdf file.

           rwFlag    - 'r' - read
                       'w' - write / overwrite

           typeFlag  - cffileFlag (default), write a cf netcdf file
                       iofileFlag, write an ioapi format file
                       (Only needed for writes, reading automatically
                       determines file type)

           newM      - tuple (ioM, cdmsM) describes the ioapi metadata
                       domain, and geographic projection of the data
                       for this file. This tuple is the return of
                       combineMeta.  Only needed for multiple writes
                       to ioapi files (see Notes).

           logFile   - log file name. Used to store ioapi library
                       log info.  Default is None, display log
                       info in stdout.  If a file is indicated, it
                       will overwrite any previous file of that name.

           llaxesFlag- True - write out alternative lat and lon coordinates
                       False [default] - do not write out alternative
                                         coordinates
                        
        Output:
           ioFile    - iofile object

        Notes/Assumptions:

           1.  If the file format is neither ioapi or cf compliant,
               but it is a netcdf file, it will raise an error.
               
           2.  If you are writing ioapi format and pass a logFile,
               the function sets up an environmental variable,
               LOGFILE.

           3.  If you are writing ioapi format file, the iofile
               object will setup an environmental variable for the
               output name.  The variable will be of the form,
               'OUTDDDDDDDDDD'.  This is needed for the ioapi
               library.

           4.  If you are writing to a file that already exists.
               the open command will print a warning and remove
               the file before writing.

           5.  Multiple writes and ioapi format. All the metadata
               for an ioapi file needs to be written in the
               beginning.  If you want to have multiple, seperate
               writes to the file, you need to open the file with
               the metadata for all the variables you plan to
               write to this file.  In order to do multiple
               writes, pass the newM parameter.  Here is an
               example of writing 3 variables:

                 >>> newM = ioapiTools.combineMeta([o3, nh3, co])
                 >>> f = ioapiTools.open('test.ioapi','w', newM, \
                                         ioapiTools.iofileFlag)
                 >>> f.write(nh3)
                 ...
                 >>> f.write([o3,co])
                 >>> f.close()

           6.  The llaxesFlag indicates whether or not to write out
               alternative coordinates, lat and lon.  This is only
               meaningful if you are writing to a CF netCDF file.
               These alternative coordinates are cdms variables in
               there own right.  They are both functions of yLat and
               xLon, e.g. lat(yLat,xLon).  To be truelly CF compliant,
               this flag should be on.  But, this slows down the write
               and may cause some programs to have problems displaying
               the data.  The values of lat are the latitude at each
               yLat,xLon grid point.  This basically translates the
               regular grid in the native projection to an irregular
               grid in degrees N,E.  It also creates a bounds_lon and
               bounds_lat variable, which correspond to the irregular
               corners of each grid cell.
               
    """

    ioFile = iofile(fileName, rwFlag, typeFlag, newM, logFile, llaxesFlag)
    return ioFile

#----------------------------------------------------------------#
class iofilescan(object):
    """
    """

    def __init__(self, searchStr, startDate, endDate, fastSort=True):
        """

        Scans files for the date range.  Opens up each of
        the files (making a list of iofiles) for variable
        extraction.

        Input:
            searchStr - a search string

            startDate - beginning date

            endDate - last date.

            fastSort - T use sort based on file names (default)
                       F actually open files and compare dates
                       
        Output:
            ioScan - iofilescan object.

        Notes/Assumptions:

          1.  Search string is of unix form, use '*' for wild card.
              For example the search string 'CCTM_CONC.D1.*' will
              match:
                 CCTM_CONC.D1.001, CCTM_CONC.D1.033.nc, ...
                  
          2.  Search string should only match files of a single file
              type (either all ioapi format or all cf netcdf format).

          3.  A sort of the file names should put them in temporal order.
              If it doesn't, set fastSort = False and it will test
              each file

          4.  Only used for extraction, not for writing. See ioScan.extract.

        """

        self.fileDct = date2Files(searchStr, startDate, endDate, fastSort) 

        self.fileLst =  self.fileDct.keys()
        if fastSort:
            self.fileLst.sort()
        else:
            self.fileLst.sort(filetimeCmp)
            
        self.startDate = startDate
        self.endDate = endDate
        self.openFlag = True
        
    def extract(self, vname, capFlag = True):
        
        """ Extracts a variable from iofilescan.  This variable will
        span the whole temporal domain (even if it crosses file
        boundaries).

        Input:
           vname - variable name

           capFlag - True [default] automatically capitalize string
                     False - do not capitalize

        Output:
            ioVar  - iovar object for that variable name
        """

        varName = vname
        if capFlag:
            ## Capitalize the variable name
            ## Most IO/API files have variables in caps
            varName = vname.upper()

        ## if the file list is length 1, i.e. the dates only span one
        ## file, then simply do a subset on this one file
        if len(self.fileLst) == 1:
            ioF = self.fileDct[self.fileLst[0]].ioFile
            varTmp = ioF.extract(varName)
            return varTmp.IOsubset(timeLst=[self.startDate, self.endDate])

        ## Extracting across multiple files
        else:
            ## Get data from file and create a temporary cdms variable
            varLst = []

            ## For each file create a variable and subset it
            ## based on the time index
            for file in self.fileLst:
                ioF = self.fileDct[file].ioFile

                ## Need to make ints so that don't cause problems
                ## w/ cdms subSlice
                start = int(self.fileDct[file].startInd)
                end = int(self.fileDct[file].endInd)
                varTmp = ioF.extract(varName)

                ## don't need to shift time index in subset
                ## dealt w/ in concatenation
                varTmp._IOshiftFlag = False

                ## Get subset based on time indices
                varLst.append(varTmp.IOsubset(timeLst=[start, end], \
                                              indexFlag = True))
            ## Concatenate variable and return
            varConc = concatenate(varLst)
            return varConc

    def close(self):
        """
        closes all the iofiles in the file dictionary
        """
        for file in self.fileLst:
            self.fileDct[file].ioFile.close()

        self.openFlag = False

    def listvariables(self, allFlag = False):

        """ list variables in the files.

        Input:
            allFlag  - True, list all variables in the file
                       False,[default] try to remove metadata variables

        Output:
            varLst   - list of all the variable names

        Note/Assumptions:

           1.  If allFlag is False, this method will try and remove
               any of the metadata variables.  For ioapi files, it
               will remove TFLAG from the list.  For CF netCDF files,
               it will remove ioapi_meta, bounds_yLat, bounds,xLon.
               It will not remove the grid_mapping variable, because
               its name is not fixed, it depends on the projection
               type.

           2.  This actually only lists the variables in the first
               file.  It assumes that all files in the scan have the
               same variable list.
        
        """

        ## simply call listvariables for the first iofile
        varLst = self.fileDct[self.fileLst[0]].ioFile.listvariables(allFlag)
        return varLst
    

    def __repr__(self):

        if self.openFlag:
            status = "open"
        else:
            status = "closed"

        summaryStr = "<ioapiTools  iofilescan,  status: %s >" %status
        return summaryStr

    def __str__(self):

        summaryStr = " object: %s\n dates: %s - %s\n first file: %s\n"\
                     " last file: %s" %("iofilescan", self.startDate, \
                                        self.endDate, self.fileLst[0], \
                                        self.fileLst[-1])
        return summaryStr

    def __call__(self, vname, capFlag = True):
        """
        Extracts a variable.

        Input:
          vname - variable name

          capFlag - True [default] - automatically capitalize vname
                    False - do not capitalize

        Output:
          ioVar - iovar object
          
        """
        return self.extract(vname, capFlag)
    
#----------------------------------------------------------------#
class iometa(object):

    """ The iometa object is the repository for ioapi specific
    metadata and projection info.
    """

    def __init__(self, ioFile = None, typeFlag = None):
        """ init

        Inputs:
            ioFile -  iofile object 

            typeFlag -  None, means iofile object [default]
                        byhandFlag, construct by hand [not yet implemented]
        """

        if typeFlag is None:

            if ioFile is None:
                raise NameError, "Need to pass an ioFile object"

            ## depending on type of file, create iometa
            if ioFile.typeFlag == iofileFlag:
                ## from ioapi file
                self.fromIOFile(ioFile)
            else:
                ## from cf netCDF file w/ metadata
                self.fromCFFile(ioFile)
                

        elif typeFlag == byhandFlag:
            ## WRITE!!!
            raise KeyError, "Not yet implemented"

        else:
            raise KeyError, "Appropriate type are None or byhandFlag"


    def __str__(self):

        summaryStr = "iometa object:\n"
        summaryStr += "\t gridName: %s \n" %self.gridName
        summaryStr += "\t gridType: %d \n" %self.gridType
        summaryStr += "\t ioapi fileType: %d \n" %self.ftype
        summaryStr += "\t projection: %s \n" %self.projectionName
        summaryStr += "\t projection parameters:\n"
        summaryStr += "\t\t xcent: %f Degrees E \n" %self.xcent
        summaryStr += "\t\t ycent: %f Degrees N \n" %self.ycent
        summaryStr += "\t\t p_alp: %f \n" %self.p_alp
        summaryStr += "\t\t p_bet: %f \n" %self.p_bet
        summaryStr += "\t\t p_gam: %f \n" %self.p_gam
        summaryStr += ""
        summaryStr += "\t verticalType: %d \n" %self.vertType
        summaryStr += "\t vertical top: %f \n" %self.vertTop
        summaryStr += "\t boundary thickness: %d \n" %self.nthick
        summaryStr += "\n"
        ## Following attributes might not exist so do a try
        try: summaryStr += "\t nvars: %d \n" %self.nvars
        except: pass
        try: summaryStr += "\t variable name list: %s \n\n" %self.vnameLst
        except: pass
        try: summaryStr += "\t variable unit list: %s \n\n" %self.vunitsLst
        except: pass
        try: summaryStr += "\t variable desc list: %s \n\n" %self.vdescLst
        except: pass
        try: summaryStr += "\t variable type list: %s \n\n" %self.vtypeLst
        except: pass

        summaryStr += "\n"
        summaryStr += "\t upname: %s \n" %self.upname
        summaryStr += "\t file description: %s\n" %self.fileDesc
        
        return summaryStr

    def fromIOFile(self, ioFile):
        """
        Extract ioapi metadate from ioapi file

        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.

        """

        ## Copy over IO/API specific metadata
        self.ftype = ioFile.ftype
        self.nvars = ioFile.nvars
        self.fileDesc = ioFile.fileDesc
        self.upname = ioFile.upname
        self.vnameLst = copy.copy(ioFile.vnameLst)
        self.vunitsLst = copy.copy(ioFile.vunitsLst)
        self.vdescLst = copy.copy(ioFile.vdescLst)
        self.vtypeLst = copy.copy(ioFile.vtypeLst)
        self.nthick = ioFile.nthick
        self.vertType = ioFile.vertType
        self.vertTop = ioFile.vertTop
        
        ## Copy over projection specific metadata
        ## General projection parameters
        self.p_alp = ioFile.p_alp
        self.p_bet = ioFile.p_bet
        self.p_gam = ioFile.p_gam

        ## Projection center in degrees
        self.xcent = ioFile.xcent
        self.ycent = ioFile.ycent

        ## Cell size in native projection units
##        self.xcellSize = ioFile.xcellSize
##        self.ycellSize = ioFile.ycellSize
        
        ## IO/API projection name (user given) and
        ## projection identifier
        self.gridName = ioFile.gridName
        self.gridType = ioFile.gridType


        ## Construct additional projection info based on gridType
        self.projectionName = self.projCode2Name(self.gridType)

    def fromCFFile(self, ioFile):
        """
        Extract ioapi metadate from CF netCDF w/ ioapi metadata

        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.

        """

        ## get ioapi_meta cdms variable from the file
        iomCdms = ioFile.f("ioapi_meta")

        
        ## Copy over IO/API specific metadata
        self.ftype = iomCdms.ftype.toscalar()
        self.upname = iomCdms.upname
        self.nthick = iomCdms.nthick.toscalar()
        self.vertType = iomCdms.vertType.toscalar()
        self.vertTop = iomCdms.vertTop.toscalar()
        
        ## Copy over projection specific metadata
        ## General projection parameters
        self.p_alp = iomCdms.p_alp.toscalar()
        self.p_bet = iomCdms.p_bet.toscalar()
        self.p_gam = iomCdms.p_gam.toscalar()

        ## Projection center in degrees
        self.xcent = iomCdms.xcent.toscalar()
        self.ycent = iomCdms.ycent.toscalar()

        ## Cell size in native projection units
##        self.xcellSize = iomCdms.xcellSize
##        self.ycellSize = iomCdms.ycellSize
        
        ## IO/API projection name (user given) and
        ## projection identifier
        self.gridName = iomCdms.gridName
        self.gridType = iomCdms.gridType.toscalar()


        ## Construct additional projection info based on gridType
        self.projectionName = self.projCode2Name(self.gridType)

        ## file description is stored as value of ioapi_meta variable
        self.fileDesc = iomCdms.getValue().tostring()

        ## These attributes are excluded b/c they are
        ## figured out from the individual variables

#        self.nvars = iomCdms.nvars
#        self.vnameLst = copy.copy(iomCdms.vnameLst)
#        self.vunitsLst = copy.copy(iomCdms.vunitsLst)
#        self.vdescLst = copy.copy(iomCdms.vdescLst)
#        self.vtypeLst = copy.copy(iomCdms.vtypeLst)


    def projCode2Name(self, gridtype):
        """
        Returns grid name based on IO/API gridtype code.
        In addition, it populates some projection specific
        variables

        
        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.

           2.  Presently, only Lambert Conformal Conic projection
               (gridtype = 2) is supported.

        """
        ## at present only looking for MM5 projections
        if gridtype == 2:
            self.standparallel1 = self.p_alp
            self.standparallel2 = self.p_bet
            self.xunits = "meters"
            self.yunits = "meters"
            return "Lambert Conformal Conic"

        ## Form for other projections
##         elif gridtype == 3:
##             return "Mercator"
##         elif gridtype == 6:
##             return "Polar Stereographic"
        else:
            raise KeyError, "Unknown projection code: %d" %gridtype


    def IO2gridmap(self, nameOnly = False, falseEast = 0, falseNorth = 0):
        """
        Returns grid_mapping cdms variable.  This has the projection
        info in CF compliant form.  To be saved to the netCDF file.

        Input:
           nameOnly  -  True, simply return the name of the grid_mapping variable
                        False, return the grid_mapping variable [default]

           falseEast  -  False easting of the projection.  Default is 0.

           falseNorth  - False northing of the projection.  Default is 0.

        Output:
           grid_map -  A grid map. A cdms variable that contains the
                       projection info in CF compliant form.  This is
                       automatically written to the file in the iofile
                       write method, when writing to CF files. If
                       nameOnly is True, then this will be the name of
                       the grid_map, the attribute grid_mapping_name.
           
        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.

           2.  Presently, only Lambert Conformal Conic projection
               (gridtype = 2) is supported.

        """

        ## at present only looking for MM5 projections
        if self.gridType == 2:
            ## Lambert conformal conic
            id = "Lambert_Conformal"
            if nameOnly:
                ## simply return the name of the grid_mapping variable
                return id

            ## Create a grid_mapping cdms variable
            ## need to store some dummy data in the variable to create
            ## it
            grid_map = cdms.createVariable("dummy", id=id)
            grid_map.grid_mapping_name="lambert_conformal_conic"
            grid_map.standard_parallel= self.standparallel1,self.standparallel2
            grid_map.longitude_of_central_meridian = self.xcent
            grid_map.latitude_of_projection_origin = self.ycent
            grid_map.false_easting = falseEast
            grid_map.false_northing = falseNorth

            return grid_map
        
        ## Form for other projections
##         elif gridtype == 3:
##             "Mercator"
##         elif gridtype == 6:
##             "Polar Stereographic"
        else:
            raise KeyError, "Unknown projection code: %d", self.gridType

    def IO2cdms(self):
        """
        Converts the iometa object into a cdms variable.  This cdms
        variable is then stored in the CF compliant netCDF file as
        ancillary data.  Allows a CF netCDF file to have necessary
        metadata to recreate an IOAPI formatted file.

        Output:
           iomCdms - a cdms variable that holds all the ioapi specific metadata.
           
        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.

           2.  This cdms variable is automatically written to the CF
               file by the iofile method write.
               
        """
        ## Create a cdms variable with the file description as
        ## its character contents
        iomCdms = cdms.createVariable(self.fileDesc, id="ioapi_meta")

        iomCdms.long_name = "IOAPI metadata-- necessary for recreating ioapi files"
        
        ## Take rest of iometa attributes and make equivalent attributes
        ## in the iomCdms variable
        iomCdms.ftype = self.ftype
        iomCdms.upname = self.upname
        iomCdms.nthick = self.nthick
        iomCdms.vertType = self.vertType
        iomCdms.vertTop = self.vertTop
        iomCdms.p_alp = self.p_alp
        iomCdms.p_bet = self.p_bet
        iomCdms.p_gam = self.p_gam
        iomCdms.xcent = self.xcent
        iomCdms.ycent = self.ycent
        iomCdms.gridName = self.gridName
        iomCdms.gridType = self.gridType
       
        ## Projection and grid_mapping variable name
        iomCdms.projectionName = self.projectionName
        iomCdms.grid_mapping = self.IO2gridmap(nameOnly = True) 

        ## These attributes are excluded b/c they are
        ## figured out from the individual variables
#        iomCdms.nvars = self.nvars
#        iomCdms.fileDesc = self.fileDesc
#        iomCdms.vnameLst = copy.copy(self.vnameLst)
#        iomCdms.vunitsLst = copy.copy(self.vunitsLst)
#        iomCdms.vdescLst = copy.copy(self.vdescLst)
#        iomCdms.vtypeLst = copy.copy(self.vtypeLst)

        return iomCdms
    
    def copy(self):

        """ Makes a copy of the iometa object.
        """
        
        return copy.deepcopy(self)


    def updateFromVar(self, var):
        """
        Update iometa from a cdms variable or iovar object.

        Updates following fields:
               vnameLst
               vunitsLst
               vdescLst
               nvars

        Note/Assumptions:
        
           1.  Internal function.  Should generally not be used by
               normal users.

           2.  That var has name, units, var_desc attributes
           
        """

        vname = var.id
        vunit = var.units
        vdesc = var.var_desc

        self.replVar(vname, vunit,vdesc)
        
    def replVar(self, vars = None, units = None, desc = None):
        """
        Replace the variable metadata stored in iometa.

        Updates the following fields:
               vnameLst
               vunitsLst
               vdescLst
               nvars

        Input:
            vars - variable name(s), string or list of strings

            units - variable units, string or list of strings

            desc  - variable description, long name, string or list of strings
        
        NOTE:

            1. For advanced users only.  Modifying iometadata
               directly should be done w/ utmost care.

            2. Length of vars, units, and desc must be equivalent.
               The length of the list determines the number of vars.

        """

        if vars is None:
            raise KeyError, "vars needs to be a string or a list"
        if units is None:
            raise KeyError, "units needs to be a string or a list"
        if desc is None:
            raise KeyError, "desc needs to be a string or a list"

        ## Check if vars is a list
        ## if yes, assumes all other inputs are a list
        if isinstance(vars, list):
            self.vnameLst = vars

            ## Test to see if lists are same length
            nvars = len(vars)
            if (nvars != len(units)):
                raise KeyError, "length of vars list must equal length of units list"
            if (nvars != len(desc)):
                raise KeyError, "length of vars list must equal length of desc list"

            ## Change some variable metadata
            self.nvars = nvars
            self.vnameLst = vars
            self.vunitsLst = units
            self.vdescLst = desc
            ## Assumes all variables type real,
            ## can change by hand later
            self.vtypeLst = N.ones(self.nvars) * _m3real


        else:
            ## Assume that all inputs are strings
            ## i.e. nvars = 1
            ## construct single element lists
            self.nvars = 1
            self.vnameLst = [vars]
            self.vunitsLst = [units]
            self.vdescLst = [desc]
            ## Assumes all variables type real,
            ## can change by hand later
            self.vtypeLst = N.ones(self.nvars) * _m3real
            
        

#----------------------------------------------------------------#
class iovar(cdms.tvariable.TransientVariable):

    """ iovar object.  This inherits from cdms transient variables and
        uses it as a model for many of its methods.  Major difference
        is the addition of ioapi metadata and projection info, iometa
        object.
    
    """

    def __init__(self, data, ioM, axes=None, id=None, attributes=None, copyFlag = True):
        """
        Creates an ioVar object.

        Input:
           data - a data array. The data array can be a
                  Numeric, MV, cdmsVariable or an ioVar.


           ioM - iometa object.

           axes - cdms axes list [time, layer, latitude, longitude]

           id - identifier of variable

           attributes - dictionary of attribute values

           copyFlag - True [default] - copy the data
                      False - share the data

        Output:
           ioVar - iovar object

        Notes/Assumptions:

           1.  If you are passing a cdms or iovar variable, you will not
               need to give axes, id, or attributes.  These will simply be
               taken from the variable's metadata.  If you are passing a
               Numeric array, you will need to provide the axes, id, and
               attributes.

           2.  The iovar inherits many of its properties from cdms
               transient variables.  See cdat's documentation for more
               specifics.

        """

            

        ## Want to have Base class (cdms transient variable) run
        ## init to get all of its features.


        ## Determine if copy data and metadata or using the same data and metadata
        ## Init the cdms variable w/ appropriate axes and attributes
        if copyFlag:
            cdms.tvariable.TransientVariable.__init__(self, data, id=id, attributes=attributes,\
                                                      axes=axes, copy = 1)
        else:
            cdms.tvariable.TransientVariable.__init__(self, data, id=id, attributes=attributes,\
                                                      axes=axes, copy = 0)
            
        ## Record iometa object, need to do it after cdms instantiation or cdms will
        ## simply overwrite the ioM attribute
        if copyFlag:
            self.ioM = ioM.copy()
        else:
            self.ioM = ioM
            

        ## Update iometa object so only has one variable in its
        ## metadata lists and uses id for variable id and name
        self.ioM.updateFromVar(self)
        self.IOmodVar(vname=id)

        ## Add some additional attributes that will be used if writing
        ## to CF netCDF
        ## In particular, grid_mapping which links the variable to a projection
        ## and the ancillary variable which links the variable to iometa
        ## cdms variable
        self.grid_mapping = self.ioM.IO2gridmap(nameOnly=True)
        self.ancillary_variables = "ioapi_meta"
        
        ## set shift index flag to True.  If this is set, an IOsubset
        ## will shift the time index to be zero w/ any temporal subset
        ## using IOshiftTimeInd.  The only time this is set to False
        ## is during ioapiTools.scan, so that the time indices aren't
        ## shifted 2 times.
        self._IOshiftFlag = True

    ##--------------##
        
    def __str__(self):

        ## get the string from the cdms variable
        cdmsStr = "array %s, type = %s, %d elements" \
                  %(self.shape, self.typecode(), self.size()) 
        
        summaryStr = " name : %s\n data: %s\n projection: %s\n object: %s" \
                     %(self.name, cdmsStr, self.ioM.projectionName, "iovar")

        return summaryStr

    ##--------------##
        
    def __repr__(self):

        ## if shape of self is >=2, just return str
        if len(self.shape) >= 2:
            return self.__str__()

        else:
            ## 0 or 1 Dimensional array,
            ## show data
            dataVals = self._data

            summaryStr = " name: %s\n data: %s\n projection: %s\n object: %s"\
                         %(self.name, dataVals, self.ioM.projectionName,"iovar")
            return summaryStr
        
    ##--------------##
        
    def __getitem__(self, key):
        """
        Wrapper around cdms tvariable get item
        """
        
        subVar = cdms.tvariable.TransientVariable.__getitem__(self, key)

        iosubVar = createVariable(subVar, self.ioM, \
                                  attributes=self.attributes, copyFlag = False)

        return iosubVar

    ##--------------##
        
    def __getslice__(self, low, high):
        """
        Get slice

        Unlike cdms, I am simply passing this to getitem
        """

        slice1 = slice(low,high)
        return self.__getitem__(slice1)


    ##--------------##
        
    def __add__(self, other):
        """
        Wrapper around cdms tvariable add
        """
        tmpVar = cdms.tvariable.TransientVariable.__add__(self,other)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar
    
    ##--------------##
        
    def __sub__(self, other):
        """
        Wrapper around cdms tvariable subtract
        """
        tmpVar = cdms.tvariable.TransientVariable.__sub__(self,other)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar
    
    ##--------------##
        
    def __div__(self, other):
        """
        Wrapper around cdms tvariable divide
        """
        tmpVar = cdms.tvariable.TransientVariable.__div__(self,other)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar
    
    ##--------------##
        
    def __mul__(self, other):
        """
        Wrapper around cdms tvariable multiply
        """
        tmpVar = cdms.tvariable.TransientVariable.__mul__(self,other)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar
    
    ##--------------##
        
    def __mod__(self, other):
        """
        Wrapper around cdms tvariable module
        """
        tmpVar = cdms.tvariable.TransientVariable.__mod__(self,other)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar
    
    ##--------------##
        
    def __abs__(self):
        """
        Wrapper around cdms tvariable absolute
        """
        tmpVar = cdms.tvariable.TransientVariable.__abs__(self)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar
    
    ##--------------##
        
    def __neg__(self):
        """
        Wrapper around cdms tvariable negative
        """
        tmpVar = cdms.tvariable.TransientVariable.__neg__(self)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar
    
    ##--------------##
        
    def __pow__(self, other):
        """
        Wrapper around cdms tvariable raised to the power
        """
        tmpVar = cdms.tvariable.TransientVariable.__pow__(self, other)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar


    ##--------------##
        
    def __iadd__(self, other):
        """
        Wrapper around cdms tvariable iadd 'x+=2'
        """
        tmpVar = cdms.tvariable.TransientVariable.__iadd__(self,other)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar
    
    ##--------------##
        
    def __isub__(self, other):
        """
        Wrapper around cdms tvariable isub
        """
        tmpVar = cdms.tvariable.TransientVariable.__isub__(self,other)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar
    
    ##--------------##
        
    def __imul__(self, other):
        """
        Wrapper around cdms tvariable imul
        """
        tmpVar = cdms.tvariable.TransientVariable.__imul__(self,other)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar
    
    ##--------------##
        
    def __idiv__(self, other):
        """
        Wrapper around cdms tvariable idiv
        """
        tmpVar = cdms.tvariable.TransientVariable.__idiv__(self,other)
        iotmpVar = createVariable(tmpVar, self.ioM, id = self.id,\
                                  attributes=self.attributes, copyFlag = False)

        return iotmpVar
    
 
    ##--------------##
        
    def __call__(self, *args, **kwargs):
        """
        cdms style subsetting.  Uses cdms selectors.

        Wrapper arround the cdms.tvariable call
        """

        subVar = cdms.tvariable.TransientVariable.__call__(self, *args, **kwargs)

        iosubVar = createVariable(subVar, self.ioM, copyFlag = False)

        return iosubVar

    ##--------------##
        
    def IOequal(self, other, exactFlag = False, rtol = 1.e-5, atol=1.e-8):

        """ Tests whether the data is 'equal' between the variable
        and 'other'.


        Input:
           other  - another variable of the same size.

           exactFlag - whether to do an exact comparison (True) or an
                       'all close' comparison (False).  Default is an
                       'all close', a comparison with a small tolerance
                       to take into account floating point error.

           rtol - 'relative' tolerance.  Default is 1.e-5.

           atol - 'absolute' tolerance.  Default is 1.e-8.

        Output:
           status - True - data equal
                    False - data not equal

        Notes/Assumptions:
        
           1.  This does not test the metadata.  It only tests the MA data
               array.

           2.  If you simply do a test w/ 'equal' signs, eg. a == b,
               this will return a cdms variable of the same shape as
               'a' and 'b'.  The elements of this array will be the
               element wise comparison of the 2 arrays. A value of 1
               means equal, 0 means unequal.  The function IOequal
               with exactFlag = True does the same thing, then tests
               to see if there are any unequal elements (0).

           3.  If you use the 'all close' comparison, exactFlag =
               False, then this simply uses the Numeric allclose
               function.  Here, 'equality' means:
                  abs(dat1 - dat2) < (atol + rtol*abs(dat2))

               Where dat1 is the element of the variable and dat2 is
               the element of the other variable.
               
           4.  The 2 variables must have identical shapes.

           5.  If you are doing an exact comparison, I do not
               recommned using this in a loop.  Because of the sort,
               this is not terribly quick.

                          
        """
        ## Exact comparison
        if exactFlag:

            ## Get a comparison array
            eqVar = (self == other)

            ## Flatten and sort this array
            eqVar = N.sort(N.ravel(eqVar))

            ## If the first element of the sorted array is 0,
            ## then at least one value in the 2 variables's data
            ## are different
            if (eqVar[0] == 0):
                return False
            else:
                return True

        ## Approximate 'all close' comparison
        ## simply pass everything to the Numeric.allclose function
        else:
            if (N.allclose(self, other, rtol, atol) == 1):
                return True
            else:
                return False
            

    ##--------------##
        
    def IOsubset(self, domainLst = None, layerLst = None, timeLst = None, \
                 coordFlag = llFlag, indexFlag = False, layindexFlag = True,\
                 copyFlag = True):

        """ Subsets the variable based on a spatial, temporal, or
        layer domain.
        
        Inputs:

            domainLst - List of coordinate tuples that define a
                        spatial domain of interest.  Inclusive of
                        endpoints.

                        Default = None -- i.e. whole domain

                        Example:
                            domainLst = [(-90.2, 38.), (-88.45, 42.)]
                        [SW corner, NE corner] of domain. Coordinates are
                        in x,y order:

                        where x is column # (0 based), longitude
                        (degrees E), or xlon (E-W meters from
                        projection center -- projection specific)

                        And y is row # (0 based), latitude (degrees
                        N), or ylat (N-S meters from projection
                        center -- projection specific)

                            domainLst = (-36000, 36000)
                        Coordinates are in xlon and ylat (in meters
                        from projection origin).  In this case,
                        ioapi2var will extract one point.

                        See typeFlag for specifics.

            layerLst -  List of layers to extract.

                        Example:
                            layerLst = [0, 4]
                            
                        In this case, will extract layers 0 through,
                        and including, 4.

                            layerLst = [2,2] OR layerLst = 2
                        In both cases, only extracts layer 2

                        Default = None -- i.e. all layers

            timeLst -   A time/date or list of dates that define a temporal
                        domain of interest.  Dates are mx.DateTime
                        objects, cdtime objects, or strings of the
                        form:
                            YYYY-MM-DD HH:MM:SS.SS
                        

                        Example:
                            timeLst = [startDate, endDate]

                        Where both startDate and endDate are
                        mx.DateTime objects.

                            timeLst = '1996-06-12 2:05'
                        In this case, it will extract only this date.

                        Default = None -- i.e. whole temporal domain
                        of this cctm file

                        If timeLst is a list of indices, make sure you
                        set indexFlag and use a 0 based integer index.

            coordFlag -  what type of coordinates are being used:
                        llFlag (1)      -   lon, lat (degrees)
                        projFlag (2)    -   xlon, ylat (meters) (see coordConv
                                            for more details)
                        crFlag (3)      -   col #, row # (0 based)

                        Default = llFlag
                        
            indexFlag  - True, time in indices (0 based)
                         False [Default], time is mx.DateTime object, cdtime
                                          or string.

            layindexFlag  - True [Default], layer in indices (0 based)
                            False, layer in sigma levels
                            
            copyFlag  -  True [Default] - copy data
                         False - share data
                         
        Output:
            iosubVar -  subset of the variable, iovar object.


        Notes / Assumptions:
        
            1.  If using indices, it returns the dimension
                inclusively. For example, layerLst = [0,2] will return
                a variable w/ layers 0,1, and 2.

            2.  If using time indices, the values must be integers.

            3.  If you are using a single coordinate for the spatial
                domain, there is a possibility that the spatial domain
                of isubVar will have length 2.  This is the case that
                the point of interest falls exactly on the boundary of
                2 cells.

            4.  Presently, only copyFlag = True is implemented.

            5.  The order of the subset matters.  For example, if you
                subset with:
                    timeLst = ['1996-06-25 12:00','1996-06-24 6:00']
                    
                the data will be reversed along the time axis.  In
                other words subVar[0] will refer to '1996-06-25
                12:00', subVar[1] will refer to '1996-06-25 11:00',
                etc. The same is true for the spatial subsets.  I
                recommend that you use spatial subsets which go from
                SW to NE corner to maintain the same spatial axes as
                the original variable.

            6.  Making vertical subsets w/ sigma layers may return
                more layers than expected.  This is because the sigma
                bounds go from sigma value - sigma value + 1 lev.  To
                gain more control over the vertical subsets, consider
                using a direct call.  For example, if you were
                interested in subsetting o3 by sigma range
                1.0 <= bounds <= .972:
                   >>> o3_sub = o3(level=(1.0, .972, 'ccb'))

                If you wanted to not include the next level, ie.have
                1.0 <= bounds < .972:
                   >>> o3_sub = o3(level=(1.0, .972, 'cob'))

                For more info on controlling the subsets, see cdms
                docs.

                
        """
        ##################################################
        ## Check each of the subdomains (space, time, etc)
        ##################################################
        ##if they are set to None, get the full domain

        ## create cdmsmeta object
        cdmsM = cdmsmeta(self, cdmsvarFlag)

        subVar = self
        
        ####################
        ## Spatial subdomain
        ####################
        if domainLst is not  None:

            ## if not a list, make a domain list w/ equal points
            if not isinstance(domainLst, list):
                domainLst = [domainLst, domainLst]

            ## Have a subdomain, check if coordinates in domain
            if not coordInDomain(self.ioM, cdmsM, domainLst[0], typeFlag=coordFlag):
                raise IndexError, "(lon,lat) = (%f, %f) is outside the grid's domain"\
                      %(domainLst[0][0], domainLst[0][1])
            if not coordInDomain(self.ioM, cdmsM, domainLst[1], typeFlag=coordFlag):
                raise IndexError, "(lon,lat) = (%f, %f) is outside the grid's domain" \
                      %(domainLst[1][0], domainLst[1][1])

            ## Define spatial subset, depends on coordFlag
            if coordFlag == llFlag:
                ## If in lat, lon (degrees) first convert to xlon, ylat
                ## convert to xlon and ylat
                coordOut = coordConv(self.ioM, domainLst, ll2projFlag)
                xLst = [coordOut[0][0], coordOut[1][0]]
                yLst = [coordOut[0][1], coordOut[1][1]]
            else:
                xLst = [domainLst[0][0], domainLst[1][0]]
                yLst = [domainLst[0][1], domainLst[1][1]]

            if coordFlag == crFlag:
                ## Using indices
                ## slices need to be 1 longer, so get endpoints
                spaceSel = cdms.selectors.Selector(latitude=slice(yLst[0], yLst[1] + 1),\
                                                   longitude = slice(xLst[0], xLst[1] + 1))
            else:
                ## using coordinates
                ## selecting via the bounds edge 'ccb'
                spaceSel = cdms.selectors.Selector(latitude=(yLst[0], yLst[1], "ccb"), \
                                                   longitude=(xLst[0], xLst[1], "ccb"))

            ## Make the subset
            subVar = subVar(spaceSel)
            

        ######################
        ## Temporal subdomain
        ######################

        timeindFlag = False 
        if timeLst is not None:    

            ## if date not a list but a single date, make a list
            ## w/ equal indices 
            if not isinstance(timeLst,list):
                timeLst = [timeLst, timeLst]

            if indexFlag:
                ## using indices

                ## If timeLst[0] is not 0, then will need to shift time index
                if timeLst[0] != 0:
                    timeindFlag = True

                ## slices need to 1 longer so get endpoints
                dateSel = cdms.selectors.Selector(time=slice(timeLst[0], timeLst[1] + 1))

            else:

                ## using dates

                ## Have a temporal range, check if dates in temporal domain
                if not dateInDomain(cdmsM,  timeLst[0]):
                    raise IndexError, "Date %s, not in var's date range"  %timeLst[0]
                if not dateInDomain(cdmsM,  timeLst[1]):
                    raise IndexError, "Date %s, not in var's date range"  %timeLst[1]

                ## If timeLst[0] is not equal to the first date of original
                ## timeAxis, then will need to shift time index
                dateTmp1 = dates2DateTime(timeLst[0])
                dateTmp2 = dates2DateTime(self.getTime().asComponentTime()[0])
                if dateTmp1 != dateTmp2:
                    timeindFlag = True

                startStr = "%s" %timeLst[0]
                endStr = "%s" %timeLst[1]
                ## Want to use "ccn" b/c only interested in nodes
                ## otherwise the axis bounds will create overselection
                dateSel = cdms.selectors.Selector(time=(startStr, endStr))

            ## Make the subset
            subVar = subVar(dateSel)
            
        ###################    
        ## Layer subdomain
        ###################    

        if layerLst is not None:
            
            ## if layer not a list but a single layer, make a list
            ## w/ equal layer indices 
            if not isinstance(layerLst, list):
                layerLst = [layerLst, layerLst]

            if layindexFlag:
                ## indices
                ## slices need to 1 longer so get endpoints
                layerSel = cdms.selectors.Selector(level=slice(layerLst[0], layerLst[1] + 1))


##             ## Have a layer range, check if layer in layer domain
##             if not layerInDomain(self.ioM, cdmsM, layerLst[0]):
##                 raise IndexError, "layer %d, not in var's layer range"  %layerLst[0]
##             if not layerInDomain(self.ioM, cdmsM, layerLst[1]):
##                 raise IndexError, "layer %s, not in var's layer range"  %layerLst[1]

            else:
                ## sigma layers
                layerSel = cdms.selectors.Selector(level=(layerLst[0], layerLst[1], "ccb"))

            ## Make the subset
            subVar = subVar(layerSel)
    

        ## Shift the time index to zero
        if timeindFlag and self._IOshiftFlag:
            startDate = subVar.getTime().asComponentTime()[0]
            subVar.IOshiftTimeInd(startDate)

            
        return subVar
    

    ##--------------##
        
    def IOclone(self):

        """ Creates a clone of the ioVar object.  This makes a copy of
        the data and the imbedded metadata objects

        Output:
            copyVar - copy of the iovar object
            
        """

        copyVar = copy.deepcopy(self)
        return copyVar
        
##         ## Need to get a clone of both the ioMeta object
##         ## and the cdms variable
##         ioMcopy = self.ioM.copy()

##         ## Get a copy of the axes
##         ## need to do this b.c axes are not copied when cdms does a clone
##         ## i.e. the same referents.  Need to make new axes

##         axesCopy = cdmsmeta(self, cdmsvarFlag).getAxes()
        
##         ## Create a new ioVar object 
##         result = createVariable(self, ioMcopy, axesCopy, copyFlag = True)
##         return result

    ##--------------##
        
    def IOmodVar(self, vname = None, vunits = None, desc = None):

        """ Modify some of the variable metadata.  In particular:
        name, unit, description

        Input:
             vname - variable name, string

             vunits - variable units, string

             desc - variable description, long name, string
             
        """

        if vname is not None:
            ## Change variable id and name
            self.id = vname
            self.name = vname

        if vunits is not None:
            ## Change variable units
            self.units = vunits
            
        if desc is not None:
            ## Change variable var_desc and long_name
            self.var_desc = desc
            self.long_name = desc

        ## Need to update ioM attribute so it reflects
        ## the latest changes to variable metadata
        self.ioM.updateFromVar(self)

        
    ##--------------##
        
    def IOchangeDate(self, startDate, unit="hours"):

        """ Changes the start date of the time axis.

        Input:

            startDate - start date as mx.DateTime object, cdtime
                        object or string of form:
                           YYYY-MM-DD HH:MM:SS.SS

            unit      - time units. Default is 'hours'.  If you
                        want daily data, change to 'days'

        Example:
            If the original time axis had a range:
                 1999-06-24 6:00 --> 1996-06-25 5:00

            After calling:
                IOchangeDate('1996-01-12 12:00')
            new temporal range:
                 1996-01-12 12:00 --> 1996-01-13 11:00'
        """

        ## Construct the time units
        ## For example, if old units where 'days since 1996-06-24 6:00'
        ## Get the unit 'days' and construct new units from start date:
        ## 1996-06-30 6:00, i.e. 'days since 1996-06-30 6:00'
        newunits = "%s since %s" %(unit, startDate)

        ## Change the variables timeAxis
        self.getTime().units = newunits

        
    ##--------------##
        
    def IOshiftTimeInd(self, startDate):
        """
        Shifts the time axis values.  This preserves
        the actual dates, but changes the start date and
        axes values.

        Input:
           startDate - start date as mx.DateTime object,
                       cdtime object or string of form:
                         YYYY-MM-DD HH:MM:SS.SS

        Note/Assumptions:
        
           1.  Internal function.  Should not be used by normal users.
        
        """
        

        ## get a copy of the time axis
        timeAxis = self.getTime().clone()
        
        ## Construct the time units
        ## For example, if old units where 'days since 1996-06-24 6:00'
        ## Get the unit 'days' and construct new units from start date:
        ## 1996-06-30 6:00, i.e. 'days since 1996-06-30 6:00'
        oldunits = timeAxis.units
        unit = oldunits.split()[0]
        newunits = "%s since %s" %(unit, startDate)

        ## Take the time values as cdtime component times
        ## convert them to cdtime relative times w/ the new units
        ## e.g. 0. days since 2004-12-10 18:00 -->
        ##      9. days since 2004-12-01 18:00
        ## this preserves the date but shifts the values
        ## of timeAxis.getValue()

        compLst = timeAxis.asComponentTime()
        relLst = [date.torel(newunits) for date in compLst]

        ## Create an array of time values
        valLst = [date.value for date in relLst]
        valArr = N.array(valLst, "f")

        ## Assign these values to timeAxis and change
        ## timeAxis' units to newunits
        self.getTime().assignValue(valArr)
        self.getTime().units = newunits

    ##--------------##
        
    def IO2cdms(self, copyFlag = True):

        """ Returns a cdms transient variable.  Retains all attributes
        and axes, does not contain projection and ioapi specific
        metadata (ioM).

        Input:
           copyFlag  - True [Default] - copy the variable's data
                       False - share variable's data

        Output:
            cdmsVar  - a cdms transient variable
        """
        if copyFlag:
            cdmsVar = cdms.createVariable(self, copy=1)
        else:
            cdmsVar = cdms.createVariable(self, copy=0)

        ## Remove the ioM attribute
        del(cdmsVar.ioM)
        
        return cdmsVar


    ##--------------##
        
    def IOcoordConv(self, coordLst, typeFlag = ll2projFlag,\
                    cellLocFlag = crossFlag):

        """ Converts b/w different types of spatial coordinates.


        Inputs:
            coordLst -  List of coordinate tuples to be converted.
                        Example:
                          converting multiple points:
                            coordLst = [(-90.2, 40.), (-78.45, 42.3), (-88.1, 44.2)]
                          converting a single point:
                            coordLst = (-76.4, 34.91)

                        Coordinates are in x,y order:
                        where x is column # (0 based), longitude (degrees E), or
                        xlon (E-W meters from projection center -- projection
                        specific)

                        And y is row # (0 based), latitude (degrees N), or
                        ylat (N-S meters from projection center -- projection
                        specific)
                        (See typeFlag below)

            typeFlag -  indicates conversion between which 2 'coordinates systems':

                ll2projFlag (1) -   lon, lat (degrees) --> xlon, ylat (meters)
                                    [Default]

                ll2crFlag (2)   -   lon, lat (degrees) --> col #, row #  (0 based)

                proj2llFlag (3) -   xlon, ylat (meters) --> lon, lat (degrees)   

                proj2crFlag (4) -   xlon, ylat (meters) --> col #, row # (0 based)

                cr2llFlag (5)   -   col #, row # (0 based) --> lon, lat (degrees)

                cr2projFlag (6) -   col #, row # (0 based) --> xlon, ylat (meters)


            cellLocFlag - Where in the cell to locate the point:
                crossFlag (1)   -   center of cell [Default]
                SWFlag (2)      -   Southwest corner of cell
                SEFlag (3)      -   Southeast corner of cell
                NEFlag (4)      -   Northeast corner of cell
                NWFlag (5)      -   Northwest corner of cell

                Only  meaningful for cr2ll or cr2proj conversion.


        Returns:

            convCoordLst - List of coordinate tuples that have been
                            converted from coordLst.  The list has a
                            similar format to coordLst, but also has a z
                            value:		
                            [(x1,y1,z1), (x2,y2,z2),...]

                            Conversions from cells, cr2proj and cr2ll, only have
                            spatial coordinates:
                            [(x1,y1), (x2,y2), ...]

                            See coordLst and typeFlag above for format and
                            coordinate types specifics.

        Notes/Assumptions:

            1.  z coordinates (vertical distance) are simply passed
                through to the projection software.  In most cases, the z
                value will simply be returned w/o modification.

            2.  Projections presently supported:
                    Lambert Conformal Conic

            3.  Grid cells are assumed to be regularly spaced in the
                projection coordinate system. For example, the grid cells
                might be 4000 x 6000 meters in a lambert conformal
                coordinate system.  When they are transformed to lon/lat
                or if you imagine them on the surface of the earth, they
                will NOT be regularly spaced or equal area.

            4.  Out of domain errors are only checked for conversions from
                cr (col,row). Otherwise, coordConv will calculate the new
                coordinates w/o warning, even if they are outside the
                extent of the grid domain.  To test for domain errors, use
                the function coordInDomain.

            5.  For conversions to or from col,row, one needs to pass
                cdmsM, a cdmsMeta object.

            6.  For conversions to col,row, coordinates that exactly hit
                the boundary between 2 cells are promoted to the larger
                col or row number.  For example, if the boundary b/w row
                30 and 31 is at 24000, then a ylat value of 24000 will be
                converted to row 31.  The one exception is the North or
                East edge of the domain.  A coordinate exactly on these
                boundaries will be demoted to the last col or row.

            7.  One should be careful with ll2cr conversions near the
                boundary.  A coordinate that is very near the domain
                boundary may be determined as outside the boundary during
                the intermediary conversions.  This is due to the problem:

                     xlon1,ylat1 -- > lon, lat --> xlon2, ylat2
                Where, xlon1, ylat1 are slightly different than xlon2, ylat2


            8.  Simply a wrapper around coordConv function
            
        """

        ## Create ioM and cdmsM
        ioM = self.ioM.copy()
        cdmsM = cdmsmeta(self, cdmsvarFlag)

        ## call coordConv
        convCoordLst = coordConv(ioM, coordLst, typeFlag, cdmsM, \
                                 cellLocFlag)

        return convCoordLst


    ##--------------##
        
    def IOcoordInDomain(self, coord = (0,0,0), typeFlag = llFlag, \
                      domainFlag = False, testProj = True, fourCorners=False):

        """ Simply tests whether or not a coordinate is in the grid's
            spatial domain.

        Input:
            coord - coordinate tuple to be tested.
                        Example:
                            coord = (-90.2, 40.)
                        Coordinates are in x,y order:

                        where x is column # (0 based), longitude (degrees E), or
                        xlon (E-W meters from projection center -- projection
                        specific)

                        And y is row # (0 based), latitude (degrees N), or
                        ylat (N-S meters from projection center -- projection
                        specific)

                        (See typeFlag below)

            typeFlag -  what type of coordinates are being used:
                    llFlag (1)      -   lon, lat (degrees) [Default]
                    projFlag (2)    -   xlon, ylat (meters) (see coordConv for
                                        more details)
                    crFlag (3)      -   col #, row # (0 based) Should be integers,
                                        see Notes below.

            domainFlag - True. Returns the domain extent as a coordLst:
                                [(xminDomain, yminDomain, zminDomain),
                                (xmaxDomain, ymaxDomain, zmaxDomain)]
                                Coordinates reflect the typeFlag.  When
                                this flag is set, coord is ignored.  For
                                projection and lon,lat coordinates, this
                                is the external edge of the 1st and last
                                grid cells.

                                zmin and zmax indicate the top and bottom
                                layer for crFlag.  Otherwise, zmin and
                                zmax are set to 0

                         False. Default. Checks the coord.

            testProj   -  True, use the proj coordinates as a regular grid.
                                means that if coord in lon/lat it is
                                first converted to proj to test extent.
                                [Default]

                          False, if typeFlag is llFlag, use the domain as if
                                it was a regular grid.

            fourCorners - True, if domainFlag, return the domain as a 4
                                corner list: [SW,SE, NE, NW]
                          False, return normal domain [SW,NE]  (Default)    
        

        Returns:
            True    -   coordinate within the grid's domain

            False   -   coordinate outside of grid's domain

            If domainFlag is True - returns domain range as a coordLst:
                                [(xminDomain, yminDomain, zminDomain),
                                (xmaxDomain, ymaxDomain, zmaxDomain)]
                                Coordinates reflect the typeFlag.  When this flag
                                is set, coord is ignored.

                                zmin and zmax indicate the top and bottom layer for crFlag.
                                Otherwise, zmin and zmax are set to 0


        Notes/Assumptions:

            1.  z coordinates (vertical distance) is not tested.

            2.  For crFlag, a return of True means that there is an exact
                match.  For example if the cols are 0 - 50, a coord of 40
                would return True, a coord of 40.2 would return False.

            3.  If you are using a coord of type lon/lat, the default
                test converts coord to proj coordinates to test if the
                coord is w.in the domain.  Because lon/lat is an
                irregular grid, the fact that a coord is w/in the SW
                and NE corners doesn't guarantee that the coordinate
                actually falls in the domain.  By setting the testProj
                flag to True (Default), this will perform the test
                w/in the regular coordinate system, proj.
    
           4.  Simply a wrapper around coordInDomain

        """     

        ## Create ioM and cdmsM
        ioM = self.ioM.copy()
        cdmsM = cdmsmeta(self, cdmsvarFlag)

        ## Call coordInDomain
        result = coordInDomain(ioM, cdmsM, coord, typeFlag, \
                               domainFlag, testProj, fourCorners)
        return result
    
    ##--------------##
        
    def IOdateInDomain(self, testDate, simpleFlag = True):

        """ Tests if date is in temporal domain.

        Input:

            testDate - date to test, mx.DateTime object, cdtime object, or
                       string of form:
                       YYYY-MM-DD HH:MM:SS.SS

                       e.g. '1996-07-12 2:00'

            simpleFlag - True [Default] simply tests if w.in temporal domain
                         False - checks if date exactly matches one of the dates
                                 in the timeAxis

        Return:
            True - in domain
            False - not in domain

        Note:

            1.  If simpleFlag is False, only returns true if testDate is
            an exact match to one of the dates from timeAxis.

            2.  Wrapper around dateInDomain
            
        """
        ## Create cdmsM
        cdmsM = cdmsmeta(self, cdmsvarFlag)

        ## Call dateInDomain
        result = dateInDomain(cdmsM, testDate, simpleFlag)
        return result

    ##--------------##
        
    def IOlayerInDomain(self, testLay, simpleFlag = True):

        """ Tests if layer in layer domain
    .   
        Input:

            testLay - sigma layer

            simpleFlag - True [Default] simply tests if w.in layer domain
                         False - checks if layer exactly matches one of the sigma
                                 layers in the layAxis

        Return:
            True - in domain
            False - not in domain

        Note:

           1.  Assumes that sigma layers go from highest value to smallest value.
           2.  Wrapper around layerInDomain

        """
        ## Create cdmsM
        cdmsM = cdmsmeta(self, cdmsvarFlag)

        ## Call layerInDomain
        result = layerInDomain(cdmsM, testLay, simpleFlag)
        return result

    ##--------------##
        
    def contour(self, *args, **kwargs):
        """
        Makes a contour plot of the variable (see contour function
        documentation).  Identical arguments and key word arguments as
        the function 'contour' except that you shouldn't pass 'var'.

        """

        ## Create a new args list w/ self prepended
        newargs = list(args)
        newargs.insert(0,self)

        ## pass everything to function contour and return cDct
        cDct = contour(*newargs, **kwargs)
        return cDct

    ##--------------##
        
    def ocontour(self, *args, **kwargs):
        """
        Overlays a contour plot of the variable onto another plot (see
        ocontour function documentation).  Identical arguments and key
        word arguments as the function 'ocontour' except that you
        shouldn't pass 'var'.

        """

        ## Create a new args list w/ self prepended
        newargs = list(args)
        newargs.insert(0,self)

        ## pass everything to function ocontour and return cDct
        cDct = ocontour(*newargs, **kwargs)
        return cDct
    
#----------------------------------------------------------------#
def createVariable(data, ioM, axes = None, id = None, attributes = None,\
                   copyFlag = True):

    """ Creates an ioVar object.

    Input:
       data - a data array. The data array can be a
              Numeric, MV, cdmsVariable or an ioVar.


       ioM - iometa object.

       axes - cdms axes list [time, layer, latitude, longitude]

       id - identifier of variable

       attributes - dictionary of attribute values

       copyFlag - True [default] - copy the data
                  False - share the data

    Output:
       ioVar - iovar object

    Notes/Assumptions:
    
       1.  If you are passing a cdms or iovar variable, you will not
           need to give axes, id, or attributes.  These will simply be
           taken from the variable's metadata.  If you are passing a
           Numeric array, you will need to provide the axes, id, and
           attributes.

       2.  The iovar inherits many of its properties from cdms
           transient variables.  See cdat's documentation for more
           specifics.
    
    """

    ioVar = iovar(data, ioM, axes, id, attributes, copyFlag)
    return ioVar


#--------------------------------------------------------------------------#
class cdmsmeta(object):

    """ cdmsmeta class: basically the spatial and temporal axes.
    creates the meta data needed for a cdms file.

    Notes/Assumptions:
        1.  Presently, only Lambert Conformal Conic is supported.

        2.  For Lambert Conformal, xlonAxis and ylatAxis are in meters
            from the x and y origin of the coordinate system.

            
    """
    def __init__(self, ioFile, typeFlag = iofileFlag):
        """ init
        
        Inputs:
            ioFile - iofile object or cdms/iovar object

            typeFlag - iofileFlag, iofile from ioapi
                       cffileFlag, iofile from CF netCDF
                       cdmsvarFlag, cdms or iovar variable
            
        """

        if typeFlag == iofileFlag:
            ################
            ## spatial axes
            ################

            ## Create xlat and ylon axes
            ## (this is in meters from proj center)
            ## include bounds
            cdms.setAutoBounds(True)
            self.ylatAxis = cdms.createAxis(ioFile.getYlats())
            self.xlonAxis = cdms.createAxis(ioFile.getXlons())
            self.ylatAxis.id = "yLat"
            self.xlonAxis.id = "xLon"
            self.ylatAxis.units = ioFile.ioM.yunits
            self.xlonAxis.units = ioFile.ioM.xunits


            # Used to associate axes w/ grid_map (see iometa)
            self.ylatAxis.standard_name="projection_y_coordinate"  
            self.xlonAxis.standard_name="projection_x_coordinate"
            self.xlonAxis.long_name = "x coordinate of projection"
            self.ylatAxis.long_name = "y coordinate of projection"
            
            ## designate ylatAxis as latitude and xlonAxis as longitude,
            ## set modulo = None, so the axis is linear
            self.ylatAxis.designateLatitude(persistent = True)
            self.xlonAxis.designateLongitude(persistent=True, modulo=None)
            

            ##############################
            ## Create time and layer axes 
            ##############################

            ## Turn autobounds off for level and time axes
            cdms.setAutoBounds(False)
            
            ## Get layer axis
            ## At moment, only reference to layers is through layer index
            tmpArray = ioFile.vertcoords
            ## create bounds, for layerAxis this is in sigma
            ## each sigma value is for the bottom of the layer
            ## so the bounds for layer 0 is sigma0 and sigma1
            boundsLst = []
            for i in xrange(len(tmpArray[:-1])):
                boundsLst.append([tmpArray[i], tmpArray[i+1]])

            ## chop off last 0 value
            boundsA = N.array(boundsLst)
            self.layAxis = cdms.createAxis(tmpArray[:-1], bounds=boundsA,\
                                           copy=1)  
            self.layAxis.id="layer"
            self.layAxis.var_desc = "sigma levels"
            self.layAxis.positive = "down"
            self.layAxis.designateLevel()
            ## Define axis standard name -- CF compliant sigma
            self.layAxis.standard_name = "atmospheric_sigma_coordinate"
            

            ## setup time axis
            self.timeAxis = cdms.createAxis(ioFile.getTimes())
            self.timeAxis.designateTime(calendar=cdtime.MixedCalendar)
            self.timeAxis.id="time"
            if ioFile.tstep == 10000:
                self.timeAxis.units = "hours since %s" %(ioFile.start)
            elif ioFile.tstep == 240000:
                self.timeAxis.units = "days since %s" %(ioFile.start)
            else:
                print "Unknown timestep %d, defaulting to hours" %ioFile.tstep
                self.timeAxis.units = "hours since %s" %(ioFile.start)
                
            ## setbounds on the time axis (needed for binAverager)
            ##cdutil.setTimeBoundsDaily(self.timeAxis, 24)


        elif typeFlag == cffileFlag:
            ## Axes have been already properly set
            ## just get them from the cdms file handle
            
            cfFile = ioFile
            self.timeAxis = cfFile.f.getAxis("time")
            self.layAxis = cfFile.f.getAxis("layer")
            self.ylatAxis = cfFile.f.getAxis("yLat")
            self.xlonAxis = cfFile.f.getAxis("xLon")


        elif typeFlag == cdmsvarFlag:
            ## cdms or iovar, simply copy the axes
            ## assumes that axes have been designated as time,level,
            ## latitude and longitude
            inVar = ioFile
            self.timeAxis = inVar.getTime().clone()
            self.layAxis = inVar.getLevel().clone()
            self.ylatAxis = inVar.getLatitude().clone()
            self.xlonAxis = inVar.getLongitude().clone()
            
        else:
            raise KeyError, "Currently not implemented"
        

    def copy(self):
        return copy.deepcopy(self)
    
    def getAxes(self, copyFlag = True):

        if copyFlag:
            ## get a clone of eaech of the axes
            axes = [self.timeAxis.clone(), self.layAxis.clone(), \
                    self.ylatAxis.clone(), self.xlonAxis.clone()]
        else:
            ## send back the originals
            axes = [self.timeAxis, self.layAxis, self.ylatAxis, self.xlonAxis]

        return axes
    
    def latlonAxes(self, ioM):
        """
        Generate lat and lon cdms variables as functions of ylat and xlon:
          lat(yLat,xLon)
          lon(yLat,xLon)

        Also generates the bounds of these cells (4 corners), irregular grid:
          lat_bounds(ylat,xlon,4)
          lon_bounds(ylat,xlon,4)
          
        Only necessary if you are writing CF compliant netCDF.

        Input:
           ioM    - iometa object, contains projection info
           
        Output:
           axes   - tuple (lat, lon, lat_bounds, lon_bounds),
                           where each element is a cdms variables.

        Note/Assumptions:

          1.  Internal method, not for general use.
          
          2.  The lon and lat coordinates (in Degrees) are a non-regular grid.

          3.  The bounds for each grid cell are the corners of the cell in
              degrees.  The order is [SW, SE, NE, NW]
              
        """

        ## Create all combinations of xlon and ylat, convert to lat/lon
        coordLst = [(x,y) for y in self.ylatAxis.getData() for x in \
                    self.xlonAxis.getData()]
        coordOut = coordConv(ioM, coordLst, proj2llFlag)

        ## Get just the lat (yVect) and lon (xVect) values, convert them to
        ## 2-D arrays
        xVect = [tmp[0] for tmp in coordOut]
        yVect = [tmp[1] for tmp in coordOut]
        xArray = N.reshape(N.array(xVect), (len(self.ylatAxis),\
                                            (len(self.xlonAxis))))
        yArray = N.reshape(N.array(yVect), (len(self.ylatAxis),\
                                            (len(self.xlonAxis))))

        ## Make the cdms variables lat,lon -- the alternative axes
        lon=cdms.createVariable(xArray,axes=(self.ylatAxis, self.xlonAxis), \
                                id="lon")
        lat=cdms.createVariable(yArray,axes=(self.ylatAxis, self.xlonAxis), \
                                id="lat")
        lon.long_name="longitude"
        lon.units="degrees_east"
        lat.long_name="latitude"
        lat.units="degrees_north"


        ## Create the boundary cells.  This is all combinations of the
        ## bounds of ylat and xlon Needed for non-regular grid.  This
        ## boundary needs 4 boundary points for each lon,lat pair (x)
        ## in the diagram below.  The numbers correspond to the order
        ## of the ylat, xlon bounds pairs converted to degrees N,E:
        ##     4           3
        ##
        ##          x
        ##
        ##   1         2

        ## Get rows and cols, 0 based index
        ## Create all combinations
        rows = range(len(self.ylatAxis))
        cols = range(len(self.xlonAxis))

        coordCR = [(x,y) for y in rows for x in cols]

        ## Get lon lat for each corner of the grid cell
        SWbounds = coordConv(ioM, coordCR, cr2llFlag, self, SWFlag)
        SEbounds = coordConv(ioM, coordCR, cr2llFlag, self, SEFlag)
        NEbounds = coordConv(ioM, coordCR, cr2llFlag, self, NEFlag)
        NWbounds = coordConv(ioM, coordCR, cr2llFlag, self, NWFlag)

        ## Create lon and lat bounds, grouped in 4's to match
        ## 4 corners of each grid, called here a cell
        lonCell = []
        latCell = []
        for i in range(len(coordCR)):
            lonCell.append([SWbounds[i][0], SEbounds[i][0], NEbounds[i][0], \
                            NWbounds[i][0]])
        for i in range(len(coordCR)):
            latCell.append([SWbounds[i][1], SEbounds[i][1], NEbounds[i][1], \
                            NWbounds[i][1]])

        ## Create cdms variables as functions of xlon and ylat
        bounds_lon = cdms.createVariable(lonCell, id = "bounds_lon")
        bounds_lat = cdms.createVariable(latCell, id = "bounds_lat")
        bounds_lon=MV.reshape(bounds_lon,(len(self.ylatAxis),len(self.xlonAxis),4))
        bounds_lon.setAxis(0,self.ylatAxis)
        bounds_lon.setAxis(1,self.xlonAxis)
        bounds_lon.id='bounds_lon'

        bounds_lat=MV.reshape(bounds_lat,(len(self.ylatAxis),len(self.xlonAxis),4))
        bounds_lat.setAxisList(bounds_lon.getAxisList())
        bounds_lat.id='bounds_lat'

        # Associate bounds to lon/lat axes
        lon.bounds="bounds_lon"
        lat.bounds="bounds_lat"
       
        return (lat, lon, bounds_lat, bounds_lon)


#----------------------------------------------------------------#

def concatenate(varLst):

    """ Concatenates a series of variables into one variable.

    Input:
       varLst - a list of variables to concatenate.

    Output:
       ioVar - iovar object, concatenation of all variables
               in varLst
               
    Notes/Assumptions:
    
     1.  Only concatenates along the time axis.  All other axes should
         be identical.

     2.  Assumes that the order of varLst is in temporal order and the
         variables' time axes do not overlap.

     3.  Uses the first variable in varLst to define metadata
         for the return variable.
         
    """
    if not isinstance(varLst, list):
        raise KeyError, "Must pass a list of ioapi variables"

    ## Assumption is that the variables are in temporal order
    ## Get first time
    startDate = varLst[0].getTime().asComponentTime()[0]

    ## Copy the variables into a new list
    ## Shift all the variables time axes to same start date
    varLst2 = [var.IOclone() for var in varLst]
    for var in varLst2:
        var.IOshiftTimeInd(startDate)


    ## Concatenate the variables along the time axis
    varTmp = MV.concatenate(varLst2, axisid="time")

    ## Create a new iovar, use the ioM and attributes from the first
    ## variable
    ioVar = createVariable(varTmp, varLst2[0].ioM, id = varLst2[0].id, \
                           attributes = varLst2[0].attributes)
                           
    return ioVar

#----------------------------------------------------------------#

def combineMeta(varLst):

    """ Combines the metadata from a series of variables.

    Input:
       varLst --  a list of variables that you want to combine
                  their metadata.  They should be iovar objects.
    Output:
       metaNew -- a tuple consisting of (ioM, cdmsM).  Where ioM
                  is the new iometa object for all the variables, and
                  cdmsM is the cdmsmeta object for the variables.

    Notes/Assumptions:
    
       1.  The ioM and cdmsM are based primarily on the first variable
           in varLst.

    """

    if not isinstance(varLst, list):
        raise KeyError, "Must pass a list of variables"

    ## Get the names, units and desc of each of the variables
    vnameLst = []
    vunitsLst = []
    vdescLst = []
    for var in varLst:
        vnameLst.append(var.id)
        vunitsLst.append(var.units)
        vdescLst.append(var.var_desc)

    ## Get a copy of the first iometa object and modify its
    ## variable info so reflects all the variables
    im2 = varLst[0].ioM.copy()
    im2.replVar(vnameLst, vunitsLst,vdescLst)

    ## Create a cdmsmeta object from the first variable
    ## assumption is that all the variables have same axes
    cm2 = cdmsmeta(varLst[0], typeFlag = cdmsvarFlag)

    return (im2,cm2)

#----------------------------------------------------------------#

def dates2DateTime(indate):
    
    """ Converts dates to mx.DateTime objects

    input:
        indate -- a string or cdtime object of a properly formatted date.

    Output:
        DateTime object corresponding to indate

    Note:
       1.  proper string format:  'YYYY-MM-DD HH:MM:SS.SS'
           eg.  '1996-02-14 6:00:01'
    
    """

    ## If cdtime, extract elements for DateTime object
    try: oDate = D.DateTime(indate.year, indate.month, indate.day, indate.hour, \
                            indate.minute, indate.second)

    ## otherwise, assume properly formatted date
    except: oDate = D.DateTimeFrom(indate)


    ## return the date object
        
    return oDate
#----------------------------------------------------------------#

def dates2Cdtime(indate):

    """ Converts dates to cdtime objects

    input:
        indate -- a string or DateTime object of a properly formatted date.

    Output:
        cdtime object corresponding to indate

    Note:
       1.  proper string format:  'YYYY-MM-DD HH:MM:SS.SS'
           eg.  '1996-02-14 6:00:01'
    
    """

    ## Convert to DateTime object preemptively
    tmpDate = dates2DateTime(indate)
    
    ## Convert to cdtime
    oDate = cdtime.componenttime(tmpDate.year, tmpDate.month, tmpDate.day,\
                                 tmpDate.hour, tmpDate.minute, int(tmpDate.second))

    ## return the cdtime object
        
    return oDate

#----------------------------------------------------------------#
def scan(searchStr, startDate, endDate, fastSort=True):

    """ Scans files for the date range.  Opens up each of the files
        (making a list of iofiles) for variable extraction.

        Input:
            searchStr - a search string

            startDate - beginning date

            endDate - last date.

            fastSort - T use sort based on file names (default)
                       F actually open files and compare dates

        Output:
            ioScan - iofilescan object.

        Notes/Assumptions:

          1.  Search string is of unix form, use '*' for wild card.
              For example the search string 'CCTM_CONC.D1.*' will
              match:
                 CCTM_CONC.D1.001, CCTM_CONC.D1.033.nc, ...
                  
          2.  Search string should only match files of a single file
              type (either all ioapi format or all cf netcdf format).

          3.  A sort of the file names should put them in temporal order.
              If it doesn't, set fastSort = False and it will test
              each file

          4.  Only used for extraction, not for writing. See ioScan.extract.

    """
    
    ioScan = iofilescan(searchStr, startDate, endDate, fastSort)
    return ioScan
                            
    
#----------------------------------------------------------------#
class fileindex(object):
    """
    Very small object used to store the iofile and date indices.
    Generated by date2Files.

    Note/Assumptions:

       1.  Internal function.  Should not be used by normal users.

    """
    def __init__(self, ioFile, startInd, endInd):
        """
        Very small object used to store the iofile and date indices.
        Generated by date2Files.

        Note/Assumptions:

           1.  Internal function.  Should not be used by normal users.

        """

        self.ioFile = ioFile
        self.startInd = startInd
        self.endInd = endInd
    
#----------------------------------------------------------------#

def date2Files(searchStr, startDate, endDate, fastSort=True):

    """ Determines a list of cctm files that span a date range.  Given
        a basename (path plus file identifier) and a start and end
        date, it will return a dictionary of files that span that date
        with the appropriate index from each file.

        Input:
            searchStr    -  identifier for files to search.  Uses a unix
                            type wildcard.  For example:
                            '/data/CCTM_CONC.D1.00*'
                            will match files:
                               /data/CCTM_CONC.D1.001
                               /data/CCTM_CONC.D1.002
                               /data/CCTM_CONC.D1.009.nc

                            But will not match:
                               /data/CCTM_CONC.D1.020
                               

            startDate   -   first date of interest.  This is a mx.DateTime object,
                            cdtime object or string.


            endDate   -     end date of interest.  This is a mx.DateTime object,
                            cdtime object or string.
            fastSort - T use sort based on file names (default)
                       F actually open files and compare dates

        Returns:
            indexDict   -   Dictionary, keys are the filenames , values are
                            fileindex objects which have attributes: iofile
                            handle (still open), startInd, endInd.

                            Where startInd is the time index to begin
                            extracting data from, and endInd is the
                            last index w/in this file to extract data
                            from.

    Note/Assumptions:

       1.  Internal function.  Should not be used by normal users.

       2.  A sort of the file names should put them in temporal order.
           If it doesn't, set fastSort = False and it will test each
           file

                            
    """

    ## Convert dates to DateTime objects
    startDate = dates2DateTime(startDate)
    endDate = dates2DateTime(endDate)

        ## Check that startDate and endDate are reasonable
    if (endDate < startDate):
        raise KeyError, "ERROR: end date %s precedes the start date %s" %(endDate, startDate)
    
               
    ################
    ## Input data
    ################

    ### TO DO:  Add some testing of the files so that only dealing w/ valid ioapi files.
    
    ## Get a list of all the CMAQ input files w/ this search string
    searchStr = os.path.expanduser(searchStr)
    inLst = glob(searchStr)
    nFiles = len(inLst)
    if (nFiles== 0):
        raise LookupError, "ERROR: no files w/ this regular expression %s" %(searchStr)

    ## Assumes that the sort function will put them correctly
    ## in numerical order
    ## This causes problems w/ some naming conventions, so need to
    ## explicitly use compare function to test start dates
    if fastSort:
        inLst.sort()
    else:
        inLst.sort(filetimeCmp)
    

    ###########################################
    ## Get date range and the metadata
    ###########################################

    ## NOTE: using DateTime over cdtime b/c it is more powerful.  

##    if onedayFlag:   ## if only one day force first file to input file
##        inLst[0] = onedayFile  

    ## Get iofile from 1st and last file in the list
    firstFile = iofile(inLst[0])
    lastFile = iofile(inLst[-1])

    ## Get first and last valid dates in sequence of files
    origDate = dates2DateTime(firstFile.cdmsM.timeAxis.asComponentTime()[0])
    lastDate = dates2DateTime(lastFile.cdmsM.timeAxis.asComponentTime()[-1])

    ## Check that startDate and endDate are w/in bounds of files
    if (endDate < startDate):
        raise KeyError, "ERROR: end date %s precedes the start date %s" %(endDate, startDate)
        sys.exit(1)
    if (startDate < origDate):
        raise KeyError, "ERROR: start date %s precedes the 1st file %s" %(startDate, origDate)
        sys.exit(1)
    if (endDate > lastDate):
        raise KeyError, "ERROR: end date %s is past the last file %s" %(endDate, lastDate)
        sys.exit(1)

    ###########################
    ## Loop through each file
    ###########################

    ## Basic idea is want to see if the startDate and EndDate are
    ## in this file.


    indexDict = {}
    # setup last file's end date as preceding start date
    lastEndDate = startDate - D.oneHour 
    
    for i in range(len(inLst)):
        presFile = iofile(inLst[i])
        fileStartDate = dates2DateTime(presFile.cdmsM.timeAxis.asComponentTime()[0])
        fileEndDate = dates2DateTime(presFile.cdmsM.timeAxis.asComponentTime()[-1])

        #######################################
        ## Determine if getting data from file
        #######################################

        if startDate > fileEndDate:
            ## close iofile handle
            presFile.close()

            ## don't need anything from this file
            continue
        
        
        elif startDate <= fileStartDate:
            ## Getting data from first time step
            startInd = 0

        else:
            ## Getting data from some index other than 0 on
            diff = startDate - fileStartDate
            startInd = diff.hours

        ## end index
        if endDate < fileStartDate:
            ## endDate precedes this file
            presFile.close()
            break
        
        elif endDate >= fileEndDate:
            ## endDate after this file, get last index
            diff = fileEndDate - fileStartDate
            endInd = diff.hours

        elif (endDate == fileStartDate) and (fileStartDate <= lastEndDate):
            ## Case when already got data from last file and don't need
            ## anymore data from this
            presFile.close()
            break
        
        else:
            ## endDate  w/in the file
            diff = endDate - fileStartDate
            endInd = diff.hours

        ## If there is an overlap b/w files then modify the index so
        ## that the start is offset. i.e. getting data from preceding file
        ## not from both files for the same dates
        if fileStartDate <= lastEndDate:
            diff = lastEndDate - fileStartDate
            startInd = diff.hours + 1
    
        ## Record file and indeces in the dictionary
        indexDict[inLst[i]] = fileindex(presFile, startInd, endInd)
        
        ## update last file date to the end of this file
        lastEndDate = fileEndDate


    ## return index Dictionary
    return indexDict


#-------------------------------------------------------------------------#

def iom2proj(ioM, coordsys = "NAD83", falseEast = 0, falseNorth = 0):

    """ Converts a iometa object projection info into an osr object.
       The osr object is used by gdal for all projection conversions.
       
     Inputs:
        ioM  -  iometa object

        coordsys - coordinate system.  Default is 'NAD83'.  See osr/gdal
                   documentation for acceptable coordinate systems

        falseEast - false easting, in coordinates of projection.  Default is 0.

        falseNorth - false northing, in coordinates of projection. Default is 0.

     Returns:
	   proj - osr object.  Can be used for osr and gdal coordinate
                  transformations. 

     Notes:

       1.  Internal function.  Should not be used by normal users.

       2.  Presently only supports the following projections:
	         Lambert Conformal Conic

            
     """

    ## Need to setup a seperate entry for each projection under each action

    ## Create osr object

    proj = None

    ## if lambert conformal
    if ioM.projectionName == "Lambert Conformal Conic":

        projLam = osr.SpatialReference()
        projLam.SetProjCS(ioM.gridName)

        projLam.SetWellKnownGeogCS(coordsys)
        projLam.SetLCC(ioM.standparallel1, ioM.standparallel2,
                       ioM.ycent, ioM.xcent, falseEast, falseNorth)

        proj = projLam

    else:
        raise LookupError, "Projection name, %s, currently not supported." %ioM.projectionName

    return proj
    
    
#-------------------------------------------------------------------------#

def coordConv(ioM, coordLst, typeFlag = ll2projFlag,\
              cdmsM = None, cellLocFlag = crossFlag):

    """ Converts b/w different types of spatial coordinates.


    Inputs:
        ioM -      Projection and domain info.  IoM is a ioMmeta object 

        coordLst -  List of coordinate tuples to be converted.
                    Example:
                      converting multiple points:
                        coordLst = [(-90.2, 40.), (-78.45, 42.3), (-88.1, 44.2)]
                      converting a single point:
                        coordLst = (-76.4, 34.91)

                    Coordinates are in x,y order:
                    where x is column # (0 based), longitude (degrees E), or
                    xlon (E-W meters from projection center -- projection
                    specific)
                    
                    And y is row # (0 based), latitude (degrees N), or
                    ylat (N-S meters from projection center -- projection
                    specific)
                    (See typeFlag below)

        typeFlag -  indicates conversion between which 2 'coordinates systems':

            ll2projFlag (1) -   lon, lat (degrees) --> xlon, ylat (meters)
                                [Default]
                                     
            ll2crFlag (2)   -   lon, lat (degrees) --> col #, row #  (0 based)

            proj2llFlag (3) -   xlon, ylat (meters) --> lon, lat (degrees)   

            proj2crFlag (4) -   xlon, ylat (meters) --> col #, row # (0 based)

            cr2llFlag (5)   -   col #, row # (0 based) --> lon, lat (degrees)
            
            cr2projFlag (6) -   col #, row # (0 based) --> xlon, ylat (meters)

        cdmsM -    Domain info, cdmsmeta object.  Only needed if you are doing
                   conversions from or to cr (column, row).  Default is None.
                   
        cellLocFlag - Where in the cell to locate the point:
            crossFlag (1)   -   center of cell [Default]
            SWFlag (2)      -   Southwest corner of cell
            SEFlag (3)      -   Southeast corner of cell
            NEFlag (4)      -   Northeast corner of cell
            NWFlag (5)      -   Northwest corner of cell

            Only  meaningful for cr2ll or cr2proj conversion.


    Returns:
    
        convCoordLst - List of coordinate tuples that have been
                        converted from coordLst.  The list has a
                        similar format to coordLst, but also has a z
                        value:		
                        [(x1,y1,z1), (x2,y2,z2),...]

                        Conversions from cells, cr2proj and cr2ll, only have
                        spatial coordinates:
                        [(x1,y1), (x2,y2), ...]
                        
                        See coordLst and typeFlag above for format and
                        coordinate types specifics.

    Notes/Assumptions:

        1.  z coordinates (vertical distance) are simply passed
            through to the projection software.  In most cases, the z
            value will simply be returned w/o modification.
            
        2.  Projections presently supported:
                Lambert Conformal Conic

        3.  Grid cells are assumed to be regularly spaced in the
            projection coordinate system. For example, the grid cells
            might be 4000 x 6000 meters in a lambert conformal
            coordinate system.  When they are transformed to lon/lat
            or if you imagine them on the surface of the earth, they
            will NOT be regularly spaced or equal area.

        4.  Out of domain errors are only checked for conversions from
            cr (col,row). Otherwise, coordConv will calculate the new
            coordinates w/o warning, even if they are outside the
            extent of the grid domain.  To test for domain errors, use
            the function coordInDomain.

	5.  For conversions to or from col,row, one needs to pass
	    cdmsM, a cdmsMeta object.
 
	6.  For conversions to col,row, coordinates that exactly hit
	    the boundary between 2 cells are promoted to the larger
	    col or row number.  For example, if the boundary b/w row
	    30 and 31 is at 24000, then a ylat value of 24000 will be
	    converted to row 31.  The one exception is the North or
	    East edge of the domain.  A coordinate exactly on these
	    boundaries will be demoted to the last col or row.

	7.  One should be careful with ll2cr conversions near the
	    boundary.  A coordinate that is very near the domain
	    boundary may be determined as outside the boundary during
	    the intermediary conversions.  This is due to the problem:

	         xlon1,ylat1 -- > lon, lat --> xlon2, ylat2
	    Where, xlon1, ylat1 are slightly different than xlon2, ylat2
	    

    """


    ## Get projection and create coordinate transformation objects
    ## LL2Proj: lon lat --> projection coordinates (meters)
    ## Proj2LL: projection --> lon lat coordinates (degrees)
    proj = iom2proj(ioM)


    projLonLat = proj.CloneGeogCS()

    LL2Proj = osr.CoordinateTransformation(projLonLat, proj)
    Proj2LL = osr.CoordinateTransformation(proj, projLonLat)
    
    ################
    ## Check which direction doing conversion and perform conversion

    convCoordLst = []

    ## if coordLst is not a list, make it one
    if not isinstance(coordLst, list):
        coordLst = [coordLst]
    
    if typeFlag == ll2projFlag:
        ## lat/lon --> projection coordinates (most likely meters)
        convCoordLst = LL2Proj.TransformPoints(coordLst)

    elif typeFlag == ll2crFlag:
        ## lat/lon --> cells (col,row)

        if cdmsM is None:
            raise KeyError, "Need to pass cdmsmeta object for col row conversions."
        
        ## Need to do 2 conversions:
        ## lat/lon --> projection coord --> cells
        convProjLst = coordConv(ioM, coordLst, ll2projFlag)
        convCoordLst = coordConv(ioM, convProjLst, proj2crFlag, cdmsM)

        
    elif typeFlag == proj2llFlag:
        ## projection coordinates (most likely meters) --> lat/lon
        convCoordLst = Proj2LL.TransformPoints(coordLst)

    elif typeFlag == proj2crFlag:
        ## projection coord --> cells

        if cdmsM is None:
            raise KeyError, "Need to pass cdmsmeta object for col row conversions."

        ## Find the distance b/w the coordinate and the western edge
        ## and southern edge, the SW corner of the domain (edge of the
        ## 0,0 cell).  Divide this distance by the cell size and take
        ## the integer value as the cell

        ## Get the edges of the domain [western, eastern] and
        ## [southern, northern]
        xedge = [cdmsM.xlonAxis.getBounds()[0][0], cdmsM.xlonAxis.getBounds()[-1][1]]
        yedge = [cdmsM.ylatAxis.getBounds()[0][0], cdmsM.ylatAxis.getBounds()[-1][1]]


        ## Max # cols,rows (0 based)
        colMax = len(cdmsM.xlonAxis) - 1
        rowMax = len(cdmsM.ylatAxis) - 1
        
        ## cell size, difference b/w 2 cells position
        xcellSize = cdmsM.xlonAxis.getValue()[1] - \
                    cdmsM.xlonAxis.getValue()[0]
        ycellSize = cdmsM.ylatAxis.getValue()[1] - \
                    cdmsM.ylatAxis.getValue()[0]
        
        for coordProj in coordLst:
            ## Calculatet the col, row #'s
            distX = coordProj[0] - xedge[0]
            distY = coordProj[1] - yedge[0]

            ## Col, row pair
            coordCR = (int(distX/xcellSize), int(distY/ycellSize), 0)

            ## If coord is exactly equal to the Eastern or Northern edge,
            ## assign the coordCR to the last column or row 
            ## This deals w/ the promotion of outer edge to a cell outside the domain
            if coordProj[0] == xedge[1]:
                coordCR = (colMax, coordCR[1])
            if coordProj[1] == yedge[1]:
                coordCR = (coordCR[0], rowMax)
                         
            convCoordLst.append(coordCR)
            
    elif typeFlag == cr2llFlag:
        ## cells --> lat/lon
        
        if cdmsM is None:
            raise KeyError, "Need to pass cdmsmeta object for col row conversions."

        ## Basic idea is 2 conversions:
        ##  cells --> projection coord --> lat/lon
        convProjLst = coordConv(ioM, coordLst, cr2projFlag, cdmsM, cellLocFlag)
        convCoordLst = coordConv(ioM, convProjLst, proj2llFlag)
        
    elif typeFlag == cr2projFlag:
        ## cells --> projection coord

        if cdmsM is None:
            raise KeyError, "Need to pass cdmsmeta object for col row conversions."

        ## Determine if location of interest is the center or SW, SE,
        ## NE, or NW corner of the cell

        ## Double check to see if cells fall w/in grid's domain
        for coordCR in coordLst:
            if not coordInDomain(ioM, cdmsM, coordCR, crFlag):
                raise IndexError, "cell (%.2f,%.2f) is outside the grid's domain" %(coordCR[0], coordCR[1])

        ## List of axes coordinates in native projection
        xlonLst = cdmsM.xlonAxis.getValue()
        ylatLst = cdmsM.ylatAxis.getValue()

        ## cell size, difference b/w 2 cells position
        xcellSize = cdmsM.xlonAxis.getValue()[1] - \
                    cdmsM.xlonAxis.getValue()[0]
        ycellSize = cdmsM.ylatAxis.getValue()[1] - \
                    cdmsM.ylatAxis.getValue()[0]


        ## Center
        if cellLocFlag == crossFlag:
            xoffset = 0.0
            yoffset = 0.0
        
        ## Corners
        ## determine offset, i.e how far to move over from cell center to find
        ## specific corner
        elif cellLocFlag == SWFlag:
            xoffset = -0.5 * xcellSize
            yoffset = -0.5 * ycellSize

        elif cellLocFlag == SEFlag:
            xoffset =  0.5 * xcellSize
            yoffset = -0.5 * ycellSize

        elif cellLocFlag == NEFlag:
            xoffset =  0.5 * xcellSize
            yoffset =  0.5 * ycellSize

        elif cellLocFlag == NWFlag:
            xoffset = -0.5 * xcellSize
            yoffset =  0.5 * ycellSize
            
        else:
            ## Incorrect cellLocFlag
            raise KeyError, "Incorrect cellLocFlag"

        ## Proj coordinate at the center of the col, row plus the offset.
        ## i.e. coordinate at center is simply xlonLst[col] ylatLst[row]
        convCoordLst = [(xlonLst[coord[0]] + xoffset, ylatLst[coord[1]] + yoffset) \
                        for coord in coordLst]

        ## Get coordinates of the center of cells and add offsets
        ## to get corner coordinates
##         centerCoordLst = coordConv(ioM, coordLst, cr2projFlag, crossFlag)
##         convCoordLst = [(coord[0] + xoffset, coord[1] + yoffset) for coord in centerCoordLst]
            
    else:
        ## incorrect flag
        raise KeyError, "Incorrect conversion type"
    
    ## Return the transformed coordinate list
    return convCoordLst

#--------------------------------------------------------------------------#
def coordInDomain(ioM, cdmsM, coord = (0,0,0), typeFlag = llFlag, \
                  domainFlag = False, testProj = True, fourCorners=False):

    """ Simply tests whether or not a coordinate is in the grid's
        spatial domain.

    Input:
        ioM -  projection info, iometa object

        cdmsM - domain info, axes. cdmsmeta object
        
        coord - coordinate tuple to be tested.
                    Example:
                        coord = (-90.2, 40.)
                    Coordinates are in x,y order:

                    where x is column # (0 based), longitude (degrees E), or
                    xlon (E-W meters from projection center -- projection
                    specific)
                    
                    And y is row # (0 based), latitude (degrees N), or
                    ylat (N-S meters from projection center -- projection
                    specific)
                    
                    (See typeFlag below)

        typeFlag -  what type of coordinates are being used:
                llFlag (1)      -   lon, lat (degrees) [Default]
                projFlag (2)    -   xlon, ylat (meters) (see coordConv for
                                    more details)
                crFlag (3)      -   col #, row # (0 based) Should be integers,
                                    see Notes below.

        domainFlag - True. Returns the domain extent as a coordLst:
                            [(xminDomain, yminDomain, zminDomain),
                            (xmaxDomain, ymaxDomain, zmaxDomain)]
                            Coordinates reflect the typeFlag.  When
                            this flag is set, coord is ignored.  For
                            projection and lon,lat coordinates, this
                            is the external edge of the 1st and last
                            grid cells.

                            zmin and zmax indicate the top and bottom
                            layer for crFlag.  Otherwise, zmin and
                            zmax are set to 0
                            
                     False. Default. Checks the coord.

        testProj   -  True, use the proj coordinates as a regular grid.
                            means that if coord in lon/lat it is
                            first converted to proj to test extent.
                            [Default]

                      False, if typeFlag is llFlag, use the domain as if
                            it was a regular grid.

        fourCorners - True, if domainFlag, return the domain as a 4
                            corner list: [SW,SE, NE, NW]
                      False, return normal domain [SW,NE] (Default)     
        
    Returns:
        True    -   coordinate within the grid's domain

        False   -   coordinate outside of grid's domainE] (Default)

        If domainFlag is True - returns domain range as a coordLst:
                            [(xminDomain, yminDomain, zminDomain),
                            (xmaxDomain, ymaxDomain, zmaxDomain)]
                            Coordinates reflect the typeFlag.  When this flag
                            is set, coord is ignored.

                            zmin and zmax indicate the top and bottom layer for crFlag.
                            Otherwise, zmin and zmax are set to 0
                        

    Notes/Assumptions:

        1.  z coordinates (vertical distance) is not tested.
        
        2.  For crFlag, a return of True means that there is an exact
            match.  For example if the cols are 0 - 50, a coord of 40
            would return True, a coord of 40.2 would return False.

        3.  If you are using a coord of type lon/lat, the default test
            converts coord to proj coordinates to test if the coord is
            w.in the domain.  Because lon/lat is an irregular grid,
            the fact that a coord is w/in the SW and NE corners
            doesn't guarantee that the coordinate actually falls in
            the domain.  By setting the testProj flag to True
            (Default), this will perform the test w/in the regular
            coordinate system, proj.
    
            

    """     

    ## Construct the domain List, the extent of the domain in the proper coordinates
    
    if typeFlag == crFlag:
        ## Col, Row, Layer
        cols = range(len(cdmsM.xlonAxis))
        rows = range(len(cdmsM.ylatAxis))
        layers = range(len(cdmsM.layAxis))
        domainLst = [(int(cols[0]), int(rows[0]), int(layers[0])),
                     (int(cols[-1]), int(rows[-1]), int(layers[-1]))]
    else:
        ## Get the edge of the domain
        xedge = [cdmsM.xlonAxis.getBounds()[0][0], \
                 cdmsM.xlonAxis.getBounds()[-1][1]]
        yedge = [cdmsM.ylatAxis.getBounds()[0][0], \
                 cdmsM.ylatAxis.getBounds()[-1][1]]

        ## Notice that z dimension is being set to 0 for now
        domainLst = [(xedge[0], yedge[0], 0), (xedge[1], yedge[1],0 )]

        if typeFlag == llFlag and testProj:
            ## Doing comparison in proj coordinates
            ## Convert coord from lon/lat to proj
            coord = coordConv(ioM, [coord], ll2projFlag)[0]
        elif typeFlag == llFlag:
            ## convert domainLst proj --> lon/lat
            domainLst = coordConv(ioM, domainLst, proj2llFlag)

    if domainFlag:
        
        ## Instead of doing comparison, just return domain in correct
        ## coordinates in "coordinate system"
        if fourCorners:
            ## determine a 4 corner domain
            if typeFlag == crFlag or typeFlag == projFlag:
                ## regular grid so simply assign each corner
                domain4Lst = []
                domain4Lst.append(domainLst[0])  ## SW
                SE = (domainLst[1][0], domainLst[0][1], domainLst[0][2])
                domain4Lst.append(SE)
                domain4Lst.append(domainLst[1])  ## NE
                NW = (domainLst[0][0], domainLst[1][1], domainLst[1][2])
                domain4Lst.append(NW)
            else:
                ## irregular grid, so first make list in proj --> lon/lat
                SW = (xedge[0], yedge[0])
                SE = (xedge[-1], yedge[0])
                NE = (xedge[-1], yedge[-1])
                NW = (xedge[0], yedge[-1])
                domain4Lst = coordConv(ioM, [SW, SE, NE, NW], proj2llFlag)

            return domain4Lst
            
        else:
            ## returning simple domain [SW, NE]
            if typeFlag == llFlag and testProj:
                ## if using proj for test then domainLst in proj
                ## convert from proj --> lon/lat
                domainLst = coordConv(ioM, domainLst, proj2llFlag)

            return domainLst

    
    ## Actually do the comparison

    if (typeFlag == crFlag):      
    ## For row, col, layer, need to have an EXACT match
    ## testing if coordinate is NOT in list --> False return
        if not (coord[0] in cols):
            return False
        if not (coord[1] in rows):
            return False

        ## If passes all these tests, then in domain
        return True
                          
    ## Otherwise llFlag or projFlag. see if coordinate falls outside
    ## of domain box.  Note: if testProj, then this is being tested
    ## against a regular grid (ie. all in proj coordinates).
    ## otherwise, this might incorrectly determine that a lon/lat
    ## is in the domain

    if (coord[0] < domainLst[0][0]) or (coord[0] > domainLst[1][0]): # x dim
         return False
    elif (coord[1] < domainLst[0][1]) or (coord[1] > domainLst[1][1]): # y dim
         return False
    else:
        ## Coordinate inside domain
        return True

#--------------------------------------------------------------------------#
def dateInDomain(cdmsM, testDate, simpleFlag = True):
    
    """ Tests if date is in temporal domain.

    Input:
        
        cdmsM - cdmsmeta object - domain info

        testDate - date to test, mx.DateTime object, cdtime object, or
                   string of form:
                   YYYY-MM-DD HH:MM:SS.SS

                   e.g. '1996-07-12 2:00'

        simpleFlag - True [Default] simply tests if w.in temporal domain
                     False - checks if date exactly matches one of the dates
                             in the timeAxis
                             
    Return:
        True - in domain
        False - not in domain
        
    Note:
    
        1.  If simpleFlag is False, only returns true if testDate is
        an exact match to one of the dates from timeAxis.
    
    """

    ## Convert date to DateTime object
    testDate = dates2DateTime(testDate)

    ## Get start and end date
    startDate = dates2DateTime(cdmsM.timeAxis.asComponentTime()[0])
    endDate = dates2DateTime(cdmsM.timeAxis.asComponentTime()[-1])
    
    

    ## Test if date is actually in domain
    if testDate < startDate:
        return False
    elif testDate > endDate:
        return False

    elif simpleFlag:
        ## passed simple test:
        ##  startDate <= testDate <= endDate
        return True
    
    else:
        ## Exact test
        
        ## Need to go through each date in temporal domain and see if equals testDate
        ## Note:  this means you need an exact match.
        ## For example: testDate = "1996-06-28 10:00:40.00" will NOT match
        ## tmpDate "1996-06-28 10:00:00.00"

        foundFlag = False
        for time in cdmsM.timeAxis.asComponentTime():
            tmpDate = dates2DateTime(time)
            if tmpDate == testDate:
                foundFlag = True
                break
        return foundFlag

#--------------------------------------------------------------------------#
def layerInDomain(cdmsM, testLay, simpleFlag = True):
    
    """ Tests if layer in layer domain
.   
    Input:
        
        cdmsM - cdmsmeta object - domain info

        testLay - sigma layer

        simpleFlag - True [Default] simply tests if w.in layer domain
                     False - checks if layer exactly matches one of the sigma
                             layers in the layAxis
                             
    Return:
        True - in domain
        False - not in domain
        
    Note:

       1.  Assumes that sigma layers go from highest value to smallest value.
       
    
    """


    ## Get start and end layers
    ## Remember botLay is the largest sigma value, and topLay is the smallest
    botLay = cdmsM.layAxis.getValue()[0]
    topLay = cdmsM.layAxis.getValue()[-1]
    
    

    ## Test if layer is actually in domain
    if testLay > botLay:
        return False
    elif testLay < topLay:
        return False

    elif simpleFlag:
        ## passed simple test:
        ##  topLay <= testLay <= botLay
        return True
    
    else:
        ## Exact test
        
        ## Need to go through each layer and see if there is an exact match.

        foundFlag = False
        for layer in cdmsM.layAxis.getValue():
            if layer == testLay:
                foundFlag = True
                break
        return foundFlag


#--------------------------------------------------------------------------#
def filetimeCmp(file1,file2):
    
    """
    Compares two iofiles and determines their temporal order.
    Bases comparison on start date.

    
    Input:
        
        file1 - first iofile
        
        file2 - second iofile
    Output:
        cmpVal - comparison value: 1 file1 after file2, -1 file1 before file2
                                   0 file1 same as file2
    """

    ## open the files and compare the dates
    cmpVal = None
    f1 = open(file1)
    f2 = open(file2)
    if f1.start > f2.start: cmpVal = 1
    if f1.start < f2.start: cmpVal = -1
    else: cmpVal = 0
    f1.close()
    f2.close()
    return cmpVal


#--------------------------------------------------------------------------#
## contour, ocontour, ovector definitions:
## For contour and ocontour functions, set them equal to ioapiPlot.contour
## etc if the appropriate modules are in existence.
## Otherwise, create not implemented stubs
try:
    import matplotlib
    from matplotlib.toolkits.basemap import Basemap
    ## if this works then can import
    import  ioapiPlot 
    contour = ioapiPlot.contour
    ocontour = ioapiPlot.ocontour
    ovector = ioapiPlot.ovector

except:
    ## Matplotlib and basemap not available, therefore not implemented
    def contour(*args, **kwargs):
        """

        This is the contour function stub.  Will raise a not avalable
        message.  This gets overwritten by init if matplotlib and basemap
        exist.

        """
        raise NotImplementedError, "contour not available because: \n" +\
              "matplotlib and Basemap are not on system"


    def ocontour(*args, **kwargs):
        """

        This is the ocontour function stub.  Will raise a not avalable
        message.  This gets overwritten by init if matplotlib and basemap
        exist.

        """
        raise NotImplementedError, "ocontour not available because: \n" +\
              "matplotlib and Basemap are not on system"

    def ovector(*args, **kwargs):
        """

        This is the ovector function stub.  Will raise a not avalable
        message.  This gets overwritten by init if matplotlib and basemap
        exist.

        """
        raise NotImplementedError, "ovector not available because: \n" +\
              "matplotlib and Basemap are not on system"

#--------------------------------------------------------------------------#
    
def binAverager(var, axisIn=0, binwidth = 24, units = "days since", updateFlag=True, \
                forcelinear = False,weights = None, action = 'average', returned = 0, \
                combinewts = None ):
    """
    binAverager-

        Creates a binned average over a specific axis.  For example,
        this could calculate the daily average from hourly data.

    Input:
        var - cdms or iovar variable to average

        axisIn - the axis index, number, over which to average over.
                 The default is 0, which usually indicates the time
                 access.  Axis needs to be designated as either time
                 level, latitude, or longitude (see Notes below) and
                 have bounds.

        binwidth - the width of the bin.  Default value is 24.  The
                   axis to be averaged over needs to be a multiple of
                   the binwidth.  This is an index width, not in the
                   units of the axis.

        units - the value used to update the units in the new axis
                created for the returned averaged variable. The
                default units are 'days since'.  This will use the
                first date as the starting point for the time axis.
                For example, if you are averaging over the time axis:

                 old_timeAxis.units = 'hours since 1996-07-29 06:00:00.00'
                 new_timeAxis.units = 'days since 1996-07-29 06:00:00.00'

        updateFlag - True [default] if update units on modified axis
                     False do not update units

        forcelinear - True force longitude axis to be linear topology
                      False [default] do not force topology to be
                      linear

        weights - parameter for cdutil.averager.  Passed directly to
                  cdutil.averager.  See cdutil documentation.

        action - parameter for cdutil.averager.  Passed directly to
                 cdutil.averager.  See cdutil documentation.

        returned - parameter for cdutil.averager.  Passed directly to
                   cdutil.averager.  See cdutil documentation.

        combinewts - parameter for cdutil.averager.  Passed directly
                     to cdutil.averager.  See cdutil documentation.
        
    Output:
    
        averVar - bin averaged variable.  The axis over which you
                  averaged will be modified to reflect the new length.
                  This axis may also have its units modified, see
                  updateFlag and units above. If var is a cdms
                  variable then averVar is a cdms variable.  If var is
                  an iovar, then this will return an iovar.

    Notes/Assumptions:
    
        1.  Axis to average over needs to be designated as one of the
            cdms fundamental axes (i.e. time, level, latitude, or
            longitude).  For example, to designate a longitude axis
            with linear topology:
                my_axis.designateLongitude(modulo=None)

        2.  Axis to average over needs to have bounds.  For example to
            test for bounds on the time axis:
               var.getTime().getBounds()
               
            If time axis and need to set the bounds, use the cdutil
            module.  For example:
               cdutil.setTimeBoundsDaily(var.getTime(), frequency=24)

        3.  If averaging over level, latitude or longitude, you will
            likely need to hand construct that axis values and bounds.
        
        4.  Copies id and attributes from var to averVar. 

        5.  Only tested for default values of cdutil.averager
            parameters (weights, action, returned, combinewts).

        6.  The forcelinear flag is needed b/c of problem with linear
            topology in the longitude axis.  Without this flag, the
            function cdutil.averager, which is called in this
            function, will change the topology to circular.  This flag
            will force the topology back to linear.
            
    """

    ## test binwidth
    if (binwidth <= 0):
        raise ArithmeticError, "binwidth must be a positive integer"
    
    ## Get average axis, the axis to average over, and test that it is a multiple
    ## of the binwidth.  Want a clone of the axis, so don't modify var's axis.
    averAxis = var.getAxis(axisIn).clone()
    oldlength = len(averAxis)
    if (oldlength%binwidth != 0):
        raise ArithmeticError, "axis length %d must be a multiple of binwidth %d" %(oldlength, binwidth)

    ## Test if axis has bounds, if not raise error and suggest that they
    ## set bounds
    if averAxis.getBounds() is None:
        raise LookupError, "Axis %d is missing bounds.  If the time axis, \n try using the cdutil module to set hourly bounds, for example:\n \t cdutil.setTimeBoundsDaily(var.getTime(), frequency=24)" %axisIn
    
    ## Calculate the new axis length and create a new axis by simply subsetting the old
    ## axis.  This will retain all of the axis metadata
    newlength = oldlength/binwidth
    newaverAxis = averAxis.subAxis(0,newlength)  ## simply subset the old axis to right length

    ## Test what type of axis, ie. time, level, longitude, or latitude.
    ## If it is not defined, raise an error
    ## Depending on the type, define a selector for subsetting that particular axis
    ## Using slice operator so that I can select via index, i.e. not worry about axis units
    if newaverAxis.isTime():
        s = lambda start,end: cdms.selectors.Selector(time=slice(start,end))
    elif newaverAxis.isLevel():
        s = lambda start,end: cdms.selectors.Selector(level=slice(start,end))
    elif newaverAxis.isLatitude():
        s = lambda start,end: cdms.selectors.Selector(latitude=slice(start,end))
    elif newaverAxis.isLongitude():
        s = lambda start,end: cdms.selectors.Selector(longitude=slice(start,end))
    else:
        raise ValueError, "Average axis needs to be designated as time, level, latitude, or longitude"
        
    ## update units ?
    if updateFlag:
        ## if a time axis, need to setup units from a date
        if newaverAxis.isTime():
            ## Get the first date in the time series
            ## construct a unitStr, e.g. 'days since 1996-06-12 06:00:00.00'
            start = newaverAxis.asComponentTime()[0]
            unitStr = units + " %s" %start
            newaverAxis.units = unitStr
        else:
            ## simply replace the units of the axis
            newaverAxis.units = units

    ## Get additional axes and replace the old axis for the new axis in the list.
    newAxes = var.getAxisList()
    newAxes[axisIn] = newaverAxis

    ## If forcelinear flag, find longitude axis in newAxes list and force it to linear topology
    if forcelinear:
        for lonAxis in newAxes:
            if (lonAxis.isLongitude()):
                break

                
    ## Create a list of averaged hyperslabs.
    ## For example, if getting daily averages from hourly data,
    ## then average over the first 24 hrs and assign it to 0th element of
    ## time axis, average over second 24 hrs and assign it to 1st element
    ## of time axis, etc.
    ## Notice that the axis specific selector, s, is used to select the
    ## region to average over.  
    averLst = [cdutil.averager(var(s(start, start + binwidth)), axisIn, weights, \
                               action, returned, combinewts) \
               for start in range(0, oldlength, binwidth)]

    ## Arrays w/in the averLst have dim = dim(var) - 1
    ## Want them to have the same # dimension as var.
    ## For example, if var has shape (72, 10, 80, 90),
    ## then the averLst elements will have shape (10,80,90),
    ## assuming that you are averaging over the first axis.
    ## Want to reshape them so averList elements have shape (1,10,80,90)
    shape = var.shape
    newShape = list(shape)
    newShape[axisIn] = 1
    averLst = [MV.reshape(elem, newShape) for elem in averLst]

    ## Concatenate this list of arrays into one hyperslabed variable
    ## the number of arrays in averLst should equal the newlength,
    ## the length of the newaverAxis.  Concatenating over the averAxis index
    averdata = MV.concatenate(averLst, axis=axisIn)

    ## If force linear, take lonAxis and redesignate as linear
    if forcelinear:
        lonAxis.designateLongitude(modulo=None)

    
    ## Depending on the type of var, either create a cdms variable
    ## or a iovar variable w/ newAxes and w/ attributes and id from var
    try: averVar=createVariable(averdata, var.ioM, axes=newAxes, \
                                attributes=var.attributes, id=var.id)
    except: averVar=cdms.createVariable(averdata, axes=newAxes, \
                                        attributes=var.attributes, id=var.id)

    
    return averVar


#--------------------------------------------------------------------------#
def pipethrough(cmd, lineLst=[]):

    """ Allows one to send a command to the shell and get back the
        stdout and stderror.  This is a very general program w/
        applications outside of ioapi related projects.

        Based on 'Python in a Nutshell' by Alex Martelli, pg 290.

        input:
          cmd -   a command to run, simply a string.

          lineLst - not sure??? I leave it blank and it seems to work.

        Output:
          resultLst -  the stdout and stderror.  Each line is the element of the
                       list.

        Example:
            buff = pipethrough('ls -l *.py')

            buff will contain the result of:
               $ ls -l *.py
            With each line of stdout or stderror as a seperate element of the
            buff list.

    """
    ## get standard in and standard out/error
    fi, fo = os.popen4(cmd, "t")
    fi.writelines(lineLst)
    fi.close()
    resultLst = fo.readlines()
    fo.close()
    return resultLst

#--------------------------------------------------------------------------#

##if __name__ == '__main__':

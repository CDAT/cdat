#!/usr/bin/env python

## import everything from ioapiTools.py

from ioapiTools import *

## Get version info from package_version file
from package_version import version as __version__
from package_version import author as __author__


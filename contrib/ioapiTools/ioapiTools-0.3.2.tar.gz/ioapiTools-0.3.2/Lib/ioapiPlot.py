#!/usr/bin/env python

####################################################################
##     Copyright (C) 2005 Alexis Zubrow
##
##     This program is free software; you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation; either version 2 of the License, or
##     (at your option) any later version.
##
##     This program is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
##
##     You should have received a copy of the GNU General Public License
##     along with this program; if not, write to the Free Software
##     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
####################################################################


"""
ioapiPlot

    A series of plotting tools for iovar objects

    Author:  Alexis Zubrow
"""

#from Scientific.IO.NetCDF import NetCDFFile
import matplotlib
import pylab as P
from matplotlib.toolkits.basemap import Basemap
from MLab import squeeze
import Numeric as N
import ioapiTools as ioT
from copy import copy

##------------------------------------------------------------------##

## Axis formatters: convert distance to km from proj center
class YAxisFormatter(matplotlib.ticker.Formatter):
   def __init__(self, ymin):
      self.ymin = ymin

   def __call__(self, y, pos=1):
      yl = (y + self.ymin)/1000.
      return "%g" % yl

class XAxisFormatter(matplotlib.ticker.Formatter):
   def __init__(self, xmin):
      self.xmin = xmin
   def __call__(self, x, pos=1):
      xl = (x + self.xmin)/1000.
      return "%g" % xl


## Map dictionary
mapDct = {}

##------------------------------------------------------------------##

def iovar2map(var, resol="l", forceFlag = False):
   """
   Creates a basemap object from the metadata in an iovar. If the map
   has already been created and stored in the map dictionary, it will
   reuse this map.

   Input:
      var - iovar object

      resol  - map coastline resolution:
              'c' - coarse
              'l' - low, default
              'i' - intermediate level
              

      forceFlag - True force recreation of map even if it exists in mapDct
                  False do not recreate map if in mapDct [default]
                  

   Output:
      map - basemap object

   Notes/Assumptions:
      1.  Internal Function, most users should not call directly.

      2.  The generation of maps is computationally intense because
          all the maps need to be transformed to the new projection.
          If the map already exists (i.e. has been generated and
          stored in the mapDct) then the default behaviour is to reuse
          it.
      
   """

   ## Get domain in Lon/Lat
   ioM = var.ioM
   domainLL = var.IOcoordInDomain(domainFlag = True)


   ## approximate extent of domain, SW cell center and NE cell center
   ## in degrees
   lons=[domainLL[0][0], domainLL[1][0]]
   lats=[domainLL[0][1], domainLL[1][1]]

   ## Projection paramters
   xcent = ioM.xcent
   ycent = ioM.ycent

   ## Create a basemap  Projection Specific
   if ioM.projectionName == "Lambert Conformal Conic":
      projbasemap = "lcc"  ## naming convention for basemap
      stpar1 = ioM.standparallel1
      stpar2 = ioM.standparallel2
      ## Create a string that has all the parameters of the map
      mapStr = projbasemap + "_%.3f_%.3f_%.3f_%.3f_%.3f_%.3f_%.3f_%.3f_%s" \
               %(stpar1,stpar2,xcent,ycent,lons[0],lats[0], lons[1],\
                 lats[1], resol)

      ## test if map in mapDct
      if mapStr in mapDct.keys() and not forceFlag:
         ## reuse a previously created map
         m = mapDct[mapStr]

      else:
         ## create a new map and record it in the mapDct for future use
         print "Reprojecting map, this might take some time...."
         
         ## lambert conformal conic w/ specific projection parameters
         m = Basemap(lons[0], lats[0], lons[1],lats[1], \
                     projection=projbasemap, \
                     lat_1=stpar1, lat_2=stpar2, lat_0=ycent, lon_0=xcent,\
                     resolution=resol, suppress_ticks=False)
##          m = Basemap(lons[0], lats[0], lons[1],lats[1], \
##                      projection=projbasemap, \
##                      lat_1=stpar1, lat_2=stpar2, lon_0=xcent, \
##                      resolution=resol)
         mapDct[mapStr] = m

   else:
      raise LookupError, "Projection name, %s, currently not supported." \
            %ioM.projectionName

   ## Return the basemap
   return m

##------------------------------------------------------------------##

def calcparallels(lats):
   """
   Calculates the optimal # parallels for a region

   Notes/Assumptions:
     1.  Internal function.
     
   """

   diff = abs(lats[1] - lats[0])

   ## Try and find a step that gives around 4 parallels in region

   if diff >= 80:
      step = 20
   elif diff < 80 and diff >= 60:
      step = 15
   elif diff < 60 and diff >= 40:
      step = 10
   elif diff < 40 and diff >= 32:
      step = 8
   elif diff < 32 and diff >= 24:
      step = 6
   elif diff < 24 and diff >= 20:
      step = 5
   elif diff < 20 and diff >= 12:
      step = 3
   elif diff < 12 and diff >= 8:
      step = 2
   elif diff < 8 and diff >= 4:
      step = 1
   elif diff < 4 and diff >= 2:
      step = .5
   elif diff < 2 and diff >= 1.6:
      step = .4
   elif diff < 1.6 and diff >= .8:
      step = .2
   else:
      step = .1

   ## Want to get a range of parallels that covers lats
   ## but not too big that you have to do whole world if unnecessary
   ## basically creating a 10 deg buffer
   lat1 = round(lats[0]/10. - 1)* 10.
   lat2 = round(lats[1]/10. + 1)* 10.
   if lat1 < -90: lat1 = -90
   if lat2 > 90: lat2 = 90
   parallels = N.arange(lat1,lat2, step)
   return parallels
   
def calcmeridians(lons):
   """
   Calculates the optimal # meridians for a region

   Notes/Assumptions:
     1.  Internal function.
     
   """

   diff = abs(lons[1] - lons[0])

   ## Try and find a step that gives around 4 meridians in region

   if diff >= 80:
      step = 20
   elif diff < 80 and diff >= 60:
      step = 15
   elif diff < 60 and diff >= 40:
      step = 10
   elif diff < 40 and diff >= 32:
      step = 8
   elif diff < 32 and diff >= 24:
      step = 6
   elif diff < 24 and diff >= 20:
      step = 5
   elif diff < 20 and diff >= 12:
      step = 3
   elif diff < 12 and diff >= 8:
      step = 2
   elif diff < 8 and diff >= 4:
      step = 1
   elif diff < 4 and diff >= 2:
      step = .5
   elif diff < 2 and diff >= 1.6:
      step = .4
   elif diff < 1.6 and diff >= .8:
      step = .2
   else:
      step = .1

   ## Want to get a range of meridians to cover lons
   ## but not too big that you have to do whole world if unnecessary
   ## basically creating a 10 deg buffer
   lon1 = round(lons[0]/10. - 1)* 10.
   lon2 = round(lons[1]/10. + 1)* 10.
   if lon1 < -360: lon1= -360.
   if lon2 > 360: lon2 = 360.
   meridians = N.arange(lon1,lon2, step)
   return meridians
   
##------------------------------------------------------------------##

def contour(*args, **kwargs):
   """
   contour draws an image or contour plot with an overlayed map. It
   will use the projection information stored in var's metadata to
   match the data to the correct projection.

   args: necessary arguments
   
      var - iovar object.  Should be subsetted so that only spatial
            dimensions have dimension length greater than 1. If time
            or level dimension is greater than 1, the function will
            take the first 'slice'.

   kwargs: keyword arguments, optional
   
      title - title to add to plot.  Default is None, get title from
              variable name and metadata.

      xTitle - label for the x-axis.  Default is None, get xlabel from
               longitude axis

      yTitle - label for the y-axis.  Default is None, get ylabel from
               latitude axis

      cnLevels  - contour levels:
                  None - no contours [default]
                  'auto' - automatically selects number and contour
                           levels to cover the data range
                  n - number of contours, auto spaced
                  cLst - array or list that defines specific contour
                         levels

      coord -  coordinate system to use for labels
               'proj' - native projection, likely meters/km [default]
               'latlon' - degrees and overlay parallels and meridians

      cmap -  color map.  Takes a matplotlib color map.  Default is cm.jet

      interp - interpolation type.  Simply matplotlib keywords:
               'bilinear' [Default], 'nearest', 'bicubic',
               'blackman100', blackman256','blackman64', 'sinc144',
               'sinc256', 'sinc64', 'spline16', 'spline36'
      
      resol  - map coastline resolution:
              'c' - coarse
              'l' - low, default
              'i' - intermediate level
              
      basemap - a Basemap object to use as projection and map.
                Default is None, get map from mapDct.  If it doesn't
                exist in dictionary, generate map from projection
                information in var.  See notes below.

      tickFmt - tick format string for the color bar.  If not passed,
                default, will try and determine ideal formatting based
                on the max data value or the last contour level.  Pass
                a valid python format string.  For example '%.2f' will
                display numbers with 2 digits of precision.
               
   Outputs:

      cDct - contour dictionary.  Contains the following keys:
             'map' - basemap used
             'fig' - matplotlib figure
             'ax' - matplotlib axes
             'cax' - colorbar axes
             'contInfo' - contour info object (if contours used)
             'xOff' - x offset, see Notes
             'yOff' - y offset, see Notes
   
   Notes/Assumptions:

      1.  Reprojecting a map takes a long time.  Please be patient.
          In order to minimize the reprojection, each new coordinate
          system (projection and spatial domain) is stored in an
          internal dictionary mapDct.  If subsequent calls to contour
          uses an already existing map, contour will reuse the map
          rather than going through the reprojection process.

      2.  The 0,0 point for basemap and the iovar projects are
          different.  The basemap defaults to the lower left corner as
          0,0.  The iovar projection uses the projection center as the
          0,0 point.  Therefore, to translate iovar coordinates
          (i.e. xLons and yLats) into the basemap coordinates, you
          need to add xOff and yOff.  For example, if you have a
          variable o3:
            >>> xLons = o3.getLongitude().getValue()
            >>> xMapVals = xLons + xOff

      
      3.  Projections supported (based on iovar):
               lambert conformal conic

      4.  Depending on the Basemap verion, contInfo will either be
          contourSet object or a list of contour levels and a
          PolyCollection.
          
   """
   ## Get args and keyword args
   if len(args) != 1:
      raise LookupError, "Must pass 1 argument: var"
   else:
      var = args[0]

   if kwargs.has_key("title"): title = kwargs["title"]
   else: title=None
   
   if kwargs.has_key("xTitle"): xTitle = kwargs["xTitle"]
   else: xTitle=None

   if kwargs.has_key("yTitle"): yTitle = kwargs["yTitle"]
   else: yTitle=None
   
   if kwargs.has_key("cnLevels"): cnLevels = kwargs["cnLevels"]
   else: cnLevels=None
   
   if kwargs.has_key("coord"): coord = kwargs["coord"]
   else: coord="proj"
   
   if kwargs.has_key("cmap"): cmap = kwargs["cmap"]
   else: cmap = P.cm.jet
   
   if kwargs.has_key("interp"): interp = kwargs["interp"]
   else: interp = "bilinear"
   
   if kwargs.has_key("resol"): resol = kwargs["resol"]
   else: resol = "l"
   
   if kwargs.has_key("figure"): figure = kwargs["figure"]
   else: figure = None
   
   if kwargs.has_key("basemap"): basemap = kwargs["basemap"]
   else: basemap = None
   
   if kwargs.has_key("tickFmt"): tickFmt = kwargs["tickFmt"]
   else: tickFmt = None
   
      
   ## Create a dictionary to store output
   cDct = {}

   ## Check if var has more than len 1 temporal or level dimension
   ## if so, get 1st values
   try:
      timeAx = var.getTime()
      if len(timeAx) > 1:
         t1 = timeAx.asComponentTime()[0]
         var = var(time=t1)
         print "Warning: multiple dates, using date 1: %s" %t1
   except: pass
   try:
      levAx = var.getLevel()
      if len(levAx) > 1:
         lev1 = levAx.getValue()[0]
         var = var(level=lev1)
         print "Warning: multiple levels, using level 1: %f" %lev1
   except: pass
   
   ## Get domain in Lon/Lat and proj (meters)
   domainLL = var.IOcoordInDomain(domainFlag = True)
   domainProj = var.IOcoordInDomain(typeFlag=ioT.projFlag, \
                                    domainFlag=True)

   ## axes in native projection (LLC), numeric
   xLons = var.getLongitude().getValue()
   yLats = var.getLatitude().getValue()

   ## x and y offsets, translate iovar coordinates --> basemap coordinates
   ## Simply the SW edge of the domain in the iovar coordinates,
   ## and switch the sign.
   xOff = -domainProj[0][0]
   yOff = -domainProj[0][1]
   cDct["xOff"] = xOff
   cDct["yOff"] = yOff
   
   ## approximate extent of domain, SW cell center and NE cell center
   ## in degrees
   lons=[domainLL[0][0], domainLL[1][0]]
   lats=[domainLL[0][1], domainLL[1][1]]


   ## Turn interactive mode off if on. Prevents freezing
   ## when drawing parallels and meridians
   ## also speeds things up
   if matplotlib.is_interactive():
      interactiveFlag = True
      matplotlib.interactive(False)
   else:
      interactiveFlag = False

   ## Not passing in a basemap
   if basemap is None:
      ## Create a basemap
      m = iovar2map(var, resol)

   ## reusing basemap that is passed to contour
   else:
      m = basemap

   ## Store map
   cDct["map"] = m

   ## Create figure and axes and store in cDct
   xsize = P.rcParams['figure.figsize'][0]
   if figure is None:
      fig=P.figure(figsize=(xsize,m.aspect*xsize))
      ax = fig.add_axes([0.1,0.1,0.7,0.7])
   else:
      ## figure is provided by the user
      fig = figure
      ax = fig.get_axes()

   ax = fig.add_axes([0.1,0.1,0.7,0.7])
      
   cDct["ax"] = ax  
   cDct["fig"] = fig
   
   ## draw boarders
   m.drawcoastlines()
   m.drawcountries()
   m.drawstates()

   ## OPTION 1: draw labelled parallels and meridians
   if coord == "latlon":

      parallels = calcparallels(lats)
      meridians = calcmeridians(lons)

      ## parallels = range(25,55,10)
      ## meridians = range(-205,-55,10)
      m.drawparallels(parallels,labels=[1,1,0,1])
      m.drawmeridians(meridians,labels=[1,1,0,1])


   ## Option 2: x,y ticks labelled relative to proj center (in km)
   elif coord == "proj":

      P.xlabel("x distance from projection center (km)")
      P.ylabel("y distance from projection center (km)")
      ax.yaxis.set_major_formatter(YAxisFormatter(domainProj[0][1]))
      ax.xaxis.set_major_formatter(XAxisFormatter(domainProj[0][0]))

   ## title.
   tmpTitle = "%s (%s)" %(var.name, var.units)
   P.title(tmpTitle)
   
   if title is not None:
      P.title(title)

   ## if pass xtitle or ytitle, overwrite default
   if xTitle is not None:
      P.xlabel(xTitle)
   if yTitle is not None:
      P.ylabel(yTitle)
      

   ## data in Numeric form, squeezes out the 1 length dimensions
   ## this array should only be 2-d
   dat = squeeze(var)

   ## The location of the contour values are in relation
   ## to the basemap projection.  B/c the basemap has 0,0
   ## in the SW corner, unlike the iovar object, which has
   ## 0,0 at the projection center.  To map on same coordinates,
   ## simply shift the coordinates to a 0,0 origin by adding
   ## the offsets
   xvals = xLons  + xOff
   yvals = yLats + yOff
   ## make 2-D arrays (ny,nx)
   xvals, yvals = matplotlib.mlab.meshgrid(xvals, yvals)
   
   if cnLevels is None:
      ## plotting as an image
      im = m.imshow(dat, cmap=cmap, interpolation=interp)
      
##                     extent=(m.xmin, m.xmax, m.ymin, m.ymax), \
##                     interpolation=interp,origin = "lower")

   elif cnLevels == "auto":
      ## plotting contours, auto determine levels
      
      contInfo = m.contourf(xvals, yvals, dat, cmap=cmap)
##                               origin="lower")

      ## store contour info
      cDct["contInfo"] = contInfo
      
   else:
      ## plotting contours, user defined levels
      contInfo = m.contourf(xvals, yvals, dat, cnLevels, cmap=cmap)

      ## store contour info
      cDct["contInfo"] = contInfo
      
   ## get levels
   if cnLevels is not None:
      ## if newer Basemap, contInfo is a counterSet
      ## else, it is list [levels, colls]
      try: lev = contInfo.levels
      except: lev = contInfo[0]
      
   ## add a color bar
   cax = P.axes([.875, .1, .05, .7])

   try:
      ## use new matplotlib format notation (post 0.87.5)
      ## accepts None format-- automatically determines tick
      P.colorbar(cax=cax, format=tickFmt)
   except:
      ## use old matplotlib format
      ## doesn't accept None for format
      if tickFmt is None:
         ## depending on max value of data, automatically determine the
         ## number of digits to show if using contours, use the max abs
         ## contour
         try: maxVal = max(abs(lev))
         except:   maxVal = max(abs(N.ravel(dat)))

         if maxVal >= 1:
            tickFmt = "%.1f"
         elif maxVal < 1 and maxVal >= 0.1:
            tickFmt = "%.2f"
         elif maxVal < 0.1 and maxVal >= 0.01:
            tickFmt = "%.3f"
         else:
            tickFmt = "%.1e"
      P.colorbar(cax=cax, tickfmt=tickFmt)

   cDct["cax"] = cax  # store color axes
   
   ## change back to plot image axes from colorbar axes
   P.axes(ax)

   ## turn interactive mode back on
   if interactiveFlag:
      matplotlib.interactive(True)
      
   ## actually plot image
   P.show()

   return cDct

##------------------------------------------------------------------##

def ocontour(*args, **kwargs):
   """
   draws a contour over a previous plot with an overlayed map. 

   args: necessary arguments
   
      var - iovar object.  Should be subsetted so that only spatial
            dimensions have dimension length greater than 1. If time
            or level dimension is greater than 1, the function will
            take the first 'slice'.

      cDct - contour dictionary.  Return from contour.  


   kwargs: keyword arguments, optional
   
      title - title to add to plot.  Default is None, get title from
              variable name and metadata.

      cnLevels  - contour levels:
                  'auto' - automatically selects number and contour
                           levels to cover the data range [default]
                  n - number of contours, auto spaced
                  cLst - array or list that defines specific contour
                         levels

      
      colors - color for the contours.  Use matplotlib color codes.
               The default is black, 'k'.


      clabel - True: label contour levels
               False: don't label contours

      inline - 0: place labels on contour lines [default]
               1: leave space under the labels

      fmt - label format string.  Default is '%.1f'
      
      fontsize - default is 10

      
   Outputs:

      ocDct - contour dictionary.  Contains the following keys:
             'map' - basemap used
             'fig' - matplotlib figure
             'ax' - matplotlib axes
             'cax' - colorbar axes
             'contInfo' - contour info (if contours used)
             'xOff' - x offset, see Notes
             'yOff' - y offset, see Notes
   
   Notes/Assumptions:


      1.  The spatial extent and projection of var needs to match the
          domain and projection of the underlying plot.  In other
          words, only use ocontour over contour plots of the same
          domain, resolution, and projection.

      2.  Need to be running matplotlib in interactive mode to overlay
          contour plots over a previous image.  I recommend using
          ipython with '-pyplab' option for best results.  See
          matplotlib documentation for more information about
          interactive mode.

      3.  Depending on the Basemap verion, contInfo will either be
          contourSet object or a list of contour levels and a
          PolyCollection.
          
      
   """
   ## Get args and keyword args
   if len(args) != 2:
      raise LookupError, "Must pass 2 arguments: var and cDct"
   else:
      var = args[0]
      cDct = args[1]

   if kwargs.has_key("title"): title = kwargs["title"]
   else: title=None
   
   if kwargs.has_key("cnLevels"): cnLevels = kwargs["cnLevels"]
   else: cnLevels = "auto"
   
   if kwargs.has_key("clabel"): clabel = kwargs["clabel"]
   else: clabel = True
   
   if kwargs.has_key("colors"): colors = kwargs["colors"]
   else: colors = "k"
   
   if kwargs.has_key("inline"): inline = kwargs["inline"]
   else: inline = 0
   
   if kwargs.has_key("fmt"): fmt = kwargs["fmt"]
   else: fmt = "%.1f"
   
   if kwargs.has_key("fontsize"): fontsize = kwargs["fontsize"]
   else: fontsize = 10
   
   if kwargs.has_key("figure"): figure = kwargs["figure"]
   else: figure = None
   

   ## Check if var has more than len 1 temporal or level dimension
   ## if so, get 1st values
   try:
      timeAx = var.getTime()
      if len(timeAx) > 1:
         t1 = timeAx.asComponentTime()[0]
         var = var(time=t1)
         print "Warning: multiple dates, using date 1: %s" %t1
   except: pass
   try:
      levAx = var.getLevel()
      if len(levAx) > 1:
         lev1 = levAx.getValue()[0]
         var = var(level=lev1)
         print "Warning: multiple levels, using level 1: %f" %lev1
   except: pass

   ## Get some parameters from the cDct
   m = cDct["map"]
   fig = cDct["fig"]
   xOff = cDct["xOff"]
   yOff = cDct["yOff"]

   ## reduce the data to a 2-d numeric array
   dat = squeeze(var)

   ## Get data axes in basemap coordinates (i.e. 0,0 lowerleft)
   xLons = var.getLongitude().getValue()
   yLats = var.getLatitude().getValue()
   xvals = xLons  + xOff
   yvals = yLats + yOff
   ## make 2-D arrays (ny,nx)
   xvals, yvals = matplotlib.mlab.meshgrid(xvals, yvals)

   

   ## Make the figure of interest active
   P.figure(fig.number)

   ## Draw the contours
   if cnLevels=="auto":
      contInfo = m.contour(xvals, yvals, dat, colors=colors)

   else:
      contInfo = m.contour(xvals, yvals, dat, cnLevels, colors=colors)


   if clabel:
      
      try: P.clabel(contInfo, inline=inline, fmt=fmt, fontsize=fontsize)
      except:
         ## old Basemap, get colls (PolyCollection) and levels (contour)
         ## from contInfo, just a list in this case
         colls=contInfo[1]
         lev=contInfo[0]
         P.clabel(colls, lev, inline=inline, fmt=fmt, fontsize=fontsize)

   if title is not None:
      P.title(title)
      
   ## create a new cDct
   cDctOut = copy(cDct)
   cDctOut["contInfo"] = contInfo


   return cDctOut

##------------------------------------------------------------------##

def ovector(*args, **kwargs):
   """
   draws a vector field of arrows over a previous plot with an
   overlayed map.

   args: necessary arguments
   
      udat - u component of the vector field (e.g. uwind), an iovar
            object.  Should be subsetted so that only spatial
            dimensions have dimension length greater than 1. If time
            or level dimension is greater than 1, the function will
            take the first 'slice'.

      vdat - v component of the vector field (e.g. vwind), an iovar
            object.  Should be subsetted so that only spatial
            dimensions have dimension length greater than 1. If time
            or level dimension is greater than 1, the function will
            take the first 'slice'.

      cDct - contour dictionary.  Return from contour.  


   kwargs: keyword arguments, optional

      scale - scaling factor for arrow length.  Scale = None [default]
              arrows are scaled so tatlongest one equals the distance
              b/w grid points..  If a scaling value is given, the
              arrows are first adjusted to fit w/in the grid and then
              multiplied by the scaling factor.  Note, for wind
              vectors, I have found that you often need a scaling
              vactor of ~100000 to produce arrows larger than the
              default.

      width - width of the arrows. Default is 1.0

      color - colors for the arrows.  Default is None, black.  See
              quiver documenation and color under the matplotlib
              module.

      cmap - matplotlib colormap.  Default is None. 

      title - new title. Default is None, keep same title as contour
      
   Outputs:

   
   Notes/Assumptions:


      1.  The spatial extent and projection of udat and vdat needs to
          match the domain and projection of the underlying plot.  In
          other words, only use ovector over contour plots of the same
          domain, resolution, and projection.  In addition, udat and
          vdat should have the same spatial domain.

      2.  See matplotlib's quiver function for more details on the
          keywords.

      3.  Need to be running matplotlib in interactive mode to overlay
          plots over a previous image.  I recommend using ipython with
          '-pyplab' option for best results.  See matplotlib
          documentation for more information about interactive mode.
      
   """
   ## Get args and keyword args
   if len(args) != 3:
      raise LookupError, "Must pass 3 arguments: udat, vdat, and cDct"
   else:
      udat = args[0]
      vdat = args[1]
      cDct = args[2]

   if kwargs.has_key("scale"): scale = kwargs["scale"]
   else: scale = None
   
   if kwargs.has_key("width"): width = kwargs["width"]
   else: width=0
   
   if kwargs.has_key("color"): color = kwargs["color"]
   else: color = None
   
   if kwargs.has_key("cmap"): cmap = kwargs["cmap"]
   else: cmap= None
   
   if kwargs.has_key("norm"): norm = kwargs["norm"]
   else: norm = None
   
   if kwargs.has_key("title"): title = kwargs["title"]
   else: title = None
   

   ## Check if var has more than len 1 temporal or level dimension
   ## if so, get 1st values
   try:
      timeAx = udat.getTime()
      if len(timeAx) > 1:
         t1 = timeAx.asComponentTime()[0]
         udat = udat(time=t1)
         print "Warning: udat multiple dates, using date 1: %s" %t1
   except: pass
   try:
      timeAx = vdat.getTime()
      if len(timeAx) > 1:
         t1 = timeAx.asComponentTime()[0]
         vdat = vdat(time=t1)
         print "Warning: vdat multiple dates, using date 1: %s" %t1
   except: pass
   try:
      levAx = udat.getLevel()
      if len(levAx) > 1:
         lev1 = levAx.getValue()[0]
         udat = udat(level=lev1)
         print "Warning: udat multiple levels, using level 1: %f" %lev1
   except: pass
   try:
      levAx = vdat.getLevel()
      if len(levAx) > 1:
         lev1 = levAx.getValue()[0]
         vdat = vdat(level=lev1)
         print "Warning: vdat multiple levels, using level 1: %f" %lev1
   except: pass

   ## Get some parameters from the cDct
   m = cDct["map"]
   fig = cDct["fig"]
   xOff = cDct["xOff"]
   yOff = cDct["yOff"]

   ## reduce the data to a 2-d numeric array,
   ## need it to be type "d" for quiver
   U = squeeze(udat)
   V = squeeze(vdat)
   U = N.array(U, typecode="d")
   V = N.array(V, typecode="d")

   ## Create a 2-d array of xlons and ylats
   ## add offset to convert of iovar coordinates --> basemap
   xvals = udat.getLongitude().getValue() +  xOff
   yvals = udat.getLatitude().getValue() + yOff
   xv, yv = matplotlib.mlab.meshgrid(xvals, yvals)

   ## New title
   if title is not None:
      P.title(title)
      

   ## plot the vector fields
   m.quiver(xv, yv, U, V, scale = scale, color = color, \
            cmap = cmap, width = width, norm=norm)
   

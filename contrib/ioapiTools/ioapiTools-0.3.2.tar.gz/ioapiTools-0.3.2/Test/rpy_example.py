#!/usr/bin/env python

import ioapiTools as ioT
import Numeric as N
from rpy import r as R
from mx import DateTime as D

#####################################################################
##
## This gives a quick example of using the python interface to R, rpy.
## These examples could be done directly in python, but I wanted to
## demonstrate the use of rpy.
##
#####################################################################

## Input files
scan1 = "~/tmp/exampleData/CCTM_ACONC.D2*"

startD = D.DateTime(1996,6,24,6)
endD = D.DateTime(1996,6,27,5)

## Get o3 data and convert to ppb
fs = ioT.scan(scan1, startD,endD)
o3 = fs("o3")
o3 *= 1000
o3.units = "ppb"

## Get noon dates
noon1D = startD + 12*D.oneHour
noon2D = noon1D + 1
noon3D = noon1D + 2

## extract data for each noon and concatenate into one file
noon1 = o3.IOsubset(timeLst = noon1D)
noon2 = o3.IOsubset(timeLst = noon2D)
noon3 = o3.IOsubset(timeLst = noon3D)

o3_noon = ioT.concatenate([noon1, noon2, noon3])

## To call R commands, you need to pass numeric 1-D arrays
o3noon_flat = N.ravel(o3_noon)

################
## 1st plot
## Plot a histogram o3 values at noon for all 3 days


## Need to first figure out the extent of the x and y axes
## and make a blank plot
o3density = R.density(o3noon_flat)  ## actually a dictionary
xrange = R.range(o3density["x"])
yrange = R.range(o3density["y"])
R.plot(xrange,yrange,type="n", xlab="ppb", ylab="density",main="o3 noon, 3 Days")

## plot the density function using lines
R.lines(o3density)

## add the histogram, with frequency set to false

R.hist(o3noon_flat, add=True, freq=False)

################

## 2nd plot - comparing the 3 noon profiles

noon1_flat = N.ravel(noon1)
noon2_flat = N.ravel(noon2)
noon3_flat = N.ravel(noon3)
density1=R.density(noon1_flat)
density2=R.density(noon2_flat)
density3=R.density(noon3_flat)

## define ranges based on larger(st) axes
xrange2 = R.range(o3density["x"])
yrange2 = R.range(density1["y"])

## 2nd plot
## make a plot window size of largest ranges
R.plot(xrange2,yrange2,type="n", xlab="ppb", ylab="density",main="o3 - 3 noons")

## plot each days' noon density function.
## Remember, day1 is the first day of the simulation.
## Therefore, the first noon is similar to the
## initial conditions, i.e. has a narrower variance
R.lines(density1, col="red",add=True)
R.lines(density2, col="blue",add=True)
R.lines(density3, col="green",add=True)

###################

## 3rd plot - Time series of particular locations

## 2 rural locations (lat/lon in degrees)
lon1 =-90.1058
lat1 = 38.8606

lon2 = -90.3058
lat2 = lat1

## 2 rural sites
rur1 = o3.IOsubset((lon1,lat1))
rur2 = o3.IOsubset((lon2,lat2))

rur1_flat = N.ravel(rur1)
rur2_flat = N.ravel(rur2)

yrange=R.range(rur1_flat, rur2_flat)

timeInd = rur1.getTime().getValue()
xrange = R.range(timeInd)

## plot the time series of the 2 locations
R.plot(xrange,yrange, main="Time series - 2 rural sites", xlab="hours since 1996-6-24 6:00", ylab="ppb", type="n")

R.lines(rur1_flat, col="red")
R.lines(rur2_flat, col="blue")

###################

## 4th plot - periodogram

## Find out periods that are most important in rural 1 data
## use these later to do a regression
spec = R.spectrum(rur1_flat, main="Periodogram")

#####################

## 5th plot - regression based on Periodogram

## Decided to use 3, 6, 12, 24 hr cycles for regression
sin3 = N.sin(timeInd*2*N.pi/3.)
sin6 = N.sin(timeInd*2*N.pi/6.)
sin12 = N.sin(timeInd*2*N.pi/12.)
sin24 = N.sin(timeInd*2*N.pi/24.)
cos3 = N.cos(timeInd*2*N.pi/3.)
cos6 = N.cos(timeInd*2*N.pi/6.)
cos12 = N.cos(timeInd*2*N.pi/12.)
cos24 = N.cos(timeInd*2*N.pi/24.)

## define the model that R will use, doesn't like "_"
## pass data to R so knows these variable names and values
## run the regression model w/ this formula
## linear model: o3_rural1 = alpha0 + alpha1*time + sum(beta_i*sin2pi*t/Ti)
## + sum(gamma_i * cos2pi*t/Ti) where i is 1-4 and Ti = periods (3,6,12,24)
mod1 = R("rur1F~timeInd+sin3+cos3+sin6+cos6+sin12+cos12+sin24+cos24")
d =R.data_frame(rur1F=rur1_flat,timeInd=timeInd,sin3=sin3, cos3=cos3, sin6=sin6, cos6=cos6, sin12=sin12, cos12=cos12,sin24=sin24, cos24=cos24)
reg1 = R.lm(mod1, data=d)

## Plot rural 1 vs regression
R.plot(xrange,yrange, main="Rural 1 vs regression", xlab="hours since 1996-6-24 6:00", ylab="ppb", type="n")
R.lines(rur1_flat, col="red")
R.lines(reg1["fitted.values"])

#######################

## 6th plot - residiuals
## plot the residuals, as expected this model is not doing so well
R.plot(reg1["residuals"], main="Residuals", ylab="ppb", xlab="hours since 1996-6-24 6:00")


#######################

## ## plot the image of the data
## ## need to put it into Numeric and get the transpose (R.t)

## ## Need fields package to use upper level image.plot function
## ## which automatically includes the scale
## R.library("fields")

## Get the range of longitude and latitude axes (in meters)
## lons = o3.getLongitude().getValue()
## lats = o3.getLatitude().getValue()
## lonrange=R.range(lons)
## latrange=R.range(lats)

## ## Need 2-D array in Numeric
## noon1array = noon1[0,0].getValue()
## noon2array = noon2[0,0].getValue()
## noon3array = noon3[0,0].getValue()

## ## plot the transpose
## R.plot(lonrange,latrange, main="O3 noon1", xlab="xLons (m)", ylab ="yLats (m)", type="n")
## R.image_plot(lons,lats,R.t(noon3array), add=True)

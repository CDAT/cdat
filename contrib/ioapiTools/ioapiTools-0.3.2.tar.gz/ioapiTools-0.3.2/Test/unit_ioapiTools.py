#!/usr/bin/env python

#######################################################
## Performs some tests on the ioapiTools module.
#######################################################

import unittest
import os
import ioapiTools as ioT
import cdms, cdtime, cdutil
from mx import DateTime as D
from optparse import OptionParser

###########################
## Get command line options
###########################

usage = "usage: %prog [options] inDir"
parser = OptionParser(usage=usage)

parser.add_option("-o", dest="outDir", default=None,
                 metavar=" OUT_DIR",
                 help="Directory to write output.  If this flag "
                  "isn't used, the ouptut directory will be the same as "
                  "the input directory")

(options, args) = parser.parse_args()

if (len(args) != 1):
    parser.error("Incorrect number of arguments -- need input directory")

## directories for input and output
dataDir = args[0]
if options.outDir is None:
    outDir = dataDir
else:
    outDir = options.outDir


## Files
file1 = "CCTM_ACONC.D2.001"
file2 = "CCTM_ACONC.D2.002"
file3CF = "o3_aconc.nc"
scan1 = "CCTM_ACONC.D2*"
ofile1 = "test1.nc"
ofile2 = "test2.ioapi"
ofile3 = "test3.ioapi"
ofile4 = "test4_error.ioapi"
ofile5 = "test5_error.ioapi"
log1 = "log1.ioapi"

## dates
date1 = "1996-06-24 8:00"
date2 = "1996-06-27 2:00"
date3 = "1998-06-27 2:00"


## locations for conversions and subsetting
lat1 = 37.01991
lat2 = 39.276
lon1 = -92.69367
lon2 = -90.358
xlon1 = -234000
xlon2 = -30000
ylat1 = -318000
ylat2 = -78000
r1 = 5
r2 = 25
c1 = 3
c2 = 20

## Create absolute paths to the files
dataDir = os.path.expanduser(dataDir)
outDir = os.path.expanduser(outDir)
file1 = os.path.join(dataDir, file1)
file2 = os.path.join(dataDir, file2)
file3CF = os.path.join(dataDir, file3CF)
scan1 = os.path.join(dataDir, scan1)
ofile1 = os.path.join(outDir, ofile1)
ofile2 = os.path.join(outDir, ofile2)
ofile3 = os.path.join(outDir, ofile3)
ofile4 = os.path.join(outDir, ofile4)
ofile5 = os.path.join(outDir, ofile5)
log1 = os.path.join(outDir, log1)

## Print some diagnostics
print "######################################"
print "input directory: %s" %dataDir
print "output directory: %s" %outDir
print "######################################"
print ""

## Setup some global ioapiTool objects for tests
try:
    f = ioT.open(file1)
    fs = ioT.scan(scan1, date1, date2)
    o3 = f("o3")
    no2 = f("no2")
    co = f("co")
    cdmsM = ioT.cdmsmeta(o3, ioT.cdmsvarFlag)
except:
    raise IOError, "Problem w/ test globals setup"


###################################################

## Define the unit tests

class iotTest(unittest.TestCase):

    ####################
    ## file and iovar ##
    ####################

    ## opening a file
    def testOpen(self):
        self.failUnless(ioT.open(file1), "Open file failed, ioapi format")

        self.failUnless(ioT.open(file3CF), "Open file failed, CF format")

    def testOpenError(self):
        self.assertRaises(IOError, ioT.open, file1 + "garbage")

    ## reading a variable
    def testReadVar(self):
        ## read from ioapi file
        self.failUnless(f("o3"), "read variable from ioapi file failed")

        ## read from CF file
        h = ioT.open(file3CF)
        self.failUnless(h("o3"), "read variable from CF file failed")

    def testReadVarError(self):
        self.assertRaises(cdms.CDMSError, f, "garbage")

    ## get axes
    def testReadAxes(self):
        self.failUnless(o3.getTime())
        self.failUnless(o3.getLevel())
        self.failUnless(o3.getLatitude())
        self.failUnless(o3.getLongitude())

    ## subsetting
    def testSubset(self):
        domainLL = [(lon1,lat1), (lon2,lat2)]
        domainProj = [(xlon1, ylat1), (xlon2, ylat2)]
        domainCR = [(c1,r1), (c2,r2)]
        lonProj = (xlon1, xlon2, "ccb")
        latProj = (ylat1, ylat2, "ccb")
        startD = ioT.dates2DateTime(date1)
        endD = startD + 10*D.oneHour
        timeLst = [startD,endD]
        timeLst2 = [ioT.dates2Cdtime(startD), ioT.dates2Cdtime(endD)]
        startInd = 2
        endInd = 13
        
        ## testing IOsubset
        self.failUnless(o3.IOsubset(domainLL, timeLst=timeLst), \
                     "IOsubset failed for lat/lon")
        self.failUnless(o3.IOsubset((lon1,lat1), timeLst=timeLst), \
                     "IOsubset failed for lat/lon, 1 pnt")
        self.failUnless(o3.IOsubset(domainProj, timeLst=timeLst, \
                                 coordFlag = ioT.projFlag),\
                     "IOsubset failed  for proj")
        self.failUnless(o3.IOsubset(domainCR, timeLst=timeLst2, \
                                 coordFlag = ioT.crFlag),\
                     "IOsubset failed for col/row")
        

        ## testing cdms and Numeric subsets
        self.failUnless(o3(time = timeLst2, latitude = latProj, \
                        longitude=lonProj), "cdms subset failed")
        self.failUnless(o3[startInd:endInd,:,r1:r2+1, c1:c2+1], \
                     "numeric subset failed")

    def testSubsetCompare(self):
        ## tests if the 3 types of subsets get identical subset
        domainLL = [(lon1,lat1), (lon2,lat2)]
        domainProj = [(xlon1, ylat1), (xlon2, ylat2)]
        domainCR = [(c1,r1), (c2,r2)]
        lonProj = (xlon1, xlon2, "ccb")
        latProj = (ylat1, ylat2, "ccb")
        startD = ioT.dates2DateTime(date1)
        endD = startD + 10*D.oneHour
        timeLst = [startD,endD]
        timeLst2 = [ioT.dates2Cdtime(startD), ioT.dates2Cdtime(endD)]
        startInd = 2
        endInd = 13

        ## 3 major types from IOsubset
        sub1 = o3.IOsubset(domainLL, timeLst=timeLst)
        sub2 = o3.IOsubset(domainProj, timeLst=timeLst2, coordFlag=ioT.projFlag)
        sub3 = o3.IOsubset(domainCR, timeLst=timeLst, coordFlag=ioT.crFlag)

        ## cdms and numeric subsets
        sub4 = o3(time=timeLst2, lat=latProj, lon=lonProj)
        sub5 = o3[startInd:endInd,:,r1:r2+1,c1:c2+1]

        ## compare each
        self.failUnless(sub1.IOequal(sub2), "subset comparison failed, 1-2")
        self.failUnless(sub1.IOequal(sub3), "subset comparison failed, 1-3")
        self.failUnless(sub1.IOequal(sub4), "subset comparison failed, 1-4")
        self.failUnless(sub1.IOequal(sub5), "subset comparison failed, 1-5")

    def testSubsetError(self):
        domainLL = [(lon1,lat1), (lon2,lat2)]
        domainBig = [(lon1,lat1+15), (lon2,lat2)]
        startD = ioT.dates2DateTime(date1)
        endD = startD + 10*D.oneHour
        timeBig = [startD -10,endD]
        levelInd=0

        self.assertRaises(IndexError, o3.IOsubset, domainBig)
        self.assertRaises(IndexError, o3.IOsubset, domainLL, levelInd, timeBig)

    ## IOclone
    def testIOclone(self):
        self.failUnless(o3.IOclone(), "IOclone failed")

    ## IOequal and modifying data values
    def testIOequal(self):
        o3_clone = o3.IOclone()

        ## test all close and exact equality
        self.failUnless(o3.IOequal(o3_clone), \
                        "IOequal 'all close' failed when should be True")
        self.failUnless(o3.IOequal(o3_clone, True), \
                        "IOequal exact failed when should be True")

        ## change a value and make sure IO equal now fails
        o3_clone[0,0,r1,c1] += 0.00001
        
        self.failIf(o3.IOequal(o3_clone), \
                     "IOequal 'all close' returned True when should have Failed")
        self.failIf(o3.IOequal(o3_clone, True), \
                     "IOequal exact returned True when should have Failed")

        ## Check that 'all close' with a higher absolute tolerance finds
        ## the 2 variables still equal
        self.failUnless(o3.IOequal(o3_clone, atol=1.e-4), \
                        "IOequal 'all close' w/ atol = 1e-4 failed when should be true")
        
        ## Change a whole series of values and spot check
        o3_clone[:,0,r1,c1:] = 2.0
        self.failUnless((o3_clone[10,0,r1, c1+12].getValue() == 2.0), \
                        "Change value did not change region to 2.0")
        self.failIf((o3_clone[10,0, r1 + 2, c1 + 12].getValue() == 2.0), \
                    "Change value changed area outside or region to 2.0")
                                   
    ## IOchangeDate
    def testIOchangeDate(self):
        date2D = D.DateTime(1999,7,12,18)
        date2Cd = ioT.dates2Cdtime(date2D)
        o3_clone = o3.IOclone()
        ## original first date
        firstCd = o3.getTime().asComponentTime()[0]
        o3_clone.IOchangeDate(date2D)


        ## Check first dates after IOchangeDate

        ## b/c IOchangeDate doesn't return anything, to see if it works
        ## use a try statement
        try: o3_clone.IOchangeDate(date2D)
        except: self.fail("IOchangeDate failed")
        
        firstCloneCd = o3_clone.getTime().asComponentTime()[0]
        ## original first date after change date of clone, shouldn't change
        ## if all is working
        firstOrigCd = o3.getTime().asComponentTime()[0]
        
        self.failUnless((firstCloneCd == date2Cd), \
                        "Changed first date does not match intended date")

        ## Make sure that change date does not effect the original file
        self.failUnless((firstCd == firstOrigCd), \
                        "Changed first date changed the original file's date")

        ## double check that the dates are actually different
        self.failIf((firstCloneCd == firstOrigCd), \
                    "Despite change dates, clone and original match")

        
    ## IOmodVar
    def testIOmodVar(self):
        newname = "o3test"
        newunits = "ppb"
        newdesc = "Variable 03 -- ppb units, but no change to values"

        o3_clone = o3.IOclone()

        ## use try because doesn't return anything
        try: o3_clone.IOmodVar(newname, newunits, newdesc)
        except: self.fail("IOmodVar failed")
        
        ## test if actually changed values
        self.failUnless((o3_clone.name == newname), \
                        "IOmodVar didn't change name")
        self.failUnless((o3_clone.id == newname), \
                        "IOmodVar didn't change id")
        self.failUnless((o3_clone.units == newunits), \
                        "IOmodVar didn't change units")
        self.failUnless((o3_clone.var_desc == newdesc), \
                        "IOmodVar didn't change description")
        self.failUnless((o3_clone.long_name == newdesc), \
                        "IOmodVar didn't change long_name")

        ## test that didn't effect originale
        self.failIf((o3_clone.name == o3.name), \
                    "IOmodVar modified original")
        self.failIf((o3_clone.id == o3.id), \
                    "IOmodVar modified original")
        self.failIf((o3_clone.units == o3.units), \
                    "IOmodVar modified original")
        self.failIf((o3_clone.var_desc == o3.var_desc), \
                    "IOmodVar modified original")
        self.failIf((o3_clone.long_name == o3.long_name), \
                    "IOmodVar modified original")

    ## IO2cdms
    def testIO2cdms(self):
        self.failUnless(o3.IO2cdms(), "Conversion to cdms variable failed")

    ## IOshiftTimeInd
    def testIOshiftTimeInd(self):
        earlyD = D.DateTime(1996,6,22,12)
        firstOrigCd = o3.getTime().asComponentTime()[0]
        firstOrigD = ioT.dates2DateTime(firstOrigCd)
        diff = firstOrigD - earlyD
        diffInd = diff.hours
        
        o3_clone = o3.IOclone()
        o3_clone.IOshiftTimeInd(earlyD)

        ## see if the time index for the first date equals difference
        ## between early date and the original date
        ## also check if the first dates are equal
        self.failUnless((o3_clone.getTime().getValue()[0] == diffInd), \
                        "Time shift didn't shift appropriate # indices")
        self.failUnless((o3_clone.getTime().asComponentTime()[0] == firstOrigCd), \
                        "Time shift changed date range")


    ################
    ## iofilescan ##
    ################
        
    ## scanning files
    def testScan(self):
        self.failUnless(ioT.scan(scan1, date1, date2), "scan failed")

    def testScanError(self):
        self.assertRaises(KeyError, ioT.scan, scan1, date2, date1)
        self.assertRaises(KeyError,ioT.scan, scan1, date1, date3)
        self.assertRaises(LookupError,ioT.scan, scan1 +"junk", date1, date2)

    ## reading a scanned variable
    def testReadVarScan(self):
        self.failUnless(fs("o3"))

    def testReadVarScanError(self):
        self.assertRaises(cdms.CDMSError, fs, "junk")
        
        
    #############
    ## writing ##
    #############

    def testWriteCF(self):

        ## test opening the CF file for writing
        ## B/c writes don't return anything, use a try statement
        try: g = ioT.open(ofile1, "w")
        except: self.fail("CF open file for write failed")
        try: g.write([o3,no2,co])
        except: self.fail("CF write of variables failed")
        try: g.close()
        except: self.fail("CF close file for writing failed")

        
    def testWriteIoapi(self):

        ## Single write
        ## test opening the ioapi file for writing
        ## B/c writes don't return anything, use a try statement
        ## use log files to redirect ioapi lib output
        
        try: g = ioT.open(ofile2,"w", ioT.iofileFlag, logFile = log1)
        except: self.fail("IOAPI open file for single write failed")
        try: g.write([o3,no2,co])
        except: self.fail("IOAPI single write of variables failed")
        try: g.close()
        except: self.fail("IOAPI close file for single writing failed")

        ## multi write
        newM = ioT.combineMeta([o3,no2,co])
        try: g = ioT.open(ofile3, "w", ioT.iofileFlag, newM)
        except: self.fail("IOAPI open file for multi-write failed")
        try: g.write([co,o3])
        except: self.fail("IOAPI multi-write 1st variables failed")
        try: g.write(no2)
        except: self.fail("IOAPI multi-write 2nd variables failed")
        try: g.close()
        except: self.fail("IOAPI close file for multi-write failed")


    def testWriteIoapiError(self):

        ## single write errors, a second write should fail
        g = ioT.open(ofile4,"w", ioT.iofileFlag, logFile = log1)
        g.write([o3,co])
        self.assertRaises(IOError,g.write,no2)
        g.close()

        ## multi-write errors, a write of a variable not in newM
        ## should fail
        newM = ioT.combineMeta([o3,no2])
        g = ioT.open(ofile5, "w", ioT.iofileFlag, newM)
        self.assertRaises(IOError, g.write, co)
        g.close()


    #####################
    ## cdmsmeta object ##
    #####################
        
    def testCdmsmetaInit(self):
        ## test 3 ways of creating a cdms meta object:
        ## ioapi file, CF file, cdms variable
        h = ioT.open(file3CF)
        self.failUnless(ioT.cdmsmeta(f, ioT.iofileFlag),\
                        "failed to create cdmsmeta from ioapi file")
        self.failUnless(ioT.cdmsmeta(h, ioT.cffileFlag),\
                        "failed to create cdmsmeta from CF file")
        self.failUnless(ioT.cdmsmeta(o3, ioT.cdmsvarFlag),\
                        "failed to create cdmsmeta from cdms variable")


    def testCdmsmetaCopy(self):
        self.failUnless(cdmsM.copy(), "cdmsmeta copy failed")


    def testCdmsmetaGetAxis(self):
        self.failUnless(cdmsM.getAxes(), "cdmsmeta get axes failed")

    def testCdmsmetaLatlonAxes(self):
        self.failUnless(cdmsM.latlonAxes(o3.ioM), \
                        "cdmsmeta lat/lon axes generation failed") 

    ###################
    ## iometa object ##
    ###################

    def testIometaCopy(self):
        self.failUnless(o3.ioM.copy(), "Iometa copy failed")

    
    def testIometaIO2cdms(self):
        self.failUnless(o3.ioM.IO2cdms(), "Iometa conversion to cdms failed")

    def testIometaIO2gridmap(self):
        self.failUnless(o3.ioM.IO2gridmap(True), \
                        "Iometa conversion to grid_map name failed")
        self.failUnless(o3.ioM.IO2gridmap(), \
                        "Iometa conversion to grid_map failed")
        
    def testIometaProjCode2Name(self):
        self.failUnless(o3.ioM.projCode2Name(2),\
                        "Get projection code name failed")

        ## Presently unsupported projection code
        self.assertRaises(KeyError, o3.ioM.projCode2Name, 5)

    def testIometaUpdateFromVar(self):
        ioM = o3.ioM.copy()
        try: ioM.updateFromVar(no2)
        except: self.fail("update ioM from variable failed")

    def testIometaReplVar(self):
        newnameLst = ["NO2", "PM2.5", "ASO4", "NOX"]
        newunitLst = ["ppm", "micrograms/m**3", "micrograms/m**3", "ppm"]
        newdescLst = ["Var NO2", "Var PM2.5", "Var SO4 aerosol", "Var NOx"]

        ioM = o3.ioM.copy()
        try: ioM.replVar(newnameLst, newunitLst, newdescLst)
        except: self.fail("iometa replace variable failed")


        ## test new values:
        self.failUnless((ioM.nvars == len(newnameLst)), \
                        "replVar did not correctly change the # variables")
        self.failUnless((ioM.vnameLst == newnameLst), \
                        "replVar did not correctly change the variable names")
        self.failUnless((ioM.vunitsLst == newunitLst), \
                        "replVar did not correctly change the variable units")
        self.failUnless((ioM.vdescLst == newdescLst), \
                        "replVar did not correctly change the variable desc")


        ## test to make sure that it didn't effect original
        self.failIf((ioM.nvars == o3.ioM.nvars), \
                        "replVar modified the original")
        self.failIf((ioM.vnameLst == o3.ioM.vnameLst), \
                        "replVar modified the original")
        self.failIf((ioM.vunitsLst == o3.ioM.vunitsLst), \
                        "replVar modified the original")
        self.failIf((ioM.vdescLst == o3.ioM.vdescLst), \
                        "replVar modified the original")

    def testIometaChangeAttribute(self):
        ## test changing some attributes directly
        newgridName = "M_test"
        newfileDesc = "Test file"
        ioM = o3.ioM.copy()

        try: ioM.gridName = newgridName
        except: self.fail("Directly modifying gridName failed")
        try: ioM.fileDesc = newfileDesc
        except: self.fail("Directly modifying fileDesc failed")
        
        ## test to make sure didn't effect original
        self.failIf((ioM.gridName == o3.ioM.gridName), \
                   "Direct modification of gridname modified the original")
        self.failIf((ioM.fileDesc == o3.ioM.fileDesc), \
                   "Direct modification of fileDesc modified the original")

    ###############
    ## Functions ##
    ###############

    ## time conversion
    def testDateConv(self):
        self.failUnless(ioT.dates2DateTime(date1))
        self.failUnless(ioT.dates2Cdtime(date1))

        ## comparison to exact date
        date1Date = D.DateTime(1996,6,24,8)
        date1Cdtime = cdtime.comptime(1996,6,24,8)
        self.assertEqual(ioT.dates2DateTime(date1), date1Date)
        self.assertEqual(ioT.dates2Cdtime(date1), date1Cdtime)

    def testDateConvError(self):
        wrongformat1 = "1996-6-24 8:00"
        wrongformat2 = "1996-06-24 8"

        self.assertRaises(D.RangeError, ioT.dates2DateTime, wrongformat1)
        self.assertRaises(D.RangeError, ioT.dates2Cdtime, wrongformat1)
        
        ## test that unequal, should have wrongformat --> 1996-6-24 00:00
        date1Date = D.DateTime(1996,6,24,8)
        date1Cdtime = cdtime.comptime(1996,6,24,8)
        self.assertNotEqual(ioT.dates2DateTime(wrongformat2), date1Date)
        self.assertNotEqual(ioT.dates2Cdtime(wrongformat2), date1Cdtime)

    ## Coordinate conversion
    def testCoordConv(self):

        ## define equivalent points in lat/lon, xlon/ylat (projection), row/col
        coordLL = [(lon1,lat1)]
        coordProj = [(xlon1, ylat1)]
        coordCR = [(c1,r1)]
        cdmsM = ioT.cdmsmeta(o3, ioT.cdmsvarFlag)
        
        coordOutLL1 = ioT.coordConv(o3.ioM, coordProj, ioT.proj2llFlag)
        coordOutLL2 = ioT.coordConv(o3.ioM, coordCR, ioT.cr2llFlag, cdmsM)
        coordOutProj1 = ioT.coordConv(o3.ioM, coordLL)
        coordOutProj2 = ioT.coordConv(o3.ioM, coordCR, ioT.cr2projFlag, cdmsM)

        self.assertAlmostEqual(coordLL[0][0], coordOutLL1[0][0], places=5)
        self.assertAlmostEqual(coordLL[0][1], coordOutLL1[0][1], places=5)
        self.assertAlmostEqual(coordLL[0][0], coordOutLL2[0][0], places=5)
        self.assertAlmostEqual(coordLL[0][1], coordOutLL2[0][1], places=5)

        ## check that the difference b/w the 2 coordinates in xlon, ylat
        ## (i.e. in meters) is less than 1m
        diffX1 = coordOutProj1[0][0] - coordProj[0][0]
        diffY1 = coordOutProj1[0][1] - coordProj[0][1]
        diffX2 = coordOutProj2[0][0] - coordProj[0][0]
        diffY2 = coordOutProj2[0][1] - coordProj[0][1]
        
        self.failUnless(diffX1 < 1., "Coord conv x diff > 1 m")
        self.failUnless(diffY1 < 1., "Coord conv y diff > 1 m")
        self.failUnless(diffX2 < 1., "Coord conv x (rc) diff > 1 m")
        self.failUnless(diffY2 < 1., "Coord conv y (rc) diff > 1 m")

    ## concatenating
    def testConcatenate(self):
        h = ioT.open(file2)
        o3_2 = h("o3")
        self.failUnless(ioT.concatenate([o3,o3_2]), \
                        "Concatenating two variables failed")

        ## if domain is not the same size, this should fail
        o3_3 = o3_2[:,:,20:,:]
        self.assertRaises(ValueError, ioT.concatenate, [o3,o3_3])


    ## combine meta
    def testCombineMeta(self):
        self.failUnless(ioT.combineMeta([o3,no2,co]), \
                        "combine meta function failed")

    ## coordInDomain
    def testCoordInDomain(self):

        ioM = o3.ioM.copy()
        pntInLL = (lon1,lat1)
        pntInProj = (xlon1,ylat1)
        pntInCR = (c1,r1)

        ## point outside domain
        pntOutLL = (-75, 62)
        pntOutCR = (100,100)
        pntOutProj = (790000, 2465000)

        ## test if can get full domain
        self.failUnless(ioT.coordInDomain(ioM, cdmsM, typeFlag = ioT.llFlag,\
                                          domainFlag = True), \
                        "Failed to return spatial domain, Lat/Lon")
        self.failUnless(ioT.coordInDomain(ioM, cdmsM, typeFlag = ioT.projFlag,\
                                          domainFlag = True), \
                        "Failed to return spatial domain, xLon/yLat")
        self.failUnless(ioT.coordInDomain(ioM, cdmsM, typeFlag = ioT.crFlag,\
                                          domainFlag = True), \
                        "Failed to return spatial domain, col/row")
        
        ## test if points in domain
        self.failUnless(ioT.coordInDomain(ioM, cdmsM, pntInLL, ioT.llFlag),\
                        "Point in domain failed, lon/lat")
        self.failUnless(ioT.coordInDomain(ioM, cdmsM, pntInProj, ioT.projFlag),\
                        "Point in domain failed, xLon/yLat")
        self.failUnless(ioT.coordInDomain(ioM, cdmsM, pntInCR, ioT.crFlag),\
                        "Point in domain failed, col/row")

        ## tests if points out of domain
        self.failIf(ioT.coordInDomain(ioM, cdmsM, pntOutLL, ioT.llFlag),\
                        "Point out of domain failed, lon/lat")
        self.failIf(ioT.coordInDomain(ioM, cdmsM, pntOutProj, ioT.projFlag),\
                        "Point out of domain failed, xLon/yLat")
        self.failIf(ioT.coordInDomain(ioM, cdmsM, pntOutCR, ioT.crFlag),\
                        "Point out of domain failed, col/row")

    ## dateInDomain 
    def testDateInDomain(self):

        dateIn = ioT.dates2DateTime(date1)
        dateIn2 = dateIn + 15*D.oneMinute  ## w/in domain, but not exact
        dateOut = dateIn - 20

        ## test if approximate match and exact match work
        self.failUnless(ioT.dateInDomain(cdmsM, dateIn), \
                        "Exact date in domain failed")
        self.failUnless(ioT.dateInDomain(cdmsM, dateIn, False), \
                        "Exact date in domain failed, #2")
        self.failUnless(ioT.dateInDomain(cdmsM, dateIn2), \
                        "Approximate date in domain failed")

        ## test if outside of domain works
        self.failIf(ioT.dateInDomain(cdmsM, dateIn2, False), \
                        "Approximate date outside of exact domain failed")
        self.failIf(ioT.dateInDomain(cdmsM, dateOut), \
                        "Date outside of domain failed")
        self.failIf(ioT.dateInDomain(cdmsM, dateOut, False), \
                        "Date outside of exact domain failed")
        

    ## layerInDomain
                        
    ## createVariable
    def testCreateVariable(self):
        o3Array = o3.getValue()
        o3Cdms = o3.IO2cdms()
        ioM = o3.ioM.copy()
        axes = cdmsM.getAxes()
        attributes = o3.attributes

        ## test creating a variable from cdms and numeric variables
        self.failUnless(ioT.createVariable(o3Cdms, ioM), \
                        "Create variable from cdms data failed")
        self.failUnless(ioT.createVariable(o3Array, ioM, axes, "O3",attributes), \
                        "Create variable from Numeric data failed")
        
    ## binAverager
    def testBinAverager(self):
        date1D = D.DateTime(1996,6,24,6)
        date2D = date1D + 47*D.oneHour
        fs = ioT.scan(scan1, date1D, date2D)
        o3_hourly = fs("o3")

        ## should raise error if run binaverager on time w/o setting bounds
        self.assertRaises(LookupError, ioT.binAverager, o3_hourly)

        ## set bounds on time axis and now should work
        cdutil.setTimeBoundsDaily(o3_hourly.getTime(), frequency=24)
        self.failUnless(ioT.binAverager(o3_hourly), \
                        "bin averaging failed to convert hourly to daily data")
        

        
    ## Cleanup output files

##     def tearDown(self):
##         if os.path.isfile(ofile1):
##             os.remove(ofile1)

##         if os.path.isfile(ofile2):
##             os.remove(ofile2)

##         if os.path.isfile(ofile3):
##             os.remove(ofile3)

##         if os.path.isfile(ofile4):
##             os.remove(ofile4)

##         if os.path.isfile(ofile5):
##             os.remove(ofile5)

##         if os.path.isfile(log1):
##             os.remove(log1)

            


###################################################

## actually run the unittest

suite = unittest.makeSuite(iotTest)
unittest.TextTestRunner(verbosity=1).run(suite)


###################################################

#!/usr/bin/env python
import os

## this test is for the cdat test_script
## Assumes that you are in the ioapiTools/Test directory

## tests that module will import
import ioapiTools



## the example data location, relative to test script
idir = "exampleData"

## print some diagnostics
## print "###################################"
## print "Testing ioapiTools:"
## print "   input dir: %s" %idir
## print "   output dir: %s" %idir
## print "###################################"

## Now run the unit test script
progStr = "./unit_ioapiTools.py " + idir
os.system(progStr)

from pyncl import *
from RandomArray import *

# pyncl (http://www.cdc.noaa.gov/people/jeffrey.s.whitaker/python/pyncl.html) examples 

NCARG_ROOT = None

# optionally, set NCARG_ROOT (ncl installation directory).
# (not needed if NCARG_ROOT is set as an environment variable)

#NCARG_ROOT = "/usr/local/ncl"

# choose graphics device.

device = raw_input("graphics device (x11, ps, eps, png, gif, pdf or ncgm): ")

# example 1: simple x-y plot with missing values.

# create data.
npts = 21
xdata = (Numeric.arange(npts).astype('d'))/(npts-1)
ydata = random(npts)
ydata[10:13] = 1.e30 # make some values missing

# create cdms transient variable.
x_axis = cdms.createAxis(xdata)
x_axis.id = 'xdata'
x_axis.long_name = 'X'
# set fill value to missing value.
ydata = cdms.createVariable(ydata,axes=[x_axis],fill_value=1.e30)
ydata.long_name = 'Y'

# create Ncl instance, add variables to ncl variable dictionary,
if NCARG_ROOT:
    plot1 = Ncl(NCARG_ROOT=NCARG_ROOT)
else:
    plot1 = Ncl()
plot1['ydata']=ydata
# set plot device and plot name.
plot1.plotdev=device
plot1.plotname="pyncl_ex1"
# 600x600 plot (default 512x512)
plot1.xsize = 600
plot1.ysize = 600

# create NCL script and run it.
# see http://www.ccsm.ucar.edu/csm/support/CSM_Graphics/index.shtml
# for lots of nifty NCL graphics examples.
plot1('res = True')
plot1('res@xyMarkLineModes = "MarkLines" ')
plot1('res@xyMarker = 1 ; choose marker style')
plot1('res@xyMarkerSizeF = 0.05  ; choose marker size')
plot1('res@tiMainString = "Plot with Missing Values"')
plot1('plot = gsn_xy(wks,ydata&xdata,ydata,res)')  
# execute NCL script and generate the plot (600x600).
plot1.nclrun()

# example 2: polar contour map.

# create data.
nlats = 73
nlons = 144
delat = 2.*math.pi/nlons
lats = Numeric.zeros((nlats,nlons),'f')
lons = Numeric.zeros((nlats,nlons),'f')
lats = (0.5*math.pi-delat*Numeric.indices(lats.shape)[0,:,:])
lons = (delat*Numeric.indices(lons.shape)[1,:,:])
wave = (Numeric.sin(2.*lats)**8*Numeric.cos(4.*lons))

# create cdms transient variable.
lat_axis=cdms.createUniformLatitudeAxis(90., nlats, -180./(nlats-1))
lon_axis=cdms.createUniformLongitudeAxis(0., nlons, 360./nlons)
wave = cdms.createVariable(wave,axes=[lat_axis,lon_axis],fill_value=1.e30)
wave.long_name = 'Streamfunction Anomaly'
# use NCL function codes to get superscript in units string.
# The default function code is ":", pyncl changes it to a "~"
# so colons can be used in labels.
wave.units = 'm/s~S~2~N~'

# create Ncl instance, add variable to ncl variable dictionary,
# NCARG_ROOT only needs to be set by first class instance.
plot2 = Ncl()
# cdms slicing is used to extract only NH extratropics.
plot2['wave']=wave(latitude=(20.,90.))
plot2.plotdev = device
plot2.plotname = "pyncl_ex2"
plot2.xsize = 600
plot2.ysize = 600
cint = 0.2  # contour interval for plot.

# create the NCL script.
plot2("""
; the ncl script commands are one big multi-line string
; all the gsn scripts are loaded and the data is read in automatically.
; No "begin" or "end" statements are needed.
; the data is accessed using the name defined by the data dictionary key.
  printVarSummary(wave)
; choose colormap (this is one of the 'extra' colormaps provided by pyncl)
  gsn_define_colormap(wks,"BuDRd")
  res                 = True
  res@gsnSpreadColors = True 
  res@cnFillOn        = True            ; turns on the color
  res@mpFillOn        = False           ; turns off continent gray
  res@cnLineLabelsOn  = False           ; no contour labels
  res@gsnPolar        = "NH"
  res@mpMinLatF       = wave&latitude(0)
  res@mpCenterLonF    = 270
  res@mpGridLonSpacingF = 90 
  res@mpGridLatSpacingF = 45 
  res@cnLevelSpacingF = %(cint)s
  res@tiMainString    = "Idealized Wave Field"
  plot             = gsn_csm_contour_map_polar(wks,wave,res)
""" % locals())  # local variables 'cint' is substituted.
# execute NCL script - 600x600 pixel plot will display in an X window
plot2.nclrun()

# view the png file using the viewer application provided 
# with the Python Imaging Lib.
if device == "png":
    try: 
        from viewer import view
    except:
        pass
    else:
        view(plot2.plotfile)
# rerun script and save as landscape pdf
if device != "pdf":
    plot2.plotdev = "pdf"
    plot2.landscape = 1
# Save=1 causes scripts, data and resource file to be saved
# in present working directory.
    plot2.nclrun(Save=1)

# example 3:  multi-panel cylindrical contour plot.

plot3 = Ncl()

# create another transient variable to plot.
mean = 0.5*Numeric.cos(2.*lats)*((Numeric.sin(2.*lats))**2 + 2.)
mean = cdms.createVariable(mean,axes=[lat_axis,lon_axis],fill_value=1.e30)
mean.long_name = 'Mean Streamfunction'
mean.units = wave.units

# use data from previous example.
plot3['wave']=wave(latitude=(0.,90.))
# add another transient variable to data dictionary
plot3['zonal']=mean(latitude=(0.,90.))
# add a third variable (the sum of the previous two).
total = wave + mean
total.long_name = 'Total Streamfunction'
total.units = wave.units
plot3['total']=total(latitude=(0.,90.))
plot3.plotdev = device
plot3.plotname = "pyncl_ex3"
plot3.xsize = 700
plot3.ysize = 700

# create ncl script for plot3 class instance.
plot3("""
  plot = new(3,graphic)                 ; create a plot array
  res                 = True
  res@gsnDraw  = False                  ; don't draw
  res@gsnFrame = False                  ; don't advance frame
  res@mpMinLatF       = wave&latitude(0)
  res@mpGridLonSpacingF = 90 
  res@mpGridLatSpacingF = 45 
  res@cnLevelSpacingF = %(cint)s
  res@tiMainString    = "Idealized Wave Field"
  plot(0)             = gsn_csm_contour_map_ce(wks,wave,res)
  plot(0)             = ZeroNegDashLineContour(plot(0))
  res@tiMainString    = "Idealized Mean Field"
  plot(1)             = gsn_csm_contour_map_ce(wks,zonal,res)
  plot(1)             = ZeroNegDashLineContour(plot(1))
  res@tiMainString    = "Total Field"
  plot(2)             = gsn_csm_contour_map_ce(wks,total,res)
  plot(2)             = ZeroNegDashLineContour(plot(2))
  resP                = True            ; modify the panel plot
  resP@txString       = "Panel Plot"     ; a common title
  resP@gsnPanelFigureStrings= (/"a)","b)","c)"/) ; add strings to panel
  resP@gsnPanelFigureStringsFontHeightF = 0.02 ; change fig.string font
  gsn_panel(wks,plot,(/3,1/),resP)             ; now draw as one plot
""" % locals())  # local variables 'cint' is substituted.
# show class instance info
print plot3
# execute NCL script and generate 700x700 plot.
plot3.nclrun()

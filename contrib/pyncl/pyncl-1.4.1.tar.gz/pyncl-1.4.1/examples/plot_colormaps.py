from pyncl import *
# plot ncl colormaps
# names of built-in ncl colormaps must be enclosed
# in double quotes, i.e. '"gui_default"'.
for map in extracolormaps:
    print 'plotting ',map
    draw_colormap(map)

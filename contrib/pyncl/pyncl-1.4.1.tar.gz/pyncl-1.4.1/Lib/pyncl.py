"""
Purpose:

Generate NCL plots of cdms transient variables (Numeric arrays with
extra, netCDF like metadata).

*** Now included as a contributed CDAT package (http://esg.llnl.gov/cdat) ***

Background:

NCL (http://ngwww.ucar.edu/ncl) is an interpreted programming language
with superb 2-D graphics capabilities (see
http://www.ccsm.ucar.edu/csm/support/CSM_Graphics/index.shtml for
examples). This class provides access to NCL's gsn
(http://www.cgd.ucar.edu/nclapps/gsn) plot interface using cdms
(http://esg.llnl.gov/cdat/cdms_html/cdms.htm) transient variables. 
It lets you to embed NCL plotting commands directly in your python code,
transparently transferring data (in the form of cdms variables) to NCL.

Source for latest version available at 
http://www.cdc.noaa.gov/people/jeffrey.s.whitaker/python/pyncl.tgz

Requires: cdms module from CDAT (http://esg.llnl.gov/cdat) and 
          NCL version 4.2.0a28 or higher (http://ngwww.ucar.edu/ncl).
          A stripped-down version of CDAT, which includes just the
          cdms module and pyncl is available at 
          http://www.cdc.noaa.gov/people/jeffrey.s.whitaker/python/cdat-4.0-pyncl.tar.gz.
          ImageMagick required to use "png" or "gif" workstation device,
          Should run on any platform CDAT runs on.
          Not tested with python < 2.2.

Usage:

Creating an NCL plot within your python script is a four step process.

(1) Import the pyncl module

>>> from pyncl import *

then create an Ncl class instance

>>> plot1 = Ncl(NCARG_ROOT="/usr/local/ncl")

or 

>>> plot1 = Ncl()

if NCARG_ROOT is set as an environment variable. The ncl executable is assumed 
to live in NCARG_ROOT/bin.

(2)  Convert the Numeric arrays you want to plot to cdms transient variables 
(Numeric masked arrays with extra, netCDF-like metadata).  See the cdms
documentation at http://esg.llnl.gov/cdat/cdms_html/cdms.htm for details.
Add the names of these variables to the class instance variable dictionary.

>>> # create Numeric arrays with some data. xdata are the abscissa values 
>>> # and ydata are the ordinate values.
>>> npts = 51
>>> xdata = (Numeric.arange(npts)*2.*math.pi/(npts-1))
>>> ydata = Numeric.sin(xdata)
>>> # create cdms transient variable.
>>> x_axis = cdms.createAxis(xdata)
>>> x_axis.id = 'xdata'
>>> x_axis.long_name = 'X'
>>> ydata = cdms.createVariable(ydata,axes=[x_axis])
>>> ydata.long_name = 'sin(X)'
>>> # add variable to ncl variable dictionary
>>> # accessed in NCL script using key ('ydata' in this case).
>>> plot1['ydata']=ydata

(3) Set some plot attributes.  Available attributes are:

plotdev:  (string) workstation plotting device.
    Valid values are x11,ps,eps,epsi,pdf,png,gif or ncgm.
    If plot1.plotdev = "png" a png image file containing the plot
    will be generated. Default value is "ps".
plotname: (string) name of graphics workstation
    If plot1.plotname = "pyncl_test" and plot1.plotdev = "ps", 
    a file called "pyncl_test.ps" will be created.
    Default value is "pyncl"
xsize: Plot width in pixels (default 512).
ysize: Plot height in pixels (default 512).
    xsize and ysize only used if plotdev = ncgm,x11,png or gif.
fontname: (string) Font used for titles and legends (default "helvetica").
    See http://ngwww.ucar.edu/ngdoc/ng/ref/FontTable.html for list of fonts.
whitespace: Extra whitespace around cropped png or gif plot (default 0).
funccode:  (string) NCL text function code 
    (default "~" instead of NCL default ":")
fgcolor: (string) Foreground color (default "White")
bgcolor: (string) Background color (default "Black")
    fgcolor and bgcolor must be one of choices given 
    in file $NCARG_ROOT/lib/ncarg/database/rgb.txt.
wksname: (string) name of ncl workstation id.  Default is "wks".
    You must use this name in your ncl script.  Simplest thing is
    to leave the default value and use "wks" in your ncl script.
-- the last three attributes are only used if the plotdev is "ps" or "pdf" --
landscape: Set to True if you want a landscape pdf or ps plot.
    Default is False (portrait plot).
cmykcolors:  If True, NCL will use CMYK color model instead of RGB.
monochrome:  If True, NCL will produce monochrome output (default is color).

Back to our simple example:

>>> plot1.plotdev = "x11" # plot will appear in an X-window.
>>> plot1.xsize = 800    
>>> plot1.ysize = 800

(3) Create an NCL script 
(as one big multi-line string or one command at a time).

This can be done by passing a string as an argument to the class instance,
or by attaching a multi-line string to the nclcommands class attribute
directly. If the class instance is called with a string argument, that
string is appended to the nclcommands class attribute.
Variables in data dictionary are accessed with the NCL script
by their key values.

one big multi-line string:

>>> # create the NCL script.
>>> # see http://www.ccsm.ucar.edu/csm/support/CSM_Graphics/index.shtml
>>> # for lots of nifty NCL graphics examples. 
>>> plot1(\"""
>>> ; no 'begin', 'end' or 'gsn_open_wks' statements are needed.
>>> ; gsn scripts are loaded automatically.
>>>   res              = True
>>>   res@tiMainString = "Sine Wave"
>>> ; cdms transient variables are accessible via their key values
>>> ; The "&" modifier is used to access coordinate 
>>> ; variables (see NCL docs at http://ngwww.ucar.edu/ncl).
>>> ; default workstation id is "wks"
>>>   plot             = gsn_xy(wks,ydata&xdata,ydata,res)  
>>> \""")

one command at a time:

>>> plot1('res=True')
>>> plot1('res@tiMainString="Sine Wave"')
>>> plot1('plot=gsn_xy(wks,ydata&xdata,ydata,res)')

to see the entire NCL script (plus other class instance info)

>>> print plot1

If you use IPython (http://ipython.scipy.org), you can edit your NCL 
script inside the interactive shell using "@ed -x plot1.nclcommands".
After exiting, @ed will return as output the code you edited.
You can then set plot1.nclcommands = _<NUMBER>, where <NUMBER> 
is the prompt number of the output.

(4) Run the NCL script using the nclrun method of the Ncl class
instance.  The nclrun method can take optional arguments "Save" and 
"loadscripts".
"Save=1" will cause the NCL script, data and plot resources to be
saved to the present working directory (by default "Save=0" and they
are written to temporary files and deleted).
The argument loadscripts can contain a list of external NCL scripts
to load (all of the csm and wrf scripts that come with NCL
are loaded automatically).

>>> plot1.nclrun() # plot appears in an 800x800 X window.
>>> plot1.plotdev = "ps" # reset plot device to postscript
>>> plot1.plotname = "pyncl_example"
>>> plot1.nclrun() # a postscript file named "pyncl_example.ps" is created.

The plot should look like this:
    http://www.cdc.noaa.gov/people/jeffrey.s.whitaker/python/pyncl_example.png

Notes:

**   Only one NCL graphics workstation is created in each Ncl class 
instance.  This workstation is created automatically, so nclcommands
should not contain a gsn_open_wks call. The workstation name is "wks"
unless overridden with the wksname attribute.

**   You may use "png" or "gif" workstation devices, 
even though this is not supported by NCL. Image file will be created using
ImageMagick convert if available, otherwise the plot will be saved in
an ncgm file.

**   plot.keys() will show all the variables defined in the data
dictionary.  To print summary information about all the cdms
transient variables in the dictionary: 
>>> for key in plot.keys(): print plot[key]

**   extra colormaps (beyond the ncl built-in colormaps) are available.
Their names are given in the list 'extracolormaps'.  Run the script
plot_colormaps.py in the examples directory to see what these 
colormaps look like. They are taken from Cindy Brewer's web site
(http://www.personal.psu.edu/faculty/c/a/cab38/ColorBrewerBeta2.html)
and University of Oregon's Data Graphics Research Program web site
(http://geography.uoregon.edu/datagraphics/color_scales.htm). You can use
these colormaps just as you would the built-in ncl-colormaps (i.e.
by setting with gsn_define_colormap(wks,"<insert color map name here>") ).

To test, execute "python pyncl.py". A plot should pop up in an X-window.
http://www.cdc.noaa.gov/people/jeffrey.s.whitaker/python/pyncl_examples.py containes more examples.
The plots generated by this script should look like these:
http://www.cdc.noaa.gov/people/jeffrey.s.whitaker/python/pyncl_ex1.png (line plot w/missing vals)
http://www.cdc.noaa.gov/people/jeffrey.s.whitaker/python/pyncl_ex2.png (polar color-filled contour plot)
http://www.cdc.noaa.gov/people/jeffrey.s.whitaker/python/pyncl_ex3.png (panel plot with fig labels)

Author: Jeff Whitaker <Jeffrey.S.Whitaker@noaa.gov>

Version 1.4.1 (20050222)
"""
#Copyright 2004 by Jeffrey Whitaker.

#Permission to use, copy, modify, and distribute this software and its
#documentation for any purpose and without fee is hereby granted,
#provided that the above copyright notice appear in all copies and that
#both that copyright notice and this permission notice appear in
#supporting documentation.

#THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
#INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO
#EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR
#CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF
#USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
#OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
#PERFORMANCE OF THIS SOFTWARE.

import sys, os, string, Numeric, tempfile, math, commands

def _checkpath(program):
    """check to see if file exists in the unix PATH"""
    unixpath = string.split(os.environ.get('PATH'),":")
    for DIR in unixpath:
        if os.path.isfile(os.path.join(DIR, program)):
            return 1
    return 0

def _runcommand(command):
    """runs command using os.popen, prints stdout and stderr"""
# try to use secure mkstemp method in python2.3, if not available use 
# deprecated mktemp method.
    try:
        fd, errfile=tempfile.mkstemp(); os.close(fd)
    except:
        errfile = tempfile.mktemp()
    child = os.popen(command+" 2> %s" % errfile,"r")
    stdout = child.read()
    for line in string.split(stdout,'\n'):
        print line
    stderr = child.close()
    if stderr:
       errout=open(errfile,"r").read()
       os.remove(errfile)
       for line in string.split(errout,'\n'):
           print line
       raise RuntimeError, '%s failed w/ exit code %d' % (command, stderr)
    else:
       os.remove(errfile)

# make sure cdms is installed.
try: 
    import cdms
except:
    raise ImportError, 'requires cdms module from CDAT (http://esg.llnl.gov/cdat)'

# names of extra colormaps
extracolormaps=['Spectral', 'RdYlGn', 'PuBu', 'Accent', 'OrRd', 'Set1', 'Set2', 'Set3', 'BuPu', 'Dark2', 'RdBu', 'Oranges', 'BuGn', 'PiYG', 'YlOrBr', 'YlGn', 'Reds', 'RdPu', 'Greens', 'PRGn', 'YlGnBu', 'RdYlBu', 'Paired', 'BrBG', 'Purples', 'Pastel2', 'Pastel1', 'GnBu', 'Greys', 'RdGy', 'YlOrRd', 'PuOr', 'PuRd', 'Blues', 'PuBuGn', 'GrMg', 'BuGy', 'BuOrR', 'BrBu', 'BuGr', 'BuDRd', 'Cat', 'RdYlBu', 'Bu', 'BuDOr', 'StepSeq','s3pcpn','StepSeqRev','GMT_wysiwyg','GMT_seis','GMT_gebco','GMT_haxby','GMT_ocean','GMT_relief','GMT_no_green','GMT_globe']

class Ncl:
    """creates ncl script instance
 includes methods for defining a dictionary of transient variables to plot,
 creating and running the ncl script."""

    def __init__(self,NCARG_ROOT=None):
        """initialize ncl variable dictionary, 
 set default plot attributes and set NCARG_ROOT if necessary"""
# if NCARG_ROOT not specified as function argument, see if it
# is defined as an environment variable.
        if not NCARG_ROOT:
            NCARG_ROOT = os.environ.get('NCARG_ROOT')
            if not NCARG_ROOT:
                raise NameError, 'NCARG_ROOT not set!'
            else:
                self.NCARG_ROOT = NCARG_ROOT
# set NCARG_ROOT environment variable to value given by function arg.
        else: 
            self.NCARG_ROOT = NCARG_ROOT
            os.environ['NCARG_ROOT'] = NCARG_ROOT
# check to see that ncl executable exists in NCARG_ROOT/bin.
        if not os.path.isfile(os.path.join(os.path.join(NCARG_ROOT,"bin"), "ncl")):
            raise NameError, 'ncl executable not in NCARG_ROOT/bin!'
# initialize ncl variable dictionary.
        self.vardict = {}
# set default values for plot attributes.
        self.landscape = 0 # if False, postscript plots will be portrait
        self.cmykcolors = 0 # if False, NCL will use RGB
        self.monochrome = 0 # if False, NCL will produce color output.
        self.plotdev = "eps"
        self.plotname = "pyncl"
        self.wksname = "wks"
        self.xsize = 512
        self.ysize = 512
        self.whitespace = 0
        self.fontname = "helvetica"
        self.scalefact = 2
        self.nclcommands = 0
        self.funccode = "~"
        self.bgcolor = 'White'
        self.fgcolor = 'Black'

    def __call__(self,string):
        """add NCL commands to self.nclcommands by calling class instance"""
        if not self.nclcommands: self.nclcommands = ""
        if string[:-1] == '\n':
            self.nclcommands = self.nclcommands + string 
        else:
            self.nclcommands = self.nclcommands + string + '\n'

    def __setitem__(self,id,tv):
        """add cdms masked variable to ncl variable dictionary"""
        if cdms.MV.isMaskedVariable(tv):
            tv.id = id
# make transient variable id same as key.
            self.vardict[id]=tv
        else:
# if tv not a transient variable, raise an exception.
            raise ValueError,'only cdms variables can be added to ncl data dictionary!'

    def __getitem__(self,key):
        """show attributes of cdms MV in dictionary"""
        return self.vardict[key].attributes

    def __repr__(self):
        """pretty printer for class instance info"""
        nkeys = len(self.keys())
        info='\nNcl class instance has '+repr(nkeys)+' variable(s) in dict\n'
        if nkeys:
            info=info+'---variable keys---:\n'
            info=info+repr(self.keys())+'\n'
        if self.nclcommands:
            info=info+'---NCL script---:\n'
            info=info+self.nclcommands
        else:
            info=info+'No NCL script defined\n'
        atts = self.__dict__.keys()
        info=info+'---other instance attributes---:\n'
        for att in atts:
            if att != 'vardict' and att != 'nclcommands':
                info=info+att+'='+repr(getattr(self,att))+'\n'
        return info

    def items(self): 
        """get items in ncl variable dictionary"""
        return self.vardict.items()

    def keys(self):
        """get keys in ncl variable dictionary"""
        return self.vardict.keys()

    def values(self):
        """get values in ncl variable dictionary"""
        return self.vardict.values()

    def nclrun(self,loadscripts=None,Save=0):
        """create the ncl script, run it.
 Optional arguments:
 loadscripts -- a list containing names (with full paths) of external
                ncl scripts to load.
 Save        -- if set to 1, NCL scripts, data and resource files are
                saved to the present working directory.  Otherwise
                they are written to temporary files and deleted."""
# check to see if there is anything in NCL variable dictionary.
        if not self.vardict:
            print '\nwarning: NCL variable dictionary is empty!'
            print 'use __setitem__ class method to add data to it'
# check to see that nclcommands is defined.
        if not self.nclcommands:
            print '\nnclcommands not defined!'
            print 'please create nclcommands instance attribute'
            print 'containing ncl script as a multi-line string'
            return
# nclprelim loads all the scripts in $NCARG_ROOT/lib/ncarg/nclscripts.
        nclprelim=["""
load "$NCARG_ROOT/lib/ncarg/nclscripts/csm/gsn_code.ncl"
load "$NCARG_ROOT/lib/ncarg/nclscripts/csm/gsn_csm.ncl" 
load "$NCARG_ROOT/lib/ncarg/nclscripts/csm/contributed.ncl"
load "$NCARG_ROOT/lib/ncarg/nclscripts/csm/ccm_func.ncl"
load "$NCARG_ROOT/lib/ncarg/nclscripts/csm/shea_util.ncl"
load "$NCARG_ROOT/lib/ncarg/nclscripts/csm/popRemap.ncl"
load "$NCARG_ROOT/lib/ncarg/nclscripts/csm/skewt_func.ncl"
load "$NCARG_ROOT/lib/ncarg/nclscripts/csm/wind_rose.ncl"
load "$NCARG_ROOT/lib/ncarg/nclscripts/wrf/WRF_contributed.ncl"\n""" % globals()]
# optionally, load extra scripts specified in loadscripts.
        if loadscripts:
            for loadscript in loadscripts:
                nclprelim.append('load "%s"\n' % loadscript)
# add a 'begin' statement.
        nclprelim.append("begin\n")
# check to make sure there is no gsn_open_wks call in nclcommands.
# if there is, print a warning.
        if string.count(self.nclcommands,'gsn_open_wks') != 0:
            print """
 Warning: nclcommands should not contain a 'gsn_open_wks' call!
 gsn_open_wks is called automatically using the values given by
 the plotdev, plotname, landscape and wksname attributes"""
# Build gsn_open_wks call using plotdev, plotname attributes.
# if plotdev = 'png' or 'gif', set to 'ncgm' while setting
# flag to ensure ncgm file is converted to image later.
        toraster = 0 
        plotdev = self.plotdev
        if self.plotdev == 'png' or self.plotdev == 'gif':
            toraster = 1
            plotdev = 'ncgm'
        nclprelim.append('  wks_type = "%s"\n' % plotdev)
# set resources related to postscript or pdf workstations.
        if plotdev in ['eps','epsi','ps','pdf']:
            if self.landscape:
                nclprelim.append('  wks_type@wkOrientation = "landscape"\n')
            if self.cmykcolors:
                nclprelim.append('  wks_type@wkColorModel = "cmyk"\n')
            if self.monochrome:
                nclprelim.append('  wks_type@wkVisualType = "monochrome"\n')
        nclprelim.append('  wks_name = "%s"\n' % self.plotname)
        nclprelim.append('  %s = gsn_open_wks(wks_type,wks_name)' % self.wksname)
        self.plotfile = self.plotname+'.'+self.plotdev
        if toraster: self.plotfile = self.plotname+'.ncgm'
# add some resources to plotname.res in pwd to customize plots.
        resfile=open(self.plotname+'.res', mode="w")
# background and foreground colors.
        resfile.write('*wkForegroundColor          : '+self.fgcolor+'\n')
        resfile.write('*wkBackgroundColor          : '+self.bgcolor+'\n') 
# set default font.
        resfile.write('*Font                       : '+self.fontname+'\n') 
# set text function code.
        resfile.write('*TextFuncCode               : '+self.funccode+'\n')
# set window size.
        resfile.write('*wkWidth                    : '+str(self.xsize)+'\n')
        resfile.write('*wkHeight                   : '+str(self.ysize)+'\n')
        resfile.close()
# loop over variables in ncl variable dictionary (self.vardict).
        nclread = []
        ncfilenames=[]
        for nvar,(variable_name,variable) in zip(range(len(self.items())),self.items()):
# create temp netCDF file for this variable, write out data.
            if Save:
                if len(self.items()) > 1:
                    ncfilenames.append(self.plotname+'_'+repr(nvar+1)+'.nc')
                else:
                    ncfilenames.append(self.plotname+'.nc')
            else:
# try to use secure mkstemp method in python2.3, if not available use 
# deprecated mktemp method.
                try:
                    fd, fname = tempfile.mkstemp('.nc'); os.close(fd)
                except:
                    fname = tempfile.mktemp('.nc')
                ncfilenames.append(fname)
            cdmsfile = cdms.open(ncfilenames[nvar],'w')
            cdmsfile.write(variable)
            cdmsfile.close()
# include ncl code to read in data, set _FillValue=missing_value (if necessary).
            filename=ncfilenames[nvar]
            nclread.append("""
  inf                 = addfile("%(filename)s","r")
  %(variable_name)s   = inf->%(variable_name)s""" % locals())
            if variable.missing_value:
                nclread.append("""
  %(variable_name)s@_FillValue   = %(variable_name)s@missing_value""" % locals())
# write the ncl commands to the file.
        if Save:
            scriptname=self.plotname+'.ncl'
        else:
# try to use secure mkstemp method in python2.3, if not available use 
# deprecated mktemp method.
            try:
                fd, scriptname=tempfile.mkstemp('.ncl'); os.close(fd)
            except:
                scriptname = tempfile.mktemp('.ncl')
# add line feeds to beginning and end if necessary.
        if self.nclcommands[0] != '\n': self.nclcommands='\n'+self.nclcommands
        if self.nclcommands[-1] != '\n': self.nclcommands=self.nclcommands+'\n'
        nclscript = ''.join(nclprelim+nclread)+self.nclcommands+'end\n'
        scriptfile=open(scriptname, mode="w")
        scriptfile.write(nclscript)
        scriptfile.close()
# execute the ncl script.
        oscommand = os.path.join(self.NCARG_ROOT,"bin/ncl")+" < "+scriptname
        _runcommand(oscommand)
# clean up.
        if not Save:
            os.remove(scriptname)
            os.remove(self.plotname+'.res')
            for filename in ncfilenames:
                os.remove(filename)
# convert to raster image, if desired.
        if toraster: 
            self.ncgmtoraster()

    def ncgmtoraster(self):
        """convert ncgm file (self.plotfile) to raster image format 
 given by self.plotdev.
 
 each frame of ncgm file converted to a separate raster image file.
 upon completion, self.plotfile contains a list of image files.

 requires ImageMagick convert, ncl ctrans, and ncl med.
    """
# image type to convert to (e.g. png or gif)
        filetype = self.plotdev
# resx,resy -- desired width and height of image
        resx = self.xsize
        resy = self.ysize
# whitespace -- number of pixels left around plot after cropping.
        whitespace = self.whitespace
# scalefact -- ctrans used to create intermediate xwindow dump
#      file with resolution scalefact*resx, scalefact*resy. scalefact
#      > 1 needed to yield smooth text in output raster image.
#      default is 2.
        scalefact = self.scalefact
# get plot file name and extension.
        ncgmfile = os.path.splitext(self.plotfile)[0]
        ncgmfile_ext = os.path.splitext(self.plotfile)[1]
        print 'converting '+self.plotfile+' to '+filetype+' format ...'
# check to see that file to be converted is ncgm, and convert is available.
        if ncgmfile_ext != ".ncgm":
            print "Warning: ncgmtoraster only works with ncgm files"
            return
        if not _checkpath('convert'):
            print "can't convert ncgm to "+filetype+" file without ImageMagick convert"
            print "graphics will be saved in ncgm format"
            return
# find number of frames.
        try:
            fd, tmpfile = tempfile.mkstemp('.ncgm'); os.close(fd)
        except:
            tmpfile = tempfile.mktemp('.ncgm')
        nframes = 1
        while 1:
            medcommand = os.path.join(self.NCARG_ROOT,"bin/med")+" -e '"+str(nframes)+"w "+tmpfile+"' "+self.plotfile
            status,output = commands.getstatusoutput(medcommand)
            if output:
                nframes = nframes - 1
                break
            nframes = nframes + 1
        print nframes,' frames'
        resxtmp = resx*scalefact
        resytmp = resy*scalefact
# if only a single frame.
        if nframes == 1:
            try:
                fd, plotfile = tempfile.mkstemp('.xwd'); os.close(fd)
            except:
                plotfile = tempfile.mktemp('.xwd')
            oscommand = os.path.join(self.NCARG_ROOT,"bin/ctrans")+" -d xwd -resolution %ix%i %s.ncgm > %s" % (resxtmp,resytmp,ncgmfile,plotfile)
            _runcommand(oscommand)
            oscommand = "convert -colors 256 -crop 0x0+%i+%i -geometry %ix%i %s %s" % (whitespace,whitespace,resx,resy,plotfile,ncgmfile+'.'+filetype)
            _runcommand(oscommand)
            os.remove(self.plotfile)
            os.remove(plotfile)
            self.plotfile = ncgmfile+'.'+filetype
        else:
# for multiple frames, one per raster image file.
            plotfiles=[]
            try:
                fd, plotfile = tempfile.mkstemp('.xwd'); os.close(fd)
            except:
                plotfile = tempfile.mkstemp('.xwd')
            for nframe in range(nframes):
                medcommand = os.path.join(self.NCARG_ROOT,"bin/med")+" -e '"+str(nframe+1)+"w "+tmpfile+"' "+self.plotfile
                status,output = commands.getstatusoutput(medcommand)
                oscommand = os.path.join(self.NCARG_ROOT,"bin/ctrans")+" -d xwd -resolution %ix%i %s > %s" % (resxtmp,resytmp,tmpfile,plotfile)
                _runcommand(oscommand)
                rasterfile = ncgmfile+'_'+str(nframe)+'.'+filetype
                oscommand = "convert -colors 256 -crop 0x0+%i+%i -geometry %ix%i %s %s" % (whitespace,whitespace,resx,resy,plotfile,rasterfile)
                _runcommand(oscommand)
                plotfiles.append(rasterfile)
# clean up.
            os.remove(self.plotfile)
            os.remove(plotfile)
            os.remove(tmpfile)
# self.plotfile now contains a list of image files.
            self.plotfile = plotfiles

def draw_colormap(name,plotdev='x11',Save=False):
    """
 draw an ncl colormap.
 
 parameters:

 name - name of colormap
 plotdev - plotting device (default X11)
 Save - if True, save the ncl script used to draw the colormap (default False)

 Extra colormaps (not provided by ncl) are available - their names
 are given in the 'extracolormaps' list.
    """
    x = Ncl()
    x.plotname = name
    x.plotdev = plotdev
    x("""
  gsn_define_colormap(wks,"%(name)s")            ; choose colormap
  gsn_draw_colormap(wks)                         ; draw colormap
      """ % locals())
    x.nclrun(Save=Save)

if __name__ == "__main__":

# generate a test plot

# create fake data.
    nlats = 73
    nlons = 144
    delat = 2.*math.pi/nlons
    lats = Numeric.zeros((nlats,nlons),'f')
    lons = Numeric.zeros((nlats,nlons),'f')
    lats = (0.5*math.pi-delat*Numeric.indices(lats.shape)[0,:,:])
    lons = (delat*Numeric.indices(lons.shape)[1,:,:])
    wave = (Numeric.sin(2.*lats)**8*Numeric.cos(4.*lons))

# create cdms transient variable.
    lat_axis=cdms.createUniformLatitudeAxis(90., nlats, -180./(nlats-1))
    lon_axis=cdms.createUniformLongitudeAxis(0., nlons, 360./nlons)
    wave = cdms.createVariable(wave,axes=[lat_axis,lon_axis],fill_value=1.e30)
    wave.long_name = 'Streamfunction Anomaly'
# use NCL function codes to get superscript in units string.
# The default function code is ":", pyncl changes it to a "~"
# so colons can be used in labels.
    wave.units = 'm/s~S~2~N~'

# create Ncl class instance.
    plot = Ncl()
# add variable to ncl variable dictionary,
# cdms slicing is used to extract only NH extratropics.
    plot['wave']=wave(latitude=(20.,90.))
    plot.plotdev = "x11" # set plot device (default is eps)

# create NCL script.
    plot('res=True')
    plot('res@gsnPolar="NH"')
# '&' modifier used to access coordinate values in NCL.
    plot('res@mpMinLatF=wave&latitude(0)')
    plot('plot=gsn_csm_contour_map_polar(wks,wave,res)')

    print plot # print out summary info for class instance

# run script, X window should appear with plot.
    plot.nclrun()

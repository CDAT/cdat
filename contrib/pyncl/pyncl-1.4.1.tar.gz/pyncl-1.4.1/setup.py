from distutils.core import setup
import os, glob

# data_pth is place to install the colormap rgb files.
# NCARG_ROOT env var must be set so that they can go into the ncl
# colormap directory.

rgbfiles = glob.glob('data/*.rgb')
NCARG_ROOT = os.environ.get('NCARG_ROOT')
NCARG_COLORMAP_PATH = os.environ.get('NCARG_COLORMAP_PATH')
if NCARG_COLORMAP_PATH:
    data_pth = NCARG_COLORMAP_PATH.split(':')[0]
elif NCARG_ROOT:
    data_pth = os.path.join(NCARG_ROOT,'lib/ncarg/colormaps')
else:
    raise NameError, 'please set either NCARG_COLORMAP_PATH or NCARG_ROOT environment variables'

setup (name = "pyncl",
       author ="Jeff Whitaker <Jeffrey.S.Whitaker@noaa.gov>",
       author_email ="jeffrey.s.whitaker@noaa.gov",
       version ='1.4.1',
       description = "Generate NCL plots of cdms transient variables (Numeric arrays with extra, netCDF like metadata).",
       url = "http://www.cdc.noaa.gov/people/jeffrey.s.whitaker/python/pyncl.html",
       data_files = [(data_pth,rgbfiles)],
       packages = ['pyncl'],
       package_dir = {'pyncl': 'Lib'},
      )
    

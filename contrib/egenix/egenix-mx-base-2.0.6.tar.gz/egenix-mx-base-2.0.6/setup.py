#!/usr/bin/env python

""" Distutils Setup File for the mx Extensions BASE distribution.

"""
#
# Load configuration(s)
#
import mxBASE
configurations = (mxBASE,)

#
# Run distutils setup...
#
import mxSetup
mxSetup.run_setup(configurations)

# Matlab file read and write utilities
from mio import loadmat, savemat

from numpy.testing import Tester
test = Tester().test

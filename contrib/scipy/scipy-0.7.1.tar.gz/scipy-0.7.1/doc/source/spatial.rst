=============================================================
Spatial algorithms and data structures (:mod:`scipy.spatial`)
=============================================================

.. warning::

   This documentation is work-in-progress and unorganized.

.. toctree::

   spatial.distance

.. automodule:: scipy.spatial
   :members:

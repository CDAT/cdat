=====================================================
Distance computations (:mod:`scipy.spatial.distance`)
=====================================================

.. automodule:: scipy.spatial.distance
   :members:

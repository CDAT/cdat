====================================================================
K-means clustering and vector quantization (:mod:`scipy.cluster.vq`)
====================================================================

.. automodule:: scipy.cluster.vq
   :members:

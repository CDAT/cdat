========================================================
Hierarchical clustering (:mod:`scipy.cluster.hierarchy`)
========================================================

.. warning::

   This documentation is work-in-progress and unorganized.

.. automodule:: scipy.cluster.hierarchy
   :members:
